/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import org.apache.activemq.ActiveMQConnectionFactory;

import java.sql.*;
import java.sql.DriverManager;

import java.net.InetAddress;
import java.net.UnknownHostException;





public class JMSToMySQL implements MessageListener {
	
    //static java.sql.Connection dBconnection;
    PreparedStatement preparedStatement=null;
    

    private Connection connection;
    private Session session;
    private Topic topic;
    private String url = "tcp://192.168.1.172:61616";
    
    private java.sql.Connection dBconnection;

    public static void main(String[] argv) throws Exception {
    	JMSToMySQL l = new JMSToMySQL();
        l.run();
        

        
    }

    public void run() throws JMSException {
    	
    	
    	
    	try{
            System.out.println("Connecting to the database...");  
            Class.forName("com.mysql.jdbc.Driver");  
            dBconnection=DriverManager.getConnection("jdbc:mysql://localhost:3306/61850?useSSL=false","root","erol7294"); 
             } catch(Exception e){
                 e.printStackTrace();
             }
    	System.out.println("MySQL Connected!");
    	
    	String hostname = "Unknown";
        ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory(url);
        connection = factory.createConnection();
    	try
    	{
    	    InetAddress addr;
    	    addr = InetAddress.getLocalHost();
    	    hostname = addr.getHostName();
    	}
    	catch (UnknownHostException ex)
    	{
    	    System.out.println("Hostname can not be resolved");
    	}
    	
    	

        connection.setClientID(hostname);
        connection.start();
        session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        topic = session.createTopic("GWMONT/LLN0.urcbAH");
        MessageConsumer consumer = session.createDurableSubscriber(topic, "AH-Listener");
        consumer.setMessageListener(this);
        

    }

    public void onMessage(Message message) {
    	try {
    		String text = ((TextMessage)message).getText();
    		//System.out.print(text);
    		String ref = "??";
    		String t = "??";
    		float f = 0;
    		String q = "??";
    		String[] attributes = text.split("\n");

			for(int i = 0; i < attributes.length;i++) {
				if(attributes[i].split(": ")[0].equals("Ref"))
					ref = attributes[i].split(": ")[1].trim();
				else if(attributes[i].split(": ")[0].equals("t"))
					t = attributes[i].split(": ")[1].trim();
				else if(attributes[i].split(": ")[0].equals("f"))
					f = Float.parseFloat(attributes[i].split(": ")[1].trim());
				else if(attributes[i].split(": ")[0].equals("q"))
					q = attributes[i].split(": ")[1].trim();
			}
			System.out.println(ref);
			System.out.println(t);
			System.out.println(f);
			System.out.println(q);
			
			insertValues(ref, t ,f, q);
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    public void setUrl(String url) {
        this.url = url;
    }
    
    public void insertValues(String ref, String t, float f, String q ){
    	 
        try{
       	 //System.out.println("Insert MX values");
       	 String query = "insert into measurements (ref, t, f, q)" + " values (?, ?, ?, ?)";
       	 preparedStatement = dBconnection.prepareStatement(query);        
       	 preparedStatement.setString(1, ref);
       	 preparedStatement.setString(2, t);
       	 preparedStatement.setFloat(3, f);
       	 preparedStatement.setString(4, q);
       	 preparedStatement.execute();
       	 //dBconnection.close();
       	 //dBconnection.commit();
       	 //preparedStatement.addBatch();
       	 //preparedStatement.executeBatch();
       	 //preparedStatement.clearBatch();
       	 //dBconnection.commit();
       	 //dBconnection.setAutoCommit(true);
        } catch(Exception e){
            e.printStackTrace();
        }
        System.out.println("Insert MX values Done!");
   }
}
