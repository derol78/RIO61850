/*
 * static_model.c
 *
 * automatically generated from RIO_TEC.icd
 */
#include "static_model.h"

static void initializeValues();

extern DataSet iedModelds_MONT_LLN0_dsAssetHealth;
extern DataSet iedModelds_MONT_LLN0_dsMeasure;
extern DataSet iedModelds_MONT_LLN0_dsOLTC;
extern DataSet iedModelds_MONT_LLN0_dsCalculate1;
extern DataSet iedModelds_MONT_LLN0_dsCalculate2;
extern DataSet iedModelds_MONT_LLN0_dsAlm;
extern DataSet iedModelds_MONT_LLN0_dsState;


extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda0;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda1;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda2;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda3;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda4;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda5;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda6;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda7;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda8;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda9;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda10;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda11;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda12;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda13;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda14;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda15;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda16;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda17;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda18;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda19;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda20;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda21;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda22;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda23;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda24;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda25;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda26;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda27;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda28;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda29;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda30;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda31;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda32;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda33;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda34;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda35;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda36;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda37;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda38;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda39;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda40;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda41;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda42;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda43;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda44;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda45;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda46;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda47;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda48;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda49;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda50;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda51;
extern DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda52;

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda0 = {
  "MONT",
  false,
  "SIML1$MX$Tmp",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda1
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda1 = {
  "MONT",
  false,
  "SIML1$MX$Tmp1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda2
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda2 = {
  "MONT",
  false,
  "SIML1$MX$Tmp2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda3
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda3 = {
  "MONT",
  false,
  "SIML1$MX$Tmp3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda4
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda4 = {
  "MONT",
  false,
  "SIML1$MX$Tmp4",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda5
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda5 = {
  "MONT",
  false,
  "SIML1$MX$H2O",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda6
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda6 = {
  "MONT",
  false,
  "SIML1$MX$H2O1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda7
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda7 = {
  "MONT",
  false,
  "SIML1$MX$H2O2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda8
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda8 = {
  "MONT",
  false,
  "SIML1$MX$H2O3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda9
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda9 = {
  "MONT",
  false,
  "SIML1$MX$H2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda10
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda10 = {
  "MONT",
  false,
  "SIML1$MX$H2ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda11
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda11 = {
  "MONT",
  false,
  "SIML1$MX$H2ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda12
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda12 = {
  "MONT",
  false,
  "SIML1$MX$H2ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda13
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda13 = {
  "MONT",
  false,
  "SIML1$MX$N2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda14
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda14 = {
  "MONT",
  false,
  "SIML1$MX$N2ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda15
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda15 = {
  "MONT",
  false,
  "SIML1$MX$N2ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda16
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda16 = {
  "MONT",
  false,
  "SIML1$MX$N2ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda17
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda17 = {
  "MONT",
  false,
  "SIML1$MX$COppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda18
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda18 = {
  "MONT",
  false,
  "SIML1$MX$COppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda19
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda19 = {
  "MONT",
  false,
  "SIML1$MX$COppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda20
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda20 = {
  "MONT",
  false,
  "SIML1$MX$COppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda21
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda21 = {
  "MONT",
  false,
  "SIML1$MX$CO2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda22
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda22 = {
  "MONT",
  false,
  "SIML1$MX$CO2ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda23
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda23 = {
  "MONT",
  false,
  "SIML1$MX$CO2ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda24
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda24 = {
  "MONT",
  false,
  "SIML1$MX$CO2ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda25
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda25 = {
  "MONT",
  false,
  "SIML1$MX$CH4ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda26
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda26 = {
  "MONT",
  false,
  "SIML1$MX$CH4ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda27
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda27 = {
  "MONT",
  false,
  "SIML1$MX$CH4ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda28
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda28 = {
  "MONT",
  false,
  "SIML1$MX$CH4ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda29
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda29 = {
  "MONT",
  false,
  "SIML1$MX$C2H2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda30
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda30 = {
  "MONT",
  false,
  "SIML1$MX$C2H2ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda31
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda31 = {
  "MONT",
  false,
  "SIML1$MX$C2H2ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda32
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda32 = {
  "MONT",
  false,
  "SIML1$MX$C2H2ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda33
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda33 = {
  "MONT",
  false,
  "SIML1$MX$C2H4ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda34
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda34 = {
  "MONT",
  false,
  "SIML1$MX$C2H4ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda35
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda35 = {
  "MONT",
  false,
  "SIML1$MX$C2H4ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda36
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda36 = {
  "MONT",
  false,
  "SIML1$MX$C2H4ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda37
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda37 = {
  "MONT",
  false,
  "SIML1$MX$C2H6ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda38
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda38 = {
  "MONT",
  false,
  "SIML1$MX$C2H6ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda39
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda39 = {
  "MONT",
  false,
  "SIML1$MX$C2H6ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda40
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda40 = {
  "MONT",
  false,
  "SIML1$MX$C2H6ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda41
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda41 = {
  "MONT",
  false,
  "SIML1$MX$O2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda42
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda42 = {
  "MONT",
  false,
  "SIML1$MX$O2ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda43
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda43 = {
  "MONT",
  false,
  "SIML1$MX$O2ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda44
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda44 = {
  "MONT",
  false,
  "SIML1$MX$O2ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda45
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda45 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda46
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda46 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda47
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda47 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda48
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda48 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda49
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda49 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas4",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda50
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda50 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas5",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda51
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda51 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas6",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda52
};

DataSetEntry iedModelds_MONT_LLN0_dsAssetHealth_fcda52 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas7",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_MONT_LLN0_dsAssetHealth = {
  "MONT",
  "LLN0$dsAssetHealth",
  53,
  &iedModelds_MONT_LLN0_dsAssetHealth_fcda0,
  &iedModelds_MONT_LLN0_dsMeasure
};

extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda0;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda1;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda2;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda3;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda4;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda5;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda6;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda7;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda8;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda9;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda10;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda11;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda12;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda13;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda14;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda15;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda16;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda17;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda18;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda19;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda20;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda21;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda22;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda23;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda24;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda25;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda26;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda27;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda28;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda29;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda30;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda31;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda32;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda33;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda34;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda35;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda36;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda37;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda38;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda39;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda40;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda41;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda42;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda43;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda44;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda45;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda46;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda47;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda48;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda49;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda50;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda51;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda52;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda53;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda54;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda55;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda56;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda57;
extern DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda58;

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda0 = {
  "MONT",
  false,
  "SIML1$MX$Tmp",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda1
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda1 = {
  "MONT",
  false,
  "SIML1$MX$Tmp1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda2
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda2 = {
  "MONT",
  false,
  "SIML1$MX$Tmp2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda3
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda3 = {
  "MONT",
  false,
  "SIML1$MX$Tmp3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda4
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda4 = {
  "MONT",
  false,
  "SIML1$MX$Tmp4",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda5
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda5 = {
  "MONT",
  false,
  "SIML1$MX$H2O",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda6
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda6 = {
  "MONT",
  false,
  "SIML1$MX$H2O1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda7
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda7 = {
  "MONT",
  false,
  "SIML1$MX$H2O2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda8
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda8 = {
  "MONT",
  false,
  "SIML1$MX$H2O3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda9
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda9 = {
  "MONT",
  false,
  "SIML1$MX$H2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda10
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda10 = {
  "MONT",
  false,
  "SIML1$MX$H2ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda11
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda11 = {
  "MONT",
  false,
  "SIML1$MX$H2ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda12
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda12 = {
  "MONT",
  false,
  "SIML1$MX$H2ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda13
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda13 = {
  "MONT",
  false,
  "SIML1$MX$N2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda14
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda14 = {
  "MONT",
  false,
  "SIML1$MX$N2ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda15
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda15 = {
  "MONT",
  false,
  "SIML1$MX$N2ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda16
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda16 = {
  "MONT",
  false,
  "SIML1$MX$N2ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda17
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda17 = {
  "MONT",
  false,
  "SIML1$MX$COppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda18
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda18 = {
  "MONT",
  false,
  "SIML1$MX$COppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda19
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda19 = {
  "MONT",
  false,
  "SIML1$MX$COppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda20
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda20 = {
  "MONT",
  false,
  "SIML1$MX$COppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda21
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda21 = {
  "MONT",
  false,
  "SIML1$MX$CO2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda22
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda22 = {
  "MONT",
  false,
  "SIML1$MX$CO2ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda23
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda23 = {
  "MONT",
  false,
  "SIML1$MX$CO2ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda24
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda24 = {
  "MONT",
  false,
  "SIML1$MX$CO2ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda25
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda25 = {
  "MONT",
  false,
  "SIML1$MX$CH4ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda26
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda26 = {
  "MONT",
  false,
  "SIML1$MX$CH4ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda27
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda27 = {
  "MONT",
  false,
  "SIML1$MX$CH4ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda28
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda28 = {
  "MONT",
  false,
  "SIML1$MX$CH4ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda29
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda29 = {
  "MONT",
  false,
  "SIML1$MX$C2H2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda30
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda30 = {
  "MONT",
  false,
  "SIML1$MX$C2H2ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda31
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda31 = {
  "MONT",
  false,
  "SIML1$MX$C2H2ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda32
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda32 = {
  "MONT",
  false,
  "SIML1$MX$C2H2ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda33
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda33 = {
  "MONT",
  false,
  "SIML1$MX$C2H4ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda34
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda34 = {
  "MONT",
  false,
  "SIML1$MX$C2H4ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda35
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda35 = {
  "MONT",
  false,
  "SIML1$MX$C2H4ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda36
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda36 = {
  "MONT",
  false,
  "SIML1$MX$C2H4ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda37
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda37 = {
  "MONT",
  false,
  "SIML1$MX$C2H6ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda38
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda38 = {
  "MONT",
  false,
  "SIML1$MX$C2H6ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda39
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda39 = {
  "MONT",
  false,
  "SIML1$MX$C2H6ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda40
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda40 = {
  "MONT",
  false,
  "SIML1$MX$C2H6ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda41
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda41 = {
  "MONT",
  false,
  "SIML1$MX$O2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda42
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda42 = {
  "MONT",
  false,
  "SIML1$MX$O2ppm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda43
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda43 = {
  "MONT",
  false,
  "SIML1$MX$O2ppm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda44
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda44 = {
  "MONT",
  false,
  "SIML1$MX$O2ppm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda45
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda45 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda46
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda46 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda47
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda47 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda48
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda48 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda49
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda49 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas4",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda50
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda50 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas5",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda51
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda51 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas6",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda52
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda52 = {
  "MONT",
  false,
  "SIML1$MX$CmbuGas7",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda53
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda53 = {
  "MONT",
  false,
  "CCGR1$MX$FanA",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda54
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda54 = {
  "MONT",
  false,
  "CCGR2$MX$FanA",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda55
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda55 = {
  "MONT",
  false,
  "CCGR3$MX$FanA",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda56
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda56 = {
  "MONT",
  false,
  "CCGR4$MX$FanA",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda57
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda57 = {
  "MONT",
  false,
  "CCGR5$MX$FanA",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsMeasure_fcda58
};

DataSetEntry iedModelds_MONT_LLN0_dsMeasure_fcda58 = {
  "MONT",
  false,
  "CCGR6$MX$FanA",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_MONT_LLN0_dsMeasure = {
  "MONT",
  "LLN0$dsMeasure",
  59,
  &iedModelds_MONT_LLN0_dsMeasure_fcda0,
  &iedModelds_MONT_LLN0_dsOLTC
};

extern DataSetEntry iedModelds_MONT_LLN0_dsOLTC_fcda0;
extern DataSetEntry iedModelds_MONT_LLN0_dsOLTC_fcda1;
extern DataSetEntry iedModelds_MONT_LLN0_dsOLTC_fcda2;
extern DataSetEntry iedModelds_MONT_LLN0_dsOLTC_fcda3;

DataSetEntry iedModelds_MONT_LLN0_dsOLTC_fcda0 = {
  "MONT",
  false,
  "YLTC1$ST$TapChg$valWTr$posVal",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsOLTC_fcda1
};

DataSetEntry iedModelds_MONT_LLN0_dsOLTC_fcda1 = {
  "MONT",
  false,
  "YLTC1$ST$OpCnt",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsOLTC_fcda2
};

DataSetEntry iedModelds_MONT_LLN0_dsOLTC_fcda2 = {
  "MONT",
  false,
  "YLTC1$ST$EndPosR",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsOLTC_fcda3
};

DataSetEntry iedModelds_MONT_LLN0_dsOLTC_fcda3 = {
  "MONT",
  false,
  "YLTC1$ST$EndPosL",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_MONT_LLN0_dsOLTC = {
  "MONT",
  "LLN0$dsOLTC",
  4,
  &iedModelds_MONT_LLN0_dsOLTC_fcda0,
  &iedModelds_MONT_LLN0_dsCalculate1
};

extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda0;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda1;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda2;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda3;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda4;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda5;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda6;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda7;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda8;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda9;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda10;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda11;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda12;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda13;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda14;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda15;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda16;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda17;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda18;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda19;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda20;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda21;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda22;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda23;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda24;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda25;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda26;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda27;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda28;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda29;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda30;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda31;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda32;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda33;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda34;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda35;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda36;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda37;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda38;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda39;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda40;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda41;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda42;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda43;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda44;

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda0 = {
  "MONT",
  false,
  "GGIO1$ST$IntIn1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda1
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda1 = {
  "MONT",
  false,
  "GGIO1$ST$IntIn2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda2
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda2 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda3
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda3 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda4
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda4 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda5
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda5 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn4",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda6
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda6 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn5",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda7
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda7 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn6",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda8
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda8 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn7",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda9
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda9 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn8",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda10
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda10 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn9",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda11
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda11 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn10",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda12
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda12 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn11",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda13
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda13 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn12",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda14
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda14 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn13",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda15
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda15 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn14",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda16
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda16 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn15",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda17
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda17 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn16",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda18
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda18 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn17",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda19
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda19 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn18",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda20
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda20 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn19",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda21
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda21 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn20",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda22
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda22 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn21",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda23
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda23 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn22",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda24
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda24 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn23",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda25
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda25 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn24",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda26
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda26 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn25",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda27
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda27 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn26",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda28
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda28 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn27",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda29
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda29 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn28",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda30
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda30 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn29",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda31
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda31 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn30",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda32
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda32 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn31",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda33
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda33 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn32",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda34
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda34 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn33",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda35
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda35 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn34",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda36
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda36 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn35",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda37
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda37 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn36",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda38
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda38 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn37",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda39
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda39 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn38",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda40
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda40 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn39",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda41
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda41 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn40",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda42
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda42 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn41",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda43
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda43 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn42",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda44
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate1_fcda44 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn43",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_MONT_LLN0_dsCalculate1 = {
  "MONT",
  "LLN0$dsCalculate1",
  45,
  &iedModelds_MONT_LLN0_dsCalculate1_fcda0,
  &iedModelds_MONT_LLN0_dsCalculate2
};

extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda0;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda1;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda2;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda3;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda4;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda5;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda6;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda7;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda8;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda9;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda10;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda11;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda12;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda13;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda14;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda15;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda16;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda17;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda18;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda19;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda20;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda21;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda22;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda23;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda24;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda25;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda26;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda27;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda28;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda29;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda30;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda31;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda32;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda33;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda34;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda35;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda36;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda37;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda38;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda39;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda40;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda41;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda42;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda43;
extern DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda44;

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda0 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn44",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda1
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda1 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn45",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda2
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda2 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn46",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda3
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda3 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn47",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda4
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda4 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn48",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda5
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda5 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn49",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda6
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda6 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn50",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda7
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda7 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn51",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda8
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda8 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn52",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda9
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda9 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn53",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda10
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda10 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn54",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda11
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda11 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn55",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda12
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda12 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn56",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda13
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda13 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn57",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda14
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda14 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn58",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda15
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda15 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn59",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda16
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda16 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn60",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda17
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda17 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn61",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda18
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda18 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn62",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda19
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda19 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn63",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda20
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda20 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn64",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda21
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda21 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn65",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda22
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda22 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn66",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda23
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda23 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn67",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda24
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda24 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn68",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda25
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda25 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn69",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda26
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda26 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn70",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda27
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda27 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn71",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda28
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda28 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn72",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda29
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda29 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn73",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda30
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda30 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn74",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda31
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda31 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn75",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda32
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda32 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn76",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda33
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda33 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn77",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda34
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda34 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn78",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda35
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda35 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn79",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda36
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda36 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn80",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda37
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda37 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn81",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda38
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda38 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn82",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda39
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda39 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn83",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda40
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda40 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn84",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda41
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda41 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn85",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda42
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda42 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn86",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda43
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda43 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn87",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda44
};

DataSetEntry iedModelds_MONT_LLN0_dsCalculate2_fcda44 = {
  "MONT",
  false,
  "GGIO1$MX$AnIn88",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_MONT_LLN0_dsCalculate2 = {
  "MONT",
  "LLN0$dsCalculate2",
  45,
  &iedModelds_MONT_LLN0_dsCalculate2_fcda0,
  &iedModelds_MONT_LLN0_dsAlm
};

extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda0;
extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda1;
extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda2;
extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda3;
extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda4;
extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda5;
extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda6;
extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda7;
extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda8;
extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda9;
extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda10;
extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda11;
extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda12;
extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda13;
extern DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda14;

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda0 = {
  "MONT",
  false,
  "GGIO2$ST$Alm1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAlm_fcda1
};

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda1 = {
  "MONT",
  false,
  "GGIO2$ST$Alm2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAlm_fcda2
};

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda2 = {
  "MONT",
  false,
  "GGIO2$ST$Alm3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAlm_fcda3
};

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda3 = {
  "MONT",
  false,
  "GGIO2$ST$Alm4",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAlm_fcda4
};

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda4 = {
  "MONT",
  false,
  "GGIO2$ST$Alm5",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAlm_fcda5
};

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda5 = {
  "MONT",
  false,
  "GGIO2$ST$Alm6",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAlm_fcda6
};

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda6 = {
  "MONT",
  false,
  "GGIO2$ST$Alm7",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAlm_fcda7
};

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda7 = {
  "MONT",
  false,
  "GGIO2$ST$Alm8",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAlm_fcda8
};

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda8 = {
  "MONT",
  false,
  "GGIO2$ST$Alm9",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAlm_fcda9
};

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda9 = {
  "MONT",
  false,
  "GGIO2$ST$Alm10",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAlm_fcda10
};

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda10 = {
  "MONT",
  false,
  "GGIO2$ST$Alm11",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAlm_fcda11
};

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda11 = {
  "MONT",
  false,
  "GGIO2$ST$Alm12",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAlm_fcda12
};

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda12 = {
  "MONT",
  false,
  "GGIO2$ST$Alm13",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAlm_fcda13
};

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda13 = {
  "MONT",
  false,
  "GGIO2$ST$Alm14",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsAlm_fcda14
};

DataSetEntry iedModelds_MONT_LLN0_dsAlm_fcda14 = {
  "MONT",
  false,
  "GGIO2$ST$Alm15",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_MONT_LLN0_dsAlm = {
  "MONT",
  "LLN0$dsAlm",
  15,
  &iedModelds_MONT_LLN0_dsAlm_fcda0,
  &iedModelds_MONT_LLN0_dsState
};

extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda0;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda1;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda2;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda3;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda4;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda5;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda6;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda7;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda8;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda9;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda10;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda11;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda12;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda13;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda14;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda15;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda16;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda17;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda18;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda19;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda20;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda21;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda22;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda23;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda24;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda25;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda26;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda27;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda28;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda29;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda30;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda31;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda32;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda33;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda34;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda35;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda36;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda37;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda38;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda39;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda40;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda41;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda42;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda43;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda44;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda45;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda46;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda47;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda48;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda49;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda50;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda51;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda52;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda53;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda54;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda55;
extern DataSetEntry iedModelds_MONT_LLN0_dsState_fcda56;

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda0 = {
  "MONT",
  false,
  "GGIO2$ST$Ind1",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda1
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda1 = {
  "MONT",
  false,
  "GGIO2$ST$Ind2",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda2
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda2 = {
  "MONT",
  false,
  "GGIO2$ST$Ind3",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda3
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda3 = {
  "MONT",
  false,
  "GGIO2$ST$Ind4",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda4
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda4 = {
  "MONT",
  false,
  "GGIO2$ST$Ind5",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda5
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda5 = {
  "MONT",
  false,
  "GGIO2$ST$Ind6",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda6
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda6 = {
  "MONT",
  false,
  "GGIO2$ST$Ind7",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda7
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda7 = {
  "MONT",
  false,
  "GGIO2$ST$Ind8",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda8
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda8 = {
  "MONT",
  false,
  "GGIO2$ST$Ind9",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda9
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda9 = {
  "MONT",
  false,
  "GGIO2$ST$Ind10",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda10
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda10 = {
  "MONT",
  false,
  "GGIO2$ST$Ind11",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda11
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda11 = {
  "MONT",
  false,
  "GGIO2$ST$Ind12",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda12
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda12 = {
  "MONT",
  false,
  "GGIO2$ST$Ind13",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda13
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda13 = {
  "MONT",
  false,
  "GGIO2$ST$Ind14",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda14
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda14 = {
  "MONT",
  false,
  "GGIO2$ST$Ind15",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda15
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda15 = {
  "MONT",
  false,
  "GGIO2$ST$Ind16",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda16
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda16 = {
  "MONT",
  false,
  "GGIO2$ST$Ind17",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda17
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda17 = {
  "MONT",
  false,
  "GGIO2$ST$Ind18",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda18
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda18 = {
  "MONT",
  false,
  "GGIO2$ST$Ind19",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda19
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda19 = {
  "MONT",
  false,
  "GGIO2$ST$Ind20",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda20
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda20 = {
  "MONT",
  false,
  "GGIO2$ST$Ind21",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda21
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda21 = {
  "MONT",
  false,
  "GGIO2$ST$Ind22",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda22
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda22 = {
  "MONT",
  false,
  "GGIO2$ST$Ind23",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda23
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda23 = {
  "MONT",
  false,
  "GGIO2$ST$Ind24",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda24
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda24 = {
  "MONT",
  false,
  "GGIO2$ST$Ind25",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda25
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda25 = {
  "MONT",
  false,
  "GGIO2$ST$Ind26",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda26
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda26 = {
  "MONT",
  false,
  "GGIO2$ST$Ind27",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda27
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda27 = {
  "MONT",
  false,
  "GGIO2$ST$Ind28",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda28
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda28 = {
  "MONT",
  false,
  "GGIO2$ST$Ind29",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda29
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda29 = {
  "MONT",
  false,
  "GGIO2$ST$Ind30",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda30
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda30 = {
  "MONT",
  false,
  "GGIO2$ST$Ind31",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda31
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda31 = {
  "MONT",
  false,
  "GGIO2$ST$Ind32",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda32
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda32 = {
  "MONT",
  false,
  "GGIO2$ST$Ind33",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda33
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda33 = {
  "MONT",
  false,
  "GGIO2$ST$Ind34",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda34
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda34 = {
  "MONT",
  false,
  "GGIO2$ST$Ind35",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda35
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda35 = {
  "MONT",
  false,
  "GGIO2$ST$Ind36",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda36
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda36 = {
  "MONT",
  false,
  "GGIO2$ST$Ind37",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda37
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda37 = {
  "MONT",
  false,
  "GGIO2$ST$Ind38",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda38
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda38 = {
  "MONT",
  false,
  "GGIO2$ST$Ind39",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda39
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda39 = {
  "MONT",
  false,
  "GGIO2$ST$Ind40",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda40
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda40 = {
  "MONT",
  false,
  "GGIO2$ST$Ind41",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda41
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda41 = {
  "MONT",
  false,
  "GGIO2$ST$Ind42",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda42
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda42 = {
  "MONT",
  false,
  "GGIO2$ST$Ind43",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda43
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda43 = {
  "MONT",
  false,
  "GGIO2$ST$Ind44",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda44
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda44 = {
  "MONT",
  false,
  "GGIO2$ST$Ind45",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda45
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda45 = {
  "MONT",
  false,
  "GGIO2$ST$Ind46",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda46
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda46 = {
  "MONT",
  false,
  "GGIO2$ST$Ind47",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda47
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda47 = {
  "MONT",
  false,
  "GGIO2$ST$Ind48",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda48
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda48 = {
  "MONT",
  false,
  "GGIO2$ST$Ind49",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda49
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda49 = {
  "MONT",
  false,
  "CCGR1$ST$CECtl",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda50
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda50 = {
  "MONT",
  false,
  "CCGR2$ST$CECtl",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda51
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda51 = {
  "MONT",
  false,
  "CCGR3$ST$CECtl",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda52
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda52 = {
  "MONT",
  false,
  "CCGR4$ST$CECtl",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda53
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda53 = {
  "MONT",
  false,
  "CCGR5$ST$CECtl",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda54
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda54 = {
  "MONT",
  false,
  "CCGR6$ST$CECtl",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda55
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda55 = {
  "MONT",
  false,
  "CCGR7$ST$CECtl",
  -1,
  NULL,
  NULL,
  &iedModelds_MONT_LLN0_dsState_fcda56
};

DataSetEntry iedModelds_MONT_LLN0_dsState_fcda56 = {
  "MONT",
  false,
  "CCGR8$ST$CECtl",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_MONT_LLN0_dsState = {
  "MONT",
  "LLN0$dsState",
  57,
  &iedModelds_MONT_LLN0_dsState_fcda0,
  NULL
};

LogicalDevice iedModel_MONT = {
    LogicalDeviceModelType,
    "MONT",
    (ModelNode*) &iedModel,
    NULL,
    (ModelNode*) &iedModel_MONT_LLN0
};

LogicalNode iedModel_MONT_LLN0 = {
    LogicalNodeModelType,
    "LLN0",
    (ModelNode*) &iedModel_MONT,
    (ModelNode*) &iedModel_MONT_LPHD1,
    (ModelNode*) &iedModel_MONT_LLN0_Mod,
};

DataObject iedModel_MONT_LLN0_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_MONT_LLN0,
    (ModelNode*) &iedModel_MONT_LLN0_Beh,
    (ModelNode*) &iedModel_MONT_LLN0_Mod_stVal,
    0
};

DataAttribute iedModel_MONT_LLN0_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_LLN0_Mod,
    (ModelNode*) &iedModel_MONT_LLN0_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_LLN0_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_LLN0_Mod,
    (ModelNode*) &iedModel_MONT_LLN0_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_LLN0_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_LLN0_Mod,
    (ModelNode*) &iedModel_MONT_LLN0_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_LLN0_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_LLN0_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_MONT_LLN0_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_MONT_LLN0,
    (ModelNode*) &iedModel_MONT_LLN0_Health,
    (ModelNode*) &iedModel_MONT_LLN0_Beh_stVal,
    0
};

DataAttribute iedModel_MONT_LLN0_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_LLN0_Beh,
    (ModelNode*) &iedModel_MONT_LLN0_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_LLN0_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_LLN0_Beh,
    (ModelNode*) &iedModel_MONT_LLN0_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_LLN0_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_LLN0_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_LLN0_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_MONT_LLN0,
    (ModelNode*) &iedModel_MONT_LLN0_NamPlt,
    (ModelNode*) &iedModel_MONT_LLN0_Health_stVal,
    0
};

DataAttribute iedModel_MONT_LLN0_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_LLN0_Health,
    (ModelNode*) &iedModel_MONT_LLN0_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_LLN0_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_LLN0_Health,
    (ModelNode*) &iedModel_MONT_LLN0_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_LLN0_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_LLN0_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_LLN0_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_MONT_LLN0,
    NULL,
    (ModelNode*) &iedModel_MONT_LLN0_NamPlt_vendor,
    0
};

DataAttribute iedModel_MONT_LLN0_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_MONT_LLN0_NamPlt,
    (ModelNode*) &iedModel_MONT_LLN0_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_LLN0_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_MONT_LLN0_NamPlt,
    (ModelNode*) &iedModel_MONT_LLN0_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_LLN0_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_LLN0_NamPlt,
    (ModelNode*) &iedModel_MONT_LLN0_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_LLN0_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_MONT_LLN0_NamPlt,
    (ModelNode*) &iedModel_MONT_LLN0_NamPlt_ldNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_LLN0_NamPlt_ldNs = {
    DataAttributeModelType,
    "ldNs",
    (ModelNode*) &iedModel_MONT_LLN0_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_MONT_LPHD1 = {
    LogicalNodeModelType,
    "LPHD1",
    (ModelNode*) &iedModel_MONT,
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_LPHD1_PhyNam,
};

DataObject iedModel_MONT_LPHD1_PhyNam = {
    DataObjectModelType,
    "PhyNam",
    (ModelNode*) &iedModel_MONT_LPHD1,
    (ModelNode*) &iedModel_MONT_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_MONT_LPHD1_PhyNam_vendor,
    0
};

DataAttribute iedModel_MONT_LPHD1_PhyNam_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_MONT_LPHD1_PhyNam,
    (ModelNode*) &iedModel_MONT_LPHD1_PhyNam_hwRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_LPHD1_PhyNam_hwRev = {
    DataAttributeModelType,
    "hwRev",
    (ModelNode*) &iedModel_MONT_LPHD1_PhyNam,
    (ModelNode*) &iedModel_MONT_LPHD1_PhyNam_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_LPHD1_PhyNam_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_MONT_LPHD1_PhyNam,
    (ModelNode*) &iedModel_MONT_LPHD1_PhyNam_serNum,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_LPHD1_PhyNam_serNum = {
    DataAttributeModelType,
    "serNum",
    (ModelNode*) &iedModel_MONT_LPHD1_PhyNam,
    (ModelNode*) &iedModel_MONT_LPHD1_PhyNam_model,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_LPHD1_PhyNam_model = {
    DataAttributeModelType,
    "model",
    (ModelNode*) &iedModel_MONT_LPHD1_PhyNam,
    (ModelNode*) &iedModel_MONT_LPHD1_PhyNam_location,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_LPHD1_PhyNam_location = {
    DataAttributeModelType,
    "location",
    (ModelNode*) &iedModel_MONT_LPHD1_PhyNam,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_LPHD1_PhyHealth = {
    DataObjectModelType,
    "PhyHealth",
    (ModelNode*) &iedModel_MONT_LPHD1,
    (ModelNode*) &iedModel_MONT_LPHD1_Proxy,
    (ModelNode*) &iedModel_MONT_LPHD1_PhyHealth_stVal,
    0
};

DataAttribute iedModel_MONT_LPHD1_PhyHealth_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_MONT_LPHD1_PhyHealth_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_LPHD1_PhyHealth_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_MONT_LPHD1_PhyHealth_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_LPHD1_PhyHealth_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_LPHD1_PhyHealth,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_LPHD1_Proxy = {
    DataObjectModelType,
    "Proxy",
    (ModelNode*) &iedModel_MONT_LPHD1,
    NULL,
    (ModelNode*) &iedModel_MONT_LPHD1_Proxy_stVal,
    0
};

DataAttribute iedModel_MONT_LPHD1_Proxy_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_LPHD1_Proxy,
    (ModelNode*) &iedModel_MONT_LPHD1_Proxy_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_LPHD1_Proxy_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_LPHD1_Proxy,
    (ModelNode*) &iedModel_MONT_LPHD1_Proxy_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_LPHD1_Proxy_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_LPHD1_Proxy,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

LogicalNode iedModel_MONT_SIML1 = {
    LogicalNodeModelType,
    "SIML1",
    (ModelNode*) &iedModel_MONT,
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_SIML1_Mod,
};

DataObject iedModel_MONT_SIML1_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_Beh,
    (ModelNode*) &iedModel_MONT_SIML1_Mod_stVal,
    0
};

DataAttribute iedModel_MONT_SIML1_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_SIML1_Mod,
    (ModelNode*) &iedModel_MONT_SIML1_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_Mod,
    (ModelNode*) &iedModel_MONT_SIML1_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_Mod,
    (ModelNode*) &iedModel_MONT_SIML1_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_SIML1_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_Health,
    (ModelNode*) &iedModel_MONT_SIML1_Beh_stVal,
    0
};

DataAttribute iedModel_MONT_SIML1_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_SIML1_Beh,
    (ModelNode*) &iedModel_MONT_SIML1_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_Beh,
    (ModelNode*) &iedModel_MONT_SIML1_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_NamPlt,
    (ModelNode*) &iedModel_MONT_SIML1_Health_stVal,
    0
};

DataAttribute iedModel_MONT_SIML1_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_SIML1_Health,
    (ModelNode*) &iedModel_MONT_SIML1_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_Health,
    (ModelNode*) &iedModel_MONT_SIML1_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp,
    (ModelNode*) &iedModel_MONT_SIML1_NamPlt_vendor,
    0
};

DataAttribute iedModel_MONT_SIML1_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_MONT_SIML1_NamPlt,
    (ModelNode*) &iedModel_MONT_SIML1_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_MONT_SIML1_NamPlt,
    (ModelNode*) &iedModel_MONT_SIML1_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_NamPlt,
    (ModelNode*) &iedModel_MONT_SIML1_NamPlt_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_NamPlt_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_NamPlt,
    (ModelNode*) &iedModel_MONT_SIML1_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_MONT_SIML1_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_Tmp = {
    DataObjectModelType,
    "Tmp",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_Tmp_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp_q,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_Tmp1 = {
    DataObjectModelType,
    "Tmp1",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_Tmp1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1_q,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_Tmp2 = {
    DataObjectModelType,
    "Tmp2",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_Tmp2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2_q,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_Tmp3 = {
    DataObjectModelType,
    "Tmp3",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_Tmp3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3_q,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_Tmp4 = {
    DataObjectModelType,
    "Tmp4",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_H2O,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_Tmp4_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4_q,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp4_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp4_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4,
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_Tmp4_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_Tmp4,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_H2O = {
    DataObjectModelType,
    "H2O",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_H2O1,
    (ModelNode*) &iedModel_MONT_SIML1_H2O_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_H2O_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_H2O,
    (ModelNode*) &iedModel_MONT_SIML1_H2O_q,
    (ModelNode*) &iedModel_MONT_SIML1_H2O_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_H2O_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_H2O,
    (ModelNode*) &iedModel_MONT_SIML1_H2O_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_H2O,
    (ModelNode*) &iedModel_MONT_SIML1_H2O_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_H2O,
    (ModelNode*) &iedModel_MONT_SIML1_H2O_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_H2O,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_H2O1 = {
    DataObjectModelType,
    "H2O1",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_H2O2,
    (ModelNode*) &iedModel_MONT_SIML1_H2O1_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_H2O1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_H2O1,
    (ModelNode*) &iedModel_MONT_SIML1_H2O1_q,
    (ModelNode*) &iedModel_MONT_SIML1_H2O1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_H2O1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_H2O1,
    (ModelNode*) &iedModel_MONT_SIML1_H2O1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_H2O1,
    (ModelNode*) &iedModel_MONT_SIML1_H2O1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_H2O1,
    (ModelNode*) &iedModel_MONT_SIML1_H2O1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_H2O1,
    (ModelNode*) &iedModel_MONT_SIML1_H2O1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_H2O1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_H2O2 = {
    DataObjectModelType,
    "H2O2",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_H2O3,
    (ModelNode*) &iedModel_MONT_SIML1_H2O2_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_H2O2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_H2O2,
    (ModelNode*) &iedModel_MONT_SIML1_H2O2_q,
    (ModelNode*) &iedModel_MONT_SIML1_H2O2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_H2O2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_H2O2,
    (ModelNode*) &iedModel_MONT_SIML1_H2O2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_H2O2,
    (ModelNode*) &iedModel_MONT_SIML1_H2O2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_H2O2,
    (ModelNode*) &iedModel_MONT_SIML1_H2O2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_H2O2,
    (ModelNode*) &iedModel_MONT_SIML1_H2O2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_H2O2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_H2O3 = {
    DataObjectModelType,
    "H2O3",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_InsAlm,
    (ModelNode*) &iedModel_MONT_SIML1_H2O3_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_H2O3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_H2O3,
    (ModelNode*) &iedModel_MONT_SIML1_H2O3_q,
    (ModelNode*) &iedModel_MONT_SIML1_H2O3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_H2O3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_H2O3,
    (ModelNode*) &iedModel_MONT_SIML1_H2O3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_H2O3,
    (ModelNode*) &iedModel_MONT_SIML1_H2O3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_H2O3,
    (ModelNode*) &iedModel_MONT_SIML1_H2O3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_H2O3,
    (ModelNode*) &iedModel_MONT_SIML1_H2O3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2O3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_H2O3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_InsAlm = {
    DataObjectModelType,
    "InsAlm",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_InsAlm_stVal,
    0
};

DataAttribute iedModel_MONT_SIML1_InsAlm_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_SIML1_InsAlm,
    (ModelNode*) &iedModel_MONT_SIML1_InsAlm_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_InsAlm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_InsAlm,
    (ModelNode*) &iedModel_MONT_SIML1_InsAlm_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_InsAlm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_InsAlm,
    (ModelNode*) &iedModel_MONT_SIML1_InsAlm_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_InsAlm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_InsAlm,
    (ModelNode*) &iedModel_MONT_SIML1_InsAlm_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_InsAlm_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_InsAlm,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_H2ppm = {
    DataObjectModelType,
    "H2ppm",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_H2ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm_q,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_H2ppm1 = {
    DataObjectModelType,
    "H2ppm1",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_H2ppm1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1_q,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_H2ppm2 = {
    DataObjectModelType,
    "H2ppm2",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_H2ppm2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2_q,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_H2ppm3 = {
    DataObjectModelType,
    "H2ppm3",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_H2ppm3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3_q,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_H2ppm3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_H2ppm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_N2ppm = {
    DataObjectModelType,
    "N2ppm",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_N2ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm_q,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_N2ppm1 = {
    DataObjectModelType,
    "N2ppm1",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_N2ppm1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1_q,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_N2ppm2 = {
    DataObjectModelType,
    "N2ppm2",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_N2ppm2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2_q,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_N2ppm3 = {
    DataObjectModelType,
    "N2ppm3",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_COppm,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_N2ppm3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3_q,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_N2ppm3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_N2ppm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_COppm = {
    DataObjectModelType,
    "COppm",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_COppm1,
    (ModelNode*) &iedModel_MONT_SIML1_COppm_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_COppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_COppm,
    (ModelNode*) &iedModel_MONT_SIML1_COppm_q,
    (ModelNode*) &iedModel_MONT_SIML1_COppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_COppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_COppm,
    (ModelNode*) &iedModel_MONT_SIML1_COppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_COppm,
    (ModelNode*) &iedModel_MONT_SIML1_COppm_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_COppm,
    (ModelNode*) &iedModel_MONT_SIML1_COppm_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_COppm,
    (ModelNode*) &iedModel_MONT_SIML1_COppm_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_COppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_COppm1 = {
    DataObjectModelType,
    "COppm1",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_COppm2,
    (ModelNode*) &iedModel_MONT_SIML1_COppm1_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_COppm1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_COppm1,
    (ModelNode*) &iedModel_MONT_SIML1_COppm1_q,
    (ModelNode*) &iedModel_MONT_SIML1_COppm1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_COppm1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_COppm1,
    (ModelNode*) &iedModel_MONT_SIML1_COppm1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_COppm1,
    (ModelNode*) &iedModel_MONT_SIML1_COppm1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_COppm1,
    (ModelNode*) &iedModel_MONT_SIML1_COppm1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_COppm1,
    (ModelNode*) &iedModel_MONT_SIML1_COppm1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_COppm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_COppm2 = {
    DataObjectModelType,
    "COppm2",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_COppm3,
    (ModelNode*) &iedModel_MONT_SIML1_COppm2_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_COppm2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_COppm2,
    (ModelNode*) &iedModel_MONT_SIML1_COppm2_q,
    (ModelNode*) &iedModel_MONT_SIML1_COppm2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_COppm2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_COppm2,
    (ModelNode*) &iedModel_MONT_SIML1_COppm2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_COppm2,
    (ModelNode*) &iedModel_MONT_SIML1_COppm2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_COppm2,
    (ModelNode*) &iedModel_MONT_SIML1_COppm2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_COppm2,
    (ModelNode*) &iedModel_MONT_SIML1_COppm2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_COppm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_COppm3 = {
    DataObjectModelType,
    "COppm3",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_COppm3_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_COppm3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_COppm3,
    (ModelNode*) &iedModel_MONT_SIML1_COppm3_q,
    (ModelNode*) &iedModel_MONT_SIML1_COppm3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_COppm3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_COppm3,
    (ModelNode*) &iedModel_MONT_SIML1_COppm3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_COppm3,
    (ModelNode*) &iedModel_MONT_SIML1_COppm3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_COppm3,
    (ModelNode*) &iedModel_MONT_SIML1_COppm3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_COppm3,
    (ModelNode*) &iedModel_MONT_SIML1_COppm3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_COppm3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_COppm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CO2ppm = {
    DataObjectModelType,
    "CO2ppm",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CO2ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm_q,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CO2ppm1 = {
    DataObjectModelType,
    "CO2ppm1",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CO2ppm1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1_q,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CO2ppm2 = {
    DataObjectModelType,
    "CO2ppm2",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CO2ppm2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2_q,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CO2ppm3 = {
    DataObjectModelType,
    "CO2ppm3",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CO2ppm3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3_q,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CO2ppm3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CO2ppm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CH4ppm = {
    DataObjectModelType,
    "CH4ppm",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CH4ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm_q,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CH4ppm1 = {
    DataObjectModelType,
    "CH4ppm1",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CH4ppm1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1_q,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CH4ppm2 = {
    DataObjectModelType,
    "CH4ppm2",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CH4ppm2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2_q,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CH4ppm3 = {
    DataObjectModelType,
    "CH4ppm3",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CH4ppm3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3_q,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CH4ppm3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CH4ppm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_C2H2ppm = {
    DataObjectModelType,
    "C2H2ppm",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_C2H2ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm_q,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_C2H2ppm1 = {
    DataObjectModelType,
    "C2H2ppm1",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_C2H2ppm1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1_q,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_C2H2ppm2 = {
    DataObjectModelType,
    "C2H2ppm2",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_C2H2ppm2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2_q,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_C2H2ppm3 = {
    DataObjectModelType,
    "C2H2ppm3",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_C2H2ppm3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3_q,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H2ppm3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_C2H2ppm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_C2H4ppm = {
    DataObjectModelType,
    "C2H4ppm",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_C2H4ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm_q,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_C2H4ppm1 = {
    DataObjectModelType,
    "C2H4ppm1",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_C2H4ppm1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1_q,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_C2H4ppm2 = {
    DataObjectModelType,
    "C2H4ppm2",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_C2H4ppm2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2_q,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_C2H4ppm3 = {
    DataObjectModelType,
    "C2H4ppm3",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_C2H4ppm3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3_q,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H4ppm3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_C2H4ppm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_C2H6ppm = {
    DataObjectModelType,
    "C2H6ppm",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_C2H6ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm_q,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_C2H6ppm1 = {
    DataObjectModelType,
    "C2H6ppm1",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_C2H6ppm1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1_q,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_C2H6ppm2 = {
    DataObjectModelType,
    "C2H6ppm2",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_C2H6ppm2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2_q,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_C2H6ppm3 = {
    DataObjectModelType,
    "C2H6ppm3",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_C2H6ppm3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3_q,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_C2H6ppm3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_C2H6ppm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_O2ppm = {
    DataObjectModelType,
    "O2ppm",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_O2ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm_q,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_O2ppm1 = {
    DataObjectModelType,
    "O2ppm1",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_O2ppm1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1_q,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_O2ppm2 = {
    DataObjectModelType,
    "O2ppm2",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_O2ppm2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2_q,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_O2ppm3 = {
    DataObjectModelType,
    "O2ppm3",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_O2ppm3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3_q,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3,
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_O2ppm3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_O2ppm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CmbuGas = {
    DataObjectModelType,
    "CmbuGas",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CmbuGas_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas_q,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CmbuGas1 = {
    DataObjectModelType,
    "CmbuGas1",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CmbuGas1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1_q,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CmbuGas2 = {
    DataObjectModelType,
    "CmbuGas2",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CmbuGas2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2_q,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CmbuGas3 = {
    DataObjectModelType,
    "CmbuGas3",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CmbuGas3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3_q,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CmbuGas4 = {
    DataObjectModelType,
    "CmbuGas4",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CmbuGas4_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4_q,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas4_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas4_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas4_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas4,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CmbuGas5 = {
    DataObjectModelType,
    "CmbuGas5",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CmbuGas5_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5_q,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas5_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas5_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas5_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas5,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CmbuGas6 = {
    DataObjectModelType,
    "CmbuGas6",
    (ModelNode*) &iedModel_MONT_SIML1,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CmbuGas6_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6_q,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas6_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas6_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas6_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas6,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_SIML1_CmbuGas7 = {
    DataObjectModelType,
    "CmbuGas7",
    (ModelNode*) &iedModel_MONT_SIML1,
    NULL,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7_mag,
    0
};

DataAttribute iedModel_MONT_SIML1_CmbuGas7_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7_q,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas7_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas7_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7,
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_SIML1_CmbuGas7_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_SIML1_CmbuGas7,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_MONT_GGIO1 = {
    LogicalNodeModelType,
    "GGIO1",
    (ModelNode*) &iedModel_MONT,
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO1_Mod,
};

DataObject iedModel_MONT_GGIO1_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_Beh,
    (ModelNode*) &iedModel_MONT_GGIO1_Mod_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_Mod,
    (ModelNode*) &iedModel_MONT_GGIO1_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_Mod,
    (ModelNode*) &iedModel_MONT_GGIO1_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_Mod,
    (ModelNode*) &iedModel_MONT_GGIO1_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_GGIO1_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_Health,
    (ModelNode*) &iedModel_MONT_GGIO1_Beh_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_Beh,
    (ModelNode*) &iedModel_MONT_GGIO1_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_Beh,
    (ModelNode*) &iedModel_MONT_GGIO1_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_NamPlt,
    (ModelNode*) &iedModel_MONT_GGIO1_Health_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_Health,
    (ModelNode*) &iedModel_MONT_GGIO1_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_Health,
    (ModelNode*) &iedModel_MONT_GGIO1_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1,
    (ModelNode*) &iedModel_MONT_GGIO1_NamPlt_vendor,
    0
};

DataAttribute iedModel_MONT_GGIO1_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_MONT_GGIO1_NamPlt,
    (ModelNode*) &iedModel_MONT_GGIO1_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_MONT_GGIO1_NamPlt,
    (ModelNode*) &iedModel_MONT_GGIO1_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_NamPlt,
    (ModelNode*) &iedModel_MONT_GGIO1_NamPlt_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_NamPlt_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_NamPlt,
    (ModelNode*) &iedModel_MONT_GGIO1_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_MONT_GGIO1_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn1 = {
    DataObjectModelType,
    "AnIn1",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn2 = {
    DataObjectModelType,
    "AnIn2",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn3 = {
    DataObjectModelType,
    "AnIn3",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn4 = {
    DataObjectModelType,
    "AnIn4",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn4_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn4_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn4_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn4_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn4,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn5 = {
    DataObjectModelType,
    "AnIn5",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn5_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn5_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn5_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn5_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn5,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn6 = {
    DataObjectModelType,
    "AnIn6",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn6_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn6_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn6_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn6_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn6,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn7 = {
    DataObjectModelType,
    "AnIn7",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn7_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn7_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn7_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn7_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn7,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn8 = {
    DataObjectModelType,
    "AnIn8",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn8_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn8_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn8_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn8_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn8,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn9 = {
    DataObjectModelType,
    "AnIn9",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn9_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn9_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn9_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn9_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn9,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn10 = {
    DataObjectModelType,
    "AnIn10",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn10_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn10_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn10_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn10_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn10,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn11 = {
    DataObjectModelType,
    "AnIn11",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn11_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn11_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn11_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn11_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn11,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn12 = {
    DataObjectModelType,
    "AnIn12",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn12_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn12_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn12_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn12_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn12_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn12_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn12_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn12,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn13 = {
    DataObjectModelType,
    "AnIn13",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn13_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn13_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn13_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn13_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn13_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn13_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn13_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn13,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn14 = {
    DataObjectModelType,
    "AnIn14",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn14_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn14_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn14_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn14_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn14_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn14_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn14_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn14,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn15 = {
    DataObjectModelType,
    "AnIn15",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn15_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn15_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn15_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn15_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn15_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn15_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn15_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn15,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn16 = {
    DataObjectModelType,
    "AnIn16",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn16_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn16_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn16_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn16_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn16_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn16_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn16_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn16,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn17 = {
    DataObjectModelType,
    "AnIn17",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn17_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn17_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn17_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn17_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn17_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn17_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn17_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn17,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn18 = {
    DataObjectModelType,
    "AnIn18",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn18_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn18_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn18_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn18_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn18_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn18_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn18_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn18,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn19 = {
    DataObjectModelType,
    "AnIn19",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn19_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn19_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn19_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn19_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn19_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn19_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn19_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn19,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn20 = {
    DataObjectModelType,
    "AnIn20",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn20_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn20_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn20_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn20_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn20_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn20_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn20_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn20,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn21 = {
    DataObjectModelType,
    "AnIn21",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn21_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn21_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn21_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn21_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn21_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn21_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn21_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn21,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn22 = {
    DataObjectModelType,
    "AnIn22",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn22_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn22_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn22_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn22_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn22_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn22_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn22_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn22,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn23 = {
    DataObjectModelType,
    "AnIn23",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn23_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn23_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn23_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn23_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn23_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn23_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn23_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn23,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn24 = {
    DataObjectModelType,
    "AnIn24",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn24_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn24_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn24_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn24_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn24_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn24_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn24_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn24,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn25 = {
    DataObjectModelType,
    "AnIn25",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn25_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn25_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn25_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn25_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn25_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn25_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn25_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn25,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn26 = {
    DataObjectModelType,
    "AnIn26",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn26_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn26_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn26_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn26_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn26_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn26_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn26_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn26,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn27 = {
    DataObjectModelType,
    "AnIn27",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn27_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn27_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn27_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn27_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn27_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn27_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn27_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn27,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn28 = {
    DataObjectModelType,
    "AnIn28",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn28_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn28_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn28_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn28_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn28_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn28_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn28_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn28,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn29 = {
    DataObjectModelType,
    "AnIn29",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn29_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn29_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn29_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn29_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn29_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn29_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn29_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn29,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn30 = {
    DataObjectModelType,
    "AnIn30",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn30_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn30_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn30_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn30_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn30_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn30_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn30_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn30,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn31 = {
    DataObjectModelType,
    "AnIn31",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn31_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn31_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn31_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn31_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn31_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn31_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn31_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn31,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn32 = {
    DataObjectModelType,
    "AnIn32",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn32_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn32_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn32_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn32_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn32_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn32_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn32_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn32,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn33 = {
    DataObjectModelType,
    "AnIn33",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn33_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn33_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn33_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn33_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn33_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn33_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn33_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn33,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn34 = {
    DataObjectModelType,
    "AnIn34",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn34_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn34_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn34_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn34_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn34_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn34_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn34_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn34,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn35 = {
    DataObjectModelType,
    "AnIn35",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn35_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn35_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn35_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn35_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn35_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn35_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn35_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn35,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn36 = {
    DataObjectModelType,
    "AnIn36",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn36_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn36_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn36_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn36_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn36_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn36_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn36_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn36,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn37 = {
    DataObjectModelType,
    "AnIn37",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn37_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn37_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn37_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn37_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn37_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn37_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn37_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn37,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn38 = {
    DataObjectModelType,
    "AnIn38",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn38_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn38_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn38_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn38_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn38_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn38_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn38_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn38,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn39 = {
    DataObjectModelType,
    "AnIn39",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn39_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn39_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn39_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn39_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn39_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn39_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn39_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn39,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn40 = {
    DataObjectModelType,
    "AnIn40",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn40_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn40_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn40_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn40_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn40_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn40_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn40_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn40,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn41 = {
    DataObjectModelType,
    "AnIn41",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn41_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn41_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn41_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn41_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn41_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn41_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn41_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn41,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn42 = {
    DataObjectModelType,
    "AnIn42",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn42_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn42_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn42_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn42_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn42_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn42_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn42_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn42,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn43 = {
    DataObjectModelType,
    "AnIn43",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn43_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn43_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn43_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn43_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn43_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn43_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn43_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn43,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn44 = {
    DataObjectModelType,
    "AnIn44",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn44_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn44_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn44_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn44_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn44_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn44_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn44_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn44,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn45 = {
    DataObjectModelType,
    "AnIn45",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn45_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn45_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn45_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn45_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn45_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn45_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn45_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn45,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn46 = {
    DataObjectModelType,
    "AnIn46",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn46_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn46_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn46_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn46_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn46_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn46_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn46_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn46,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn47 = {
    DataObjectModelType,
    "AnIn47",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn47_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn47_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn47_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn47_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn47_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn47_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn47_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn47,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn48 = {
    DataObjectModelType,
    "AnIn48",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn48_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn48_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn48_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn48_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn48_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn48_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn48_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn48,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn49 = {
    DataObjectModelType,
    "AnIn49",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn49_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn49_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn49_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn49_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn49_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn49_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn49_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn49,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn50 = {
    DataObjectModelType,
    "AnIn50",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn50_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn50_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn50_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn50_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn50_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn50_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn50_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn50,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn51 = {
    DataObjectModelType,
    "AnIn51",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn51_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn51_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn51_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn51_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn51_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn51_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn51_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn51,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn52 = {
    DataObjectModelType,
    "AnIn52",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn52_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn52_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn52_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn52_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn52_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn52_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn52_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn52,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn53 = {
    DataObjectModelType,
    "AnIn53",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn53_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn53_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn53_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn53_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn53_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn53_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn53_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn53,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn54 = {
    DataObjectModelType,
    "AnIn54",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn54_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn54_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn54_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn54_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn54_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn54_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn54_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn54,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn55 = {
    DataObjectModelType,
    "AnIn55",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn55_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn55_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn55_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn55_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn55_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn55_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn55_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn55,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn56 = {
    DataObjectModelType,
    "AnIn56",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn56_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn56_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn56_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn56_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn56_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn56_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn56_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn56,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn57 = {
    DataObjectModelType,
    "AnIn57",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn57_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn57_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn57_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn57_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn57_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn57_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn57_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn57,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn58 = {
    DataObjectModelType,
    "AnIn58",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn58_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn58_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn58_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn58_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn58_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn58_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn58_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn58,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn59 = {
    DataObjectModelType,
    "AnIn59",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn59_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn59_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn59_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn59_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn59_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn59_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn59_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn59,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn60 = {
    DataObjectModelType,
    "AnIn60",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn60_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn60_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn60_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn60_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn60_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn60_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn60_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn60,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn61 = {
    DataObjectModelType,
    "AnIn61",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn61_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn61_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn61_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn61_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn61_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn61_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn61_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn61,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn62 = {
    DataObjectModelType,
    "AnIn62",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn62_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn62_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn62_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn62_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn62_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn62_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn62_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn62,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn63 = {
    DataObjectModelType,
    "AnIn63",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn63_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn63_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn63_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn63_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn63_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn63_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn63_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn63,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn64 = {
    DataObjectModelType,
    "AnIn64",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn64_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn64_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn64_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn64_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn64_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn64_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn64_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn64,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn65 = {
    DataObjectModelType,
    "AnIn65",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn65_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn65_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn65_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn65_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn65_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn65_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn65_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn65,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn66 = {
    DataObjectModelType,
    "AnIn66",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn66_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn66_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn66_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn66_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn66_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn66_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn66_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn66,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn67 = {
    DataObjectModelType,
    "AnIn67",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn67_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn67_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn67_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn67_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn67_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn67_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn67_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn67,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn68 = {
    DataObjectModelType,
    "AnIn68",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn68_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn68_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn68_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn68_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn68_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn68_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn68_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn68,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn69 = {
    DataObjectModelType,
    "AnIn69",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn69_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn69_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn69_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn69_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn69_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn69_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn69_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn69,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn70 = {
    DataObjectModelType,
    "AnIn70",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn70_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn70_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn70_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn70_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn70_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn70_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn70_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn70,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn71 = {
    DataObjectModelType,
    "AnIn71",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn71_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn71_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn71_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn71_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn71_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn71_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn71_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn71,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn72 = {
    DataObjectModelType,
    "AnIn72",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn72_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn72_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn72_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn72_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn72_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn72_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn72_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn72,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn73 = {
    DataObjectModelType,
    "AnIn73",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn73_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn73_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn73_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn73_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn73_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn73_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn73_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn73,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn74 = {
    DataObjectModelType,
    "AnIn74",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn74_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn74_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn74_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn74_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn74_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn74_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn74_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn74,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn75 = {
    DataObjectModelType,
    "AnIn75",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn75_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn75_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn75_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn75_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn75_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn75_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn75_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn75,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn76 = {
    DataObjectModelType,
    "AnIn76",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn76_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn76_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn76_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn76_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn76_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn76_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn76_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn76,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn77 = {
    DataObjectModelType,
    "AnIn77",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn77_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn77_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn77_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn77_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn77_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn77_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn77_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn77,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn78 = {
    DataObjectModelType,
    "AnIn78",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn78_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn78_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn78_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn78_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn78_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn78_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn78_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn78,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn79 = {
    DataObjectModelType,
    "AnIn79",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn79_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn79_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn79_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn79_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn79_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn79_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn79_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn79,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn80 = {
    DataObjectModelType,
    "AnIn80",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn80_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn80_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn80_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn80_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn80_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn80_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn80_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn80,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn81 = {
    DataObjectModelType,
    "AnIn81",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn81_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn81_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn81_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn81_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn81_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn81_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn81_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn81,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn82 = {
    DataObjectModelType,
    "AnIn82",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn82_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn82_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn82_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn82_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn82_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn82_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn82_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn82,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn83 = {
    DataObjectModelType,
    "AnIn83",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn83_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn83_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn83_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn83_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn83_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn83_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn83_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn83,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn84 = {
    DataObjectModelType,
    "AnIn84",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn84_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn84_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn84_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn84_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn84_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn84_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn84_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn84,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn85 = {
    DataObjectModelType,
    "AnIn85",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn85_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn85_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn85_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn85_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn85_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn85_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn85_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn85,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn86 = {
    DataObjectModelType,
    "AnIn86",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn86_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn86_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn86_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn86_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn86_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn86_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn86_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn86,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn87 = {
    DataObjectModelType,
    "AnIn87",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn87_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn87_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn87_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn87_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn87_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn87_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn87_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn87,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn88 = {
    DataObjectModelType,
    "AnIn88",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn88_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn88_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn88_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn88_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn88_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn88_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn88_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn88,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn89 = {
    DataObjectModelType,
    "AnIn89",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn89_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn89_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn89_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn89_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn89_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn89_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn89_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn89,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn90 = {
    DataObjectModelType,
    "AnIn90",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn90_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn90_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn90_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn90_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn90_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn90_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn90_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn90,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn91 = {
    DataObjectModelType,
    "AnIn91",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn91_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn91_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn91_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn91_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn91_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn91_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn91_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn91,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn92 = {
    DataObjectModelType,
    "AnIn92",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn92_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn92_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn92_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn92_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn92_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn92_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn92_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn92,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn93 = {
    DataObjectModelType,
    "AnIn93",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn93_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn93_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn93_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn93_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn93_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn93_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn93_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn93,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn94 = {
    DataObjectModelType,
    "AnIn94",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn94_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn94_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn94_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn94_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn94_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn94_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn94_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn94,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn95 = {
    DataObjectModelType,
    "AnIn95",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn95_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn95_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn95_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn95_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn95_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn95_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn95_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn95,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn96 = {
    DataObjectModelType,
    "AnIn96",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn96_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn96_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn96_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn96_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn96_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn96_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn96_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn96,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn97 = {
    DataObjectModelType,
    "AnIn97",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn97_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn97_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn97_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn97_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn97_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn97_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn97_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn97,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn98 = {
    DataObjectModelType,
    "AnIn98",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn98_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn98_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn98_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn98_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn98_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn98_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn98_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn98,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn99 = {
    DataObjectModelType,
    "AnIn99",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn99_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn99_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn99_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn99_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn99_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn99_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn99_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn99,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn100 = {
    DataObjectModelType,
    "AnIn100",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn100_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn100_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn100_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn100_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn100_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn100_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn100_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn100,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn101 = {
    DataObjectModelType,
    "AnIn101",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn101_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn101_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn101_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn101_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn101_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn101_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn101_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn101,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn102 = {
    DataObjectModelType,
    "AnIn102",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn102_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn102_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn102_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn102_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn102_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn102_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn102_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn102,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn103 = {
    DataObjectModelType,
    "AnIn103",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn103_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn103_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn103_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn103_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn103_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn103_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn103_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn103,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn104 = {
    DataObjectModelType,
    "AnIn104",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn104_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn104_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn104_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn104_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn104_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn104_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn104_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn104,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn105 = {
    DataObjectModelType,
    "AnIn105",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn105_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn105_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn105_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn105_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn105_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn105_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn105_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn105,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn106 = {
    DataObjectModelType,
    "AnIn106",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn106_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn106_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn106_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn106_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn106_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn106_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn106_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn106,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn107 = {
    DataObjectModelType,
    "AnIn107",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn107_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn107_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn107_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn107_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn107_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn107_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn107_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn107,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn108 = {
    DataObjectModelType,
    "AnIn108",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn108_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn108_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn108_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn108_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn108_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn108_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn108_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn108,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn109 = {
    DataObjectModelType,
    "AnIn109",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn109_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn109_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn109_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn109_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn109_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn109_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn109_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn109,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn110 = {
    DataObjectModelType,
    "AnIn110",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn110_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn110_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn110_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn110_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn110_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn110_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn110_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn110,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn111 = {
    DataObjectModelType,
    "AnIn111",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn111_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn111_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn111_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn111_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn111_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn111_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn111_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn111,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn112 = {
    DataObjectModelType,
    "AnIn112",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn112_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn112_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn112_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn112_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn112_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn112_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn112_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn112,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn113 = {
    DataObjectModelType,
    "AnIn113",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn113_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn113_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn113_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn113_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn113_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn113_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn113_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn113,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn114 = {
    DataObjectModelType,
    "AnIn114",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn114_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn114_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn114_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn114_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn114_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn114_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn114_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn114,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn115 = {
    DataObjectModelType,
    "AnIn115",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn115_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn115_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn115_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn115_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn115_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn115_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn115_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn115,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn116 = {
    DataObjectModelType,
    "AnIn116",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn116_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn116_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn116_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn116_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn116_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn116_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn116_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn116,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn117 = {
    DataObjectModelType,
    "AnIn117",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn117_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn117_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn117_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn117_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn117_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn117_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn117_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn117,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn118 = {
    DataObjectModelType,
    "AnIn118",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn118_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn118_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn118_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn118_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn118_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn118_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn118_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn118,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn119 = {
    DataObjectModelType,
    "AnIn119",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn119_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn119_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn119_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn119_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn119_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn119_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn119_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn119,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn120 = {
    DataObjectModelType,
    "AnIn120",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn120_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn120_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn120_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn120_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn120_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn120_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn120_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn120,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_AnIn121 = {
    DataObjectModelType,
    "AnIn121",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn1,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121_mag,
    0
};

DataAttribute iedModel_MONT_GGIO1_AnIn121_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121_q,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn121_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn121_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn121_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn121_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn121_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121,
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_AnIn121_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_AnIn121,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn1 = {
    DataObjectModelType,
    "IntIn1",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn2,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn1_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn2 = {
    DataObjectModelType,
    "IntIn2",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn3,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn2_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn2,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn2,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn2,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn2,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn2,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn3 = {
    DataObjectModelType,
    "IntIn3",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn4,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn3_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn3,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn3,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn3,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn3,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn3,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn4 = {
    DataObjectModelType,
    "IntIn4",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn5,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn4_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn4,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn4,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn4,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn4,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn4_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn4_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn4,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn4_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn4_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn4,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn5 = {
    DataObjectModelType,
    "IntIn5",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn6,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn5_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn5,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn5,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn5,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn5,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn5_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn5_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn5,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn5_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn5_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn5,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn6 = {
    DataObjectModelType,
    "IntIn6",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn7,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn6_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn6,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn6,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn6,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn6,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn6_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn6_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn6,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn6_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn6_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn6,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn7 = {
    DataObjectModelType,
    "IntIn7",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn8,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn7_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn7,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn7,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn7,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn7,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn7_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn7_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn7,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn7_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn7_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn7,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn8 = {
    DataObjectModelType,
    "IntIn8",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn9,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn8_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn8,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn8,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn8,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn8,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn8_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn8_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn8,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn8_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn8_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn8,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn9 = {
    DataObjectModelType,
    "IntIn9",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn10,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn9_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn9,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn9,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn9,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn9,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn9_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn9_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn9,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn9_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn9_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn9,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn10 = {
    DataObjectModelType,
    "IntIn10",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn11,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn10_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn10,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn10,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn10,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn10,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn10_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn10_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn10,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn10_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn10_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn10,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn11 = {
    DataObjectModelType,
    "IntIn11",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn12,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn11_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn11,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn11,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn11,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn11_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn11,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn11_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn11_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn11,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn11_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn11_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn11,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn12 = {
    DataObjectModelType,
    "IntIn12",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn13,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn12_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn12_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn12,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn12_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn12_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn12,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn12_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn12_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn12,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn12_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn12_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn12,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn12_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn12_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn12,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn12_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn12_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn12,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn13 = {
    DataObjectModelType,
    "IntIn13",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn14,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn13_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn13_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn13,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn13_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn13_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn13,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn13_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn13_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn13,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn13_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn13_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn13,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn13_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn13_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn13,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn13_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn13_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn13,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn14 = {
    DataObjectModelType,
    "IntIn14",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn15,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn14_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn14_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn14,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn14_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn14_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn14,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn14_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn14_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn14,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn14_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn14_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn14,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn14_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn14_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn14,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn14_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn14_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn14,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn15 = {
    DataObjectModelType,
    "IntIn15",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn16,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn15_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn15_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn15,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn15_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn15_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn15,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn15_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn15_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn15,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn15_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn15_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn15,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn15_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn15_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn15,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn15_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn15_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn15,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn16 = {
    DataObjectModelType,
    "IntIn16",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn17,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn16_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn16_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn16,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn16_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn16_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn16,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn16_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn16_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn16,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn16_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn16_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn16,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn16_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn16_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn16,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn16_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn16_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn16,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn17 = {
    DataObjectModelType,
    "IntIn17",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn18,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn17_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn17_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn17,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn17_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn17_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn17,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn17_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn17_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn17,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn17_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn17_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn17,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn17_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn17_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn17,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn17_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn17_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn17,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn18 = {
    DataObjectModelType,
    "IntIn18",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn19,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn18_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn18_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn18,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn18_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn18_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn18,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn18_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn18_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn18,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn18_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn18_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn18,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn18_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn18_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn18,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn18_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn18_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn18,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn19 = {
    DataObjectModelType,
    "IntIn19",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn20,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn19_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn19_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn19,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn19_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn19_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn19,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn19_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn19_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn19,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn19_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn19_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn19,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn19_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn19_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn19,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn19_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn19_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn19,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn20 = {
    DataObjectModelType,
    "IntIn20",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn21,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn20_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn20_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn20,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn20_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn20_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn20,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn20_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn20_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn20,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn20_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn20_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn20,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn20_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn20_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn20,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn20_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn20_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn20,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn21 = {
    DataObjectModelType,
    "IntIn21",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn22,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn21_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn21_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn21,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn21_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn21_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn21,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn21_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn21_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn21,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn21_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn21_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn21,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn21_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn21_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn21,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn21_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn21_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn21,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn22 = {
    DataObjectModelType,
    "IntIn22",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn23,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn22_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn22_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn22,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn22_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn22_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn22,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn22_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn22_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn22,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn22_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn22_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn22,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn22_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn22_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn22,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn22_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn22_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn22,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn23 = {
    DataObjectModelType,
    "IntIn23",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn24,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn23_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn23_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn23,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn23_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn23_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn23,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn23_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn23_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn23,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn23_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn23_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn23,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn23_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn23_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn23,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn23_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn23_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn23,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn24 = {
    DataObjectModelType,
    "IntIn24",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn25,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn24_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn24_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn24,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn24_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn24_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn24,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn24_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn24_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn24,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn24_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn24_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn24,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn24_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn24_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn24,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn24_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn24_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn24,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn25 = {
    DataObjectModelType,
    "IntIn25",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn26,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn25_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn25_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn25,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn25_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn25_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn25,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn25_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn25_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn25,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn25_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn25_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn25,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn25_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn25_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn25,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn25_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn25_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn25,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn26 = {
    DataObjectModelType,
    "IntIn26",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn27,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn26_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn26_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn26,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn26_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn26_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn26,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn26_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn26_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn26,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn26_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn26_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn26,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn26_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn26_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn26,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn26_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn26_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn26,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn27 = {
    DataObjectModelType,
    "IntIn27",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn28,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn27_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn27_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn27,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn27_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn27_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn27,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn27_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn27_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn27,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn27_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn27_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn27,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn27_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn27_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn27,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn27_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn27_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn27,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn28 = {
    DataObjectModelType,
    "IntIn28",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn29,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn28_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn28_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn28,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn28_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn28_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn28,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn28_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn28_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn28,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn28_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn28_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn28,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn28_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn28_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn28,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn28_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn28_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn28,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn29 = {
    DataObjectModelType,
    "IntIn29",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn30,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn29_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn29_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn29,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn29_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn29_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn29,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn29_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn29_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn29,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn29_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn29_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn29,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn29_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn29_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn29,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn29_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn29_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn29,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn30 = {
    DataObjectModelType,
    "IntIn30",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn31,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn30_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn30_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn30,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn30_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn30_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn30,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn30_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn30_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn30,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn30_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn30_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn30,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn30_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn30_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn30,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn30_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn30_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn30,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn31 = {
    DataObjectModelType,
    "IntIn31",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn32,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn31_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn31_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn31,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn31_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn31_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn31,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn31_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn31_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn31,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn31_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn31_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn31,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn31_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn31_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn31,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn31_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn31_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn31,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn32 = {
    DataObjectModelType,
    "IntIn32",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn33,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn32_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn32_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn32,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn32_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn32_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn32,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn32_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn32_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn32,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn32_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn32_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn32,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn32_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn32_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn32,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn32_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn32_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn32,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn33 = {
    DataObjectModelType,
    "IntIn33",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn34,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn33_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn33_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn33,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn33_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn33_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn33,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn33_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn33_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn33,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn33_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn33_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn33,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn33_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn33_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn33,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn33_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn33_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn33,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn34 = {
    DataObjectModelType,
    "IntIn34",
    (ModelNode*) &iedModel_MONT_GGIO1,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn35,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn34_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn34_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn34,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn34_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn34_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn34,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn34_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn34_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn34,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn34_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn34_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn34,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn34_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn34_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn34,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn34_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn34_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn34,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO1_IntIn35 = {
    DataObjectModelType,
    "IntIn35",
    (ModelNode*) &iedModel_MONT_GGIO1,
    NULL,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn35_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO1_IntIn35_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn35,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn35_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn35_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn35,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn35_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn35_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn35,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn35_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn35_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn35,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn35_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn35_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn35,
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn35_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO1_IntIn35_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO1_IntIn35,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_MONT_GGIO2 = {
    LogicalNodeModelType,
    "GGIO2",
    (ModelNode*) &iedModel_MONT,
    (ModelNode*) &iedModel_MONT_CCGR1,
    (ModelNode*) &iedModel_MONT_GGIO2_Mod,
};

DataObject iedModel_MONT_GGIO2_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Beh,
    (ModelNode*) &iedModel_MONT_GGIO2_Mod_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Mod,
    (ModelNode*) &iedModel_MONT_GGIO2_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Mod,
    (ModelNode*) &iedModel_MONT_GGIO2_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Mod,
    (ModelNode*) &iedModel_MONT_GGIO2_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_GGIO2_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Health,
    (ModelNode*) &iedModel_MONT_GGIO2_Beh_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Beh,
    (ModelNode*) &iedModel_MONT_GGIO2_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Beh,
    (ModelNode*) &iedModel_MONT_GGIO2_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_NamPlt,
    (ModelNode*) &iedModel_MONT_GGIO2_Health_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Health,
    (ModelNode*) &iedModel_MONT_GGIO2_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Health,
    (ModelNode*) &iedModel_MONT_GGIO2_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm1,
    (ModelNode*) &iedModel_MONT_GGIO2_NamPlt_vendor,
    0
};

DataAttribute iedModel_MONT_GGIO2_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_MONT_GGIO2_NamPlt,
    (ModelNode*) &iedModel_MONT_GGIO2_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_MONT_GGIO2_NamPlt,
    (ModelNode*) &iedModel_MONT_GGIO2_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_NamPlt,
    (ModelNode*) &iedModel_MONT_GGIO2_NamPlt_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_NamPlt_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_NamPlt,
    (ModelNode*) &iedModel_MONT_GGIO2_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_MONT_GGIO2_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm1 = {
    DataObjectModelType,
    "Alm1",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm1_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm1,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm1,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm1,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm1,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm1,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm2 = {
    DataObjectModelType,
    "Alm2",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm3,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm2_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm3 = {
    DataObjectModelType,
    "Alm3",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm4,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm3_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm3,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm3,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm3,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm3,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm3,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm4 = {
    DataObjectModelType,
    "Alm4",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm5,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm4_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm4,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm4,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm4,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm4,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm4_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm4_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm4,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm4_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm4_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm4,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm5 = {
    DataObjectModelType,
    "Alm5",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm6,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm5_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm5,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm5,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm5,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm5,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm5_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm5_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm5,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm5_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm5_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm5,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm6 = {
    DataObjectModelType,
    "Alm6",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm7,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm6_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm6,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm6,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm6,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm6,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm6_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm6_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm6,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm6_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm6_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm6,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm7 = {
    DataObjectModelType,
    "Alm7",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm8,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm7_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm7,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm7,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm7,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm7,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm7_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm7_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm7,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm7_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm7_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm7,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm8 = {
    DataObjectModelType,
    "Alm8",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm9,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm8_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm8,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm8,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm8,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm8,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm8_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm8_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm8,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm8_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm8_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm8,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm9 = {
    DataObjectModelType,
    "Alm9",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm10,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm9_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm9,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm9,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm9,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm9,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm9_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm9_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm9,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm9_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm9_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm9,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm10 = {
    DataObjectModelType,
    "Alm10",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm11,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm10_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm10,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm10,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm10,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm10,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm10_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm10_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm10,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm10_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm10_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm10,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm11 = {
    DataObjectModelType,
    "Alm11",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm12,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm11_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm11,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm11,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm11,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm11_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm11,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm11_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm11_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm11,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm11_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm11_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm11,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm12 = {
    DataObjectModelType,
    "Alm12",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm13,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm12_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm12_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm12,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm12_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm12_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm12,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm12_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm12_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm12,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm12_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm12_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm12,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm12_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm12_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm12,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm12_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm12_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm12,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm13 = {
    DataObjectModelType,
    "Alm13",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm14,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm13_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm13_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm13,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm13_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm13_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm13,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm13_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm13_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm13,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm13_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm13_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm13,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm13_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm13_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm13,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm13_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm13_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm13,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm14 = {
    DataObjectModelType,
    "Alm14",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm15,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm14_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm14_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm14,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm14_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm14_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm14,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm14_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm14_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm14,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm14_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm14_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm14,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm14_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm14_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm14,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm14_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm14_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm14,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm15 = {
    DataObjectModelType,
    "Alm15",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm16,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm15_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm15_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm15,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm15_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm15_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm15,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm15_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm15_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm15,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm15_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm15_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm15,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm15_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm15_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm15,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm15_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm15_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm15,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm16 = {
    DataObjectModelType,
    "Alm16",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm17,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm16_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm16_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm16,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm16_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm16_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm16,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm16_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm16_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm16,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm16_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm16_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm16,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm16_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm16_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm16,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm16_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm16_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm16,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm17 = {
    DataObjectModelType,
    "Alm17",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm18,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm17_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm17_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm17,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm17_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm17_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm17,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm17_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm17_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm17,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm17_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm17_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm17,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm17_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm17_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm17,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm17_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm17_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm17,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm18 = {
    DataObjectModelType,
    "Alm18",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm19,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm18_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm18_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm18,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm18_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm18_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm18,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm18_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm18_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm18,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm18_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm18_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm18,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm18_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm18_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm18,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm18_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm18_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm18,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm19 = {
    DataObjectModelType,
    "Alm19",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm20,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm19_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm19_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm19,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm19_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm19_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm19,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm19_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm19_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm19,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm19_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm19_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm19,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm19_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm19_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm19,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm19_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm19_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm19,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm20 = {
    DataObjectModelType,
    "Alm20",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm21,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm20_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm20_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm20,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm20_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm20_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm20,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm20_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm20_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm20,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm20_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm20_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm20,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm20_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm20_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm20,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm20_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm20_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm20,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm21 = {
    DataObjectModelType,
    "Alm21",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm22,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm21_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm21_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm21,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm21_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm21_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm21,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm21_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm21_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm21,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm21_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm21_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm21,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm21_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm21_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm21,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm21_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm21_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm21,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm22 = {
    DataObjectModelType,
    "Alm22",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm23,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm22_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm22_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm22,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm22_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm22_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm22,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm22_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm22_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm22,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm22_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm22_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm22,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm22_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm22_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm22,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm22_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm22_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm22,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm23 = {
    DataObjectModelType,
    "Alm23",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm24,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm23_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm23_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm23,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm23_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm23_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm23,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm23_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm23_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm23,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm23_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm23_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm23,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm23_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm23_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm23,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm23_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm23_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm23,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm24 = {
    DataObjectModelType,
    "Alm24",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm25,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm24_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm24_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm24,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm24_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm24_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm24,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm24_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm24_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm24,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm24_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm24_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm24,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm24_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm24_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm24,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm24_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm24_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm24,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm25 = {
    DataObjectModelType,
    "Alm25",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm26,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm25_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm25_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm25,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm25_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm25_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm25,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm25_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm25_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm25,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm25_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm25_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm25,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm25_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm25_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm25,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm25_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm25_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm25,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm26 = {
    DataObjectModelType,
    "Alm26",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm27,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm26_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm26_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm26,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm26_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm26_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm26,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm26_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm26_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm26,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm26_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm26_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm26,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm26_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm26_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm26,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm26_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm26_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm26,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm27 = {
    DataObjectModelType,
    "Alm27",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm28,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm27_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm27_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm27,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm27_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm27_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm27,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm27_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm27_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm27,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm27_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm27_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm27,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm27_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm27_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm27,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm27_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm27_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm27,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm28 = {
    DataObjectModelType,
    "Alm28",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm29,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm28_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm28_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm28,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm28_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm28_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm28,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm28_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm28_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm28,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm28_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm28_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm28,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm28_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm28_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm28,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm28_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm28_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm28,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm29 = {
    DataObjectModelType,
    "Alm29",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm30,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm29_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm29_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm29,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm29_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm29_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm29,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm29_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm29_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm29,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm29_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm29_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm29,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm29_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm29_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm29,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm29_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm29_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm29,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm30 = {
    DataObjectModelType,
    "Alm30",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm31,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm30_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm30_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm30,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm30_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm30_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm30,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm30_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm30_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm30,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm30_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm30_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm30,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm30_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm30_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm30,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm30_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm30_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm30,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm31 = {
    DataObjectModelType,
    "Alm31",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm32,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm31_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm31_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm31,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm31_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm31_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm31,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm31_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm31_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm31,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm31_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm31_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm31,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm31_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm31_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm31,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm31_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm31_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm31,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm32 = {
    DataObjectModelType,
    "Alm32",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm33,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm32_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm32_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm32,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm32_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm32_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm32,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm32_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm32_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm32,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm32_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm32_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm32,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm32_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm32_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm32,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm32_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm32_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm32,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm33 = {
    DataObjectModelType,
    "Alm33",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm34,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm33_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm33_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm33,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm33_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm33_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm33,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm33_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm33_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm33,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm33_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm33_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm33,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm33_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm33_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm33,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm33_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm33_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm33,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm34 = {
    DataObjectModelType,
    "Alm34",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm35,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm34_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm34_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm34,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm34_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm34_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm34,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm34_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm34_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm34,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm34_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm34_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm34,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm34_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm34_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm34,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm34_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm34_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm34,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm35 = {
    DataObjectModelType,
    "Alm35",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm36,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm35_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm35_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm35,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm35_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm35_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm35,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm35_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm35_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm35,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm35_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm35_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm35,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm35_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm35_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm35,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm35_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm35_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm35,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm36 = {
    DataObjectModelType,
    "Alm36",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm37,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm36_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm36_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm36,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm36_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm36_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm36,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm36_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm36_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm36,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm36_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm36_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm36,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm36_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm36_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm36,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm36_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm36_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm36,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm37 = {
    DataObjectModelType,
    "Alm37",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm38,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm37_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm37_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm37,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm37_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm37_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm37,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm37_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm37_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm37,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm37_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm37_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm37,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm37_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm37_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm37,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm37_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm37_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm37,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm38 = {
    DataObjectModelType,
    "Alm38",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm39,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm38_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm38_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm38,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm38_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm38_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm38,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm38_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm38_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm38,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm38_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm38_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm38,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm38_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm38_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm38,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm38_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm38_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm38,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm39 = {
    DataObjectModelType,
    "Alm39",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm40,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm39_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm39_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm39,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm39_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm39_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm39,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm39_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm39_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm39,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm39_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm39_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm39,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm39_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm39_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm39,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm39_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm39_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm39,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm40 = {
    DataObjectModelType,
    "Alm40",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm41,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm40_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm40_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm40,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm40_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm40_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm40,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm40_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm40_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm40,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm40_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm40_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm40,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm40_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm40_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm40,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm40_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm40_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm40,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm41 = {
    DataObjectModelType,
    "Alm41",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm42,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm41_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm41_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm41,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm41_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm41_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm41,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm41_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm41_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm41,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm41_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm41_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm41,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm41_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm41_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm41,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm41_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm41_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm41,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm42 = {
    DataObjectModelType,
    "Alm42",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm43,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm42_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm42_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm42,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm42_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm42_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm42,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm42_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm42_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm42,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm42_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm42_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm42,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm42_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm42_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm42,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm42_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm42_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm42,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm43 = {
    DataObjectModelType,
    "Alm43",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm44,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm43_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm43_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm43,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm43_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm43_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm43,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm43_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm43_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm43,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm43_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm43_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm43,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm43_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm43_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm43,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm43_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm43_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm43,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm44 = {
    DataObjectModelType,
    "Alm44",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm45,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm44_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm44_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm44,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm44_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm44_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm44,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm44_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm44_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm44,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm44_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm44_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm44,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm44_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm44_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm44,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm44_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm44_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm44,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm45 = {
    DataObjectModelType,
    "Alm45",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm46,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm45_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm45_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm45,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm45_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm45_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm45,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm45_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm45_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm45,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm45_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm45_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm45,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm45_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm45_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm45,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm45_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm45_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm45,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm46 = {
    DataObjectModelType,
    "Alm46",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm47,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm46_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm46_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm46,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm46_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm46_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm46,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm46_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm46_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm46,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm46_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm46_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm46,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm46_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm46_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm46,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm46_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm46_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm46,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm47 = {
    DataObjectModelType,
    "Alm47",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm48,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm47_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm47_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm47,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm47_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm47_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm47,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm47_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm47_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm47,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm47_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm47_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm47,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm47_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm47_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm47,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm47_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm47_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm47,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm48 = {
    DataObjectModelType,
    "Alm48",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm49,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm48_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm48_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm48,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm48_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm48_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm48,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm48_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm48_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm48,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm48_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm48_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm48,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm48_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm48_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm48,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm48_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm48_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm48,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm49 = {
    DataObjectModelType,
    "Alm49",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm50,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm49_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm49_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm49,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm49_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm49_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm49,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm49_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm49_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm49,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm49_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm49_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm49,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm49_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm49_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm49,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm49_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm49_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm49,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Alm50 = {
    DataObjectModelType,
    "Alm50",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind1,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm50_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Alm50_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm50,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm50_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm50_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm50,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm50_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm50_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm50,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm50_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm50_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm50,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm50_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm50_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm50,
    (ModelNode*) &iedModel_MONT_GGIO2_Alm50_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Alm50_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Alm50,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind1_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind1,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind1,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind1,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind1,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind1_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind1_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind1,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind1_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind1_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind3,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind2_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind2_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind2_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind2_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind2_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind4,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind3_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind3,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind3,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind3,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind3,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind3_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind3_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind3,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind3_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind3_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind5,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind4_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind4,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind4,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind4,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind4,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind4_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind4_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind4,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind4_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind4_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind5 = {
    DataObjectModelType,
    "Ind5",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind6,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind5_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind5,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind5,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind5,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind5,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind5_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind5_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind5,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind5_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind5_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind5,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind6 = {
    DataObjectModelType,
    "Ind6",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind7,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind6_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind6,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind6,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind6,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind6,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind6_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind6_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind6,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind6_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind6_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind6,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind7 = {
    DataObjectModelType,
    "Ind7",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind8,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind7_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind7,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind7,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind7,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind7,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind7_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind7_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind7,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind7_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind7_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind7,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind8 = {
    DataObjectModelType,
    "Ind8",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind9,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind8_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind8,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind8,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind8,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind8,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind8_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind8_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind8,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind8_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind8_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind8,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind9 = {
    DataObjectModelType,
    "Ind9",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind10,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind9_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind9,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind9,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind9,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind9,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind9_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind9_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind9,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind9_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind9_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind9,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind10 = {
    DataObjectModelType,
    "Ind10",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind11,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind10_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind10,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind10,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind10,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind10,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind10_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind10_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind10,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind10_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind10_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind10,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind11 = {
    DataObjectModelType,
    "Ind11",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind12,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind11_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind11,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind11,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind11,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind11_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind11,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind11_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind11_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind11,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind11_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind11_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind11,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind12 = {
    DataObjectModelType,
    "Ind12",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind13,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind12_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind12_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind12,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind12_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind12_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind12,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind12_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind12_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind12,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind12_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind12_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind12,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind12_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind12_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind12,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind12_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind12_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind12,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind13 = {
    DataObjectModelType,
    "Ind13",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind14,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind13_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind13_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind13,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind13_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind13_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind13,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind13_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind13_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind13,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind13_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind13_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind13,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind13_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind13_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind13,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind13_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind13_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind13,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind14 = {
    DataObjectModelType,
    "Ind14",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind15,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind14_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind14_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind14,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind14_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind14_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind14,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind14_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind14_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind14,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind14_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind14_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind14,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind14_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind14_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind14,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind14_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind14_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind14,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind15 = {
    DataObjectModelType,
    "Ind15",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind16,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind15_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind15_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind15,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind15_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind15_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind15,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind15_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind15_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind15,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind15_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind15_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind15,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind15_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind15_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind15,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind15_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind15_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind15,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind16 = {
    DataObjectModelType,
    "Ind16",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind17,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind16_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind16_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind16,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind16_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind16_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind16,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind16_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind16_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind16,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind16_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind16_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind16,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind16_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind16_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind16,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind16_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind16_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind16,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind17 = {
    DataObjectModelType,
    "Ind17",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind18,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind17_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind17_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind17,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind17_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind17_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind17,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind17_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind17_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind17,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind17_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind17_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind17,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind17_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind17_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind17,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind17_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind17_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind17,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind18 = {
    DataObjectModelType,
    "Ind18",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind19,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind18_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind18_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind18,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind18_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind18_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind18,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind18_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind18_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind18,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind18_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind18_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind18,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind18_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind18_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind18,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind18_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind18_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind18,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind19 = {
    DataObjectModelType,
    "Ind19",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind20,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind19_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind19_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind19,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind19_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind19_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind19,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind19_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind19_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind19,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind19_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind19_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind19,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind19_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind19_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind19,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind19_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind19_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind19,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind20 = {
    DataObjectModelType,
    "Ind20",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind21,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind20_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind20_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind20,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind20_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind20_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind20,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind20_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind20_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind20,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind20_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind20_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind20,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind20_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind20_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind20,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind20_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind20_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind20,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind21 = {
    DataObjectModelType,
    "Ind21",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind22,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind21_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind21_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind21,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind21_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind21_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind21,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind21_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind21_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind21,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind21_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind21_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind21,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind21_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind21_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind21,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind21_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind21_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind21,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind22 = {
    DataObjectModelType,
    "Ind22",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind23,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind22_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind22_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind22,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind22_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind22_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind22,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind22_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind22_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind22,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind22_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind22_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind22,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind22_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind22_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind22,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind22_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind22_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind22,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind23 = {
    DataObjectModelType,
    "Ind23",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind24,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind23_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind23_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind23,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind23_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind23_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind23,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind23_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind23_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind23,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind23_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind23_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind23,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind23_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind23_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind23,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind23_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind23_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind23,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind24 = {
    DataObjectModelType,
    "Ind24",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind25,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind24_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind24_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind24,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind24_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind24_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind24,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind24_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind24_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind24,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind24_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind24_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind24,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind24_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind24_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind24,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind24_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind24_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind24,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind25 = {
    DataObjectModelType,
    "Ind25",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind26,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind25_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind25_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind25,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind25_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind25_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind25,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind25_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind25_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind25,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind25_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind25_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind25,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind25_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind25_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind25,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind25_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind25_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind25,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind26 = {
    DataObjectModelType,
    "Ind26",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind27,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind26_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind26_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind26,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind26_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind26_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind26,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind26_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind26_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind26,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind26_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind26_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind26,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind26_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind26_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind26,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind26_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind26_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind26,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind27 = {
    DataObjectModelType,
    "Ind27",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind28,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind27_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind27_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind27,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind27_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind27_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind27,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind27_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind27_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind27,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind27_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind27_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind27,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind27_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind27_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind27,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind27_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind27_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind27,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind28 = {
    DataObjectModelType,
    "Ind28",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind29,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind28_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind28_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind28,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind28_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind28_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind28,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind28_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind28_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind28,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind28_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind28_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind28,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind28_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind28_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind28,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind28_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind28_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind28,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind29 = {
    DataObjectModelType,
    "Ind29",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind30,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind29_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind29_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind29,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind29_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind29_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind29,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind29_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind29_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind29,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind29_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind29_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind29,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind29_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind29_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind29,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind29_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind29_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind29,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind30 = {
    DataObjectModelType,
    "Ind30",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind31,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind30_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind30_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind30,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind30_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind30_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind30,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind30_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind30_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind30,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind30_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind30_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind30,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind30_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind30_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind30,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind30_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind30_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind30,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind31 = {
    DataObjectModelType,
    "Ind31",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind32,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind31_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind31_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind31,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind31_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind31_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind31,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind31_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind31_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind31,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind31_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind31_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind31,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind31_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind31_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind31,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind31_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind31_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind31,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind32 = {
    DataObjectModelType,
    "Ind32",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind33,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind32_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind32_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind32,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind32_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind32_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind32,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind32_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind32_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind32,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind32_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind32_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind32,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind32_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind32_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind32,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind32_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind32_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind32,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind33 = {
    DataObjectModelType,
    "Ind33",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind34,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind33_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind33_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind33,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind33_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind33_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind33,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind33_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind33_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind33,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind33_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind33_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind33,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind33_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind33_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind33,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind33_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind33_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind33,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind34 = {
    DataObjectModelType,
    "Ind34",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind35,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind34_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind34_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind34,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind34_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind34_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind34,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind34_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind34_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind34,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind34_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind34_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind34,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind34_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind34_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind34,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind34_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind34_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind34,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind35 = {
    DataObjectModelType,
    "Ind35",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind36,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind35_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind35_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind35,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind35_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind35_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind35,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind35_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind35_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind35,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind35_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind35_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind35,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind35_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind35_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind35,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind35_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind35_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind35,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind36 = {
    DataObjectModelType,
    "Ind36",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind37,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind36_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind36_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind36,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind36_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind36_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind36,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind36_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind36_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind36,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind36_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind36_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind36,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind36_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind36_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind36,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind36_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind36_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind36,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind37 = {
    DataObjectModelType,
    "Ind37",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind38,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind37_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind37_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind37,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind37_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind37_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind37,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind37_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind37_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind37,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind37_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind37_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind37,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind37_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind37_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind37,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind37_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind37_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind37,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind38 = {
    DataObjectModelType,
    "Ind38",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind39,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind38_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind38_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind38,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind38_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind38_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind38,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind38_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind38_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind38,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind38_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind38_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind38,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind38_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind38_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind38,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind38_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind38_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind38,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind39 = {
    DataObjectModelType,
    "Ind39",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind40,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind39_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind39_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind39,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind39_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind39_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind39,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind39_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind39_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind39,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind39_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind39_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind39,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind39_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind39_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind39,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind39_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind39_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind39,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind40 = {
    DataObjectModelType,
    "Ind40",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind41,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind40_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind40_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind40,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind40_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind40_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind40,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind40_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind40_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind40,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind40_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind40_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind40,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind40_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind40_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind40,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind40_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind40_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind40,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind41 = {
    DataObjectModelType,
    "Ind41",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind42,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind41_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind41_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind41,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind41_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind41_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind41,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind41_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind41_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind41,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind41_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind41_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind41,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind41_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind41_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind41,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind41_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind41_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind41,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind42 = {
    DataObjectModelType,
    "Ind42",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind43,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind42_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind42_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind42,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind42_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind42_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind42,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind42_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind42_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind42,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind42_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind42_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind42,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind42_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind42_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind42,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind42_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind42_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind42,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind43 = {
    DataObjectModelType,
    "Ind43",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind44,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind43_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind43_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind43,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind43_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind43_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind43,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind43_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind43_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind43,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind43_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind43_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind43,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind43_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind43_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind43,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind43_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind43_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind43,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind44 = {
    DataObjectModelType,
    "Ind44",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind45,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind44_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind44_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind44,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind44_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind44_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind44,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind44_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind44_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind44,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind44_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind44_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind44,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind44_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind44_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind44,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind44_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind44_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind44,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind45 = {
    DataObjectModelType,
    "Ind45",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind46,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind45_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind45_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind45,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind45_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind45_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind45,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind45_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind45_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind45,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind45_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind45_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind45,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind45_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind45_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind45,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind45_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind45_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind45,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind46 = {
    DataObjectModelType,
    "Ind46",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind47,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind46_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind46_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind46,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind46_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind46_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind46,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind46_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind46_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind46,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind46_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind46_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind46,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind46_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind46_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind46,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind46_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind46_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind46,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind47 = {
    DataObjectModelType,
    "Ind47",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind48,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind47_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind47_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind47,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind47_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind47_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind47,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind47_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind47_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind47,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind47_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind47_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind47,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind47_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind47_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind47,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind47_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind47_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind47,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind48 = {
    DataObjectModelType,
    "Ind48",
    (ModelNode*) &iedModel_MONT_GGIO2,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind49,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind48_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind48_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind48,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind48_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind48_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind48,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind48_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind48_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind48,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind48_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind48_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind48,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind48_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind48_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind48,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind48_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind48_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind48,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_GGIO2_Ind49 = {
    DataObjectModelType,
    "Ind49",
    (ModelNode*) &iedModel_MONT_GGIO2,
    NULL,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind49_stVal,
    0
};

DataAttribute iedModel_MONT_GGIO2_Ind49_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind49,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind49_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind49_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind49,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind49_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind49_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind49,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind49_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind49_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind49,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind49_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind49_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind49,
    (ModelNode*) &iedModel_MONT_GGIO2_Ind49_dataNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_GGIO2_Ind49_dataNs = {
    DataAttributeModelType,
    "dataNs",
    (ModelNode*) &iedModel_MONT_GGIO2_Ind49,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_MONT_CCGR1 = {
    LogicalNodeModelType,
    "CCGR1",
    (ModelNode*) &iedModel_MONT,
    (ModelNode*) &iedModel_MONT_CCGR2,
    (ModelNode*) &iedModel_MONT_CCGR1_Mod,
};

DataObject iedModel_MONT_CCGR1_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_MONT_CCGR1,
    (ModelNode*) &iedModel_MONT_CCGR1_Beh,
    (ModelNode*) &iedModel_MONT_CCGR1_Mod_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR1_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR1_Mod,
    (ModelNode*) &iedModel_MONT_CCGR1_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR1_Mod,
    (ModelNode*) &iedModel_MONT_CCGR1_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR1_Mod,
    (ModelNode*) &iedModel_MONT_CCGR1_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR1_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR1_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_MONT_CCGR1,
    (ModelNode*) &iedModel_MONT_CCGR1_Health,
    (ModelNode*) &iedModel_MONT_CCGR1_Beh_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR1_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR1_Beh,
    (ModelNode*) &iedModel_MONT_CCGR1_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR1_Beh,
    (ModelNode*) &iedModel_MONT_CCGR1_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR1_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR1_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_MONT_CCGR1,
    (ModelNode*) &iedModel_MONT_CCGR1_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR1_Health_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR1_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR1_Health,
    (ModelNode*) &iedModel_MONT_CCGR1_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR1_Health,
    (ModelNode*) &iedModel_MONT_CCGR1_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR1_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR1_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_MONT_CCGR1,
    (ModelNode*) &iedModel_MONT_CCGR1_FanA,
    (ModelNode*) &iedModel_MONT_CCGR1_NamPlt_vendor,
    0
};

DataAttribute iedModel_MONT_CCGR1_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_MONT_CCGR1_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR1_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_MONT_CCGR1_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR1_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR1_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR1_NamPlt_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_NamPlt_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR1_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR1_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_MONT_CCGR1_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR1_FanA = {
    DataObjectModelType,
    "FanA",
    (ModelNode*) &iedModel_MONT_CCGR1,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_FanA_mag,
    0
};

DataAttribute iedModel_MONT_CCGR1_FanA_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_CCGR1_FanA,
    (ModelNode*) &iedModel_MONT_CCGR1_FanA_q,
    (ModelNode*) &iedModel_MONT_CCGR1_FanA_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_FanA_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_CCGR1_FanA_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_FanA_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR1_FanA,
    (ModelNode*) &iedModel_MONT_CCGR1_FanA_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_FanA_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR1_FanA,
    (ModelNode*) &iedModel_MONT_CCGR1_FanA_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_FanA_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR1_FanA,
    (ModelNode*) &iedModel_MONT_CCGR1_FanA_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_FanA_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR1_FanA,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR1_CECtl = {
    DataObjectModelType,
    "CECtl",
    (ModelNode*) &iedModel_MONT_CCGR1,
    NULL,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_operTm,
    0
};

DataAttribute iedModel_MONT_CCGR1_CECtl_operTm = {
    DataAttributeModelType,
    "operTm",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_SBO,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_SBO = {
    DataAttributeModelType,
    "SBO",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_VISIBLE_STRING_65,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Oper = {
    DataAttributeModelType,
    "Oper",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Oper_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Oper_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Oper_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper_origin,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Oper_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Oper_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Oper_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Oper_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper_Check,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Oper_Check = {
    DataAttributeModelType,
    "Check",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Oper,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_CHECK,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Cancel = {
    DataAttributeModelType,
    "Cancel",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Cancel_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Cancel_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Cancel_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel_origin,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Cancel_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Cancel_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Cancel_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_Cancel_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_Cancel,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_origin_orCat,
    0,
    IEC61850_FC_ST,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_stVal,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_pulseConfig,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_pulseConfig = {
    DataAttributeModelType,
    "pulseConfig",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_ctlModel,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_pulseConfig_cmdQual,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_pulseConfig_cmdQual = {
    DataAttributeModelType,
    "cmdQual",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_pulseConfig_onDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_pulseConfig_onDur = {
    DataAttributeModelType,
    "onDur",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_pulseConfig_offDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_pulseConfig_offDur = {
    DataAttributeModelType,
    "offDur",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_pulseConfig_numPls,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_pulseConfig_numPls = {
    DataAttributeModelType,
    "numPls",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_pulseConfig,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_sboTimeout,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_sboTimeout = {
    DataAttributeModelType,
    "sboTimeout",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_sboClass,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_sboClass = {
    DataAttributeModelType,
    "sboClass",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_d,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR1_CECtl_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR1_CECtl,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_MONT_CCGR2 = {
    LogicalNodeModelType,
    "CCGR2",
    (ModelNode*) &iedModel_MONT,
    (ModelNode*) &iedModel_MONT_CCGR3,
    (ModelNode*) &iedModel_MONT_CCGR2_Mod,
};

DataObject iedModel_MONT_CCGR2_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_MONT_CCGR2,
    (ModelNode*) &iedModel_MONT_CCGR2_Beh,
    (ModelNode*) &iedModel_MONT_CCGR2_Mod_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR2_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR2_Mod,
    (ModelNode*) &iedModel_MONT_CCGR2_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR2_Mod,
    (ModelNode*) &iedModel_MONT_CCGR2_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR2_Mod,
    (ModelNode*) &iedModel_MONT_CCGR2_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR2_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR2_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_MONT_CCGR2,
    (ModelNode*) &iedModel_MONT_CCGR2_Health,
    (ModelNode*) &iedModel_MONT_CCGR2_Beh_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR2_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR2_Beh,
    (ModelNode*) &iedModel_MONT_CCGR2_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR2_Beh,
    (ModelNode*) &iedModel_MONT_CCGR2_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR2_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR2_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_MONT_CCGR2,
    (ModelNode*) &iedModel_MONT_CCGR2_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR2_Health_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR2_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR2_Health,
    (ModelNode*) &iedModel_MONT_CCGR2_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR2_Health,
    (ModelNode*) &iedModel_MONT_CCGR2_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR2_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR2_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_MONT_CCGR2,
    (ModelNode*) &iedModel_MONT_CCGR2_FanA,
    (ModelNode*) &iedModel_MONT_CCGR2_NamPlt_vendor,
    0
};

DataAttribute iedModel_MONT_CCGR2_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_MONT_CCGR2_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR2_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_MONT_CCGR2_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR2_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR2_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR2_NamPlt_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_NamPlt_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR2_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR2_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_MONT_CCGR2_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR2_FanA = {
    DataObjectModelType,
    "FanA",
    (ModelNode*) &iedModel_MONT_CCGR2,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_FanA_mag,
    0
};

DataAttribute iedModel_MONT_CCGR2_FanA_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_CCGR2_FanA,
    (ModelNode*) &iedModel_MONT_CCGR2_FanA_q,
    (ModelNode*) &iedModel_MONT_CCGR2_FanA_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_FanA_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_CCGR2_FanA_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_FanA_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR2_FanA,
    (ModelNode*) &iedModel_MONT_CCGR2_FanA_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_FanA_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR2_FanA,
    (ModelNode*) &iedModel_MONT_CCGR2_FanA_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_FanA_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR2_FanA,
    (ModelNode*) &iedModel_MONT_CCGR2_FanA_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_FanA_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR2_FanA,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR2_CECtl = {
    DataObjectModelType,
    "CECtl",
    (ModelNode*) &iedModel_MONT_CCGR2,
    NULL,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_operTm,
    0
};

DataAttribute iedModel_MONT_CCGR2_CECtl_operTm = {
    DataAttributeModelType,
    "operTm",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_SBO,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_SBO = {
    DataAttributeModelType,
    "SBO",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_VISIBLE_STRING_65,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Oper = {
    DataAttributeModelType,
    "Oper",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Oper_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Oper_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Oper_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper_origin,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Oper_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Oper_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Oper_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Oper_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper_Check,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Oper_Check = {
    DataAttributeModelType,
    "Check",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Oper,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_CHECK,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Cancel = {
    DataAttributeModelType,
    "Cancel",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Cancel_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Cancel_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Cancel_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel_origin,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Cancel_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Cancel_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Cancel_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_Cancel_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_Cancel,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_origin_orCat,
    0,
    IEC61850_FC_ST,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_stVal,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_pulseConfig,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_pulseConfig = {
    DataAttributeModelType,
    "pulseConfig",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_ctlModel,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_pulseConfig_cmdQual,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_pulseConfig_cmdQual = {
    DataAttributeModelType,
    "cmdQual",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_pulseConfig_onDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_pulseConfig_onDur = {
    DataAttributeModelType,
    "onDur",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_pulseConfig_offDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_pulseConfig_offDur = {
    DataAttributeModelType,
    "offDur",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_pulseConfig_numPls,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_pulseConfig_numPls = {
    DataAttributeModelType,
    "numPls",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_pulseConfig,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_sboTimeout,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_sboTimeout = {
    DataAttributeModelType,
    "sboTimeout",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_sboClass,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_sboClass = {
    DataAttributeModelType,
    "sboClass",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_d,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR2_CECtl_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR2_CECtl,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_MONT_CCGR3 = {
    LogicalNodeModelType,
    "CCGR3",
    (ModelNode*) &iedModel_MONT,
    (ModelNode*) &iedModel_MONT_CCGR4,
    (ModelNode*) &iedModel_MONT_CCGR3_Mod,
};

DataObject iedModel_MONT_CCGR3_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_MONT_CCGR3,
    (ModelNode*) &iedModel_MONT_CCGR3_Beh,
    (ModelNode*) &iedModel_MONT_CCGR3_Mod_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR3_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR3_Mod,
    (ModelNode*) &iedModel_MONT_CCGR3_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR3_Mod,
    (ModelNode*) &iedModel_MONT_CCGR3_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR3_Mod,
    (ModelNode*) &iedModel_MONT_CCGR3_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR3_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR3_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_MONT_CCGR3,
    (ModelNode*) &iedModel_MONT_CCGR3_Health,
    (ModelNode*) &iedModel_MONT_CCGR3_Beh_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR3_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR3_Beh,
    (ModelNode*) &iedModel_MONT_CCGR3_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR3_Beh,
    (ModelNode*) &iedModel_MONT_CCGR3_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR3_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR3_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_MONT_CCGR3,
    (ModelNode*) &iedModel_MONT_CCGR3_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR3_Health_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR3_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR3_Health,
    (ModelNode*) &iedModel_MONT_CCGR3_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR3_Health,
    (ModelNode*) &iedModel_MONT_CCGR3_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR3_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR3_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_MONT_CCGR3,
    (ModelNode*) &iedModel_MONT_CCGR3_FanA,
    (ModelNode*) &iedModel_MONT_CCGR3_NamPlt_vendor,
    0
};

DataAttribute iedModel_MONT_CCGR3_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_MONT_CCGR3_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR3_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_MONT_CCGR3_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR3_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR3_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR3_NamPlt_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_NamPlt_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR3_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR3_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_MONT_CCGR3_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR3_FanA = {
    DataObjectModelType,
    "FanA",
    (ModelNode*) &iedModel_MONT_CCGR3,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_FanA_mag,
    0
};

DataAttribute iedModel_MONT_CCGR3_FanA_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_CCGR3_FanA,
    (ModelNode*) &iedModel_MONT_CCGR3_FanA_q,
    (ModelNode*) &iedModel_MONT_CCGR3_FanA_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_FanA_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_CCGR3_FanA_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_FanA_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR3_FanA,
    (ModelNode*) &iedModel_MONT_CCGR3_FanA_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_FanA_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR3_FanA,
    (ModelNode*) &iedModel_MONT_CCGR3_FanA_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_FanA_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR3_FanA,
    (ModelNode*) &iedModel_MONT_CCGR3_FanA_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_FanA_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR3_FanA,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR3_CECtl = {
    DataObjectModelType,
    "CECtl",
    (ModelNode*) &iedModel_MONT_CCGR3,
    NULL,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_operTm,
    0
};

DataAttribute iedModel_MONT_CCGR3_CECtl_operTm = {
    DataAttributeModelType,
    "operTm",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_SBO,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_SBO = {
    DataAttributeModelType,
    "SBO",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_VISIBLE_STRING_65,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Oper = {
    DataAttributeModelType,
    "Oper",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Oper_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Oper_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Oper_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper_origin,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Oper_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Oper_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Oper_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Oper_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper_Check,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Oper_Check = {
    DataAttributeModelType,
    "Check",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Oper,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_CHECK,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Cancel = {
    DataAttributeModelType,
    "Cancel",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Cancel_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Cancel_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Cancel_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel_origin,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Cancel_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Cancel_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Cancel_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_Cancel_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_Cancel,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_origin_orCat,
    0,
    IEC61850_FC_ST,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_stVal,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_pulseConfig,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_pulseConfig = {
    DataAttributeModelType,
    "pulseConfig",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_ctlModel,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_pulseConfig_cmdQual,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_pulseConfig_cmdQual = {
    DataAttributeModelType,
    "cmdQual",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_pulseConfig_onDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_pulseConfig_onDur = {
    DataAttributeModelType,
    "onDur",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_pulseConfig_offDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_pulseConfig_offDur = {
    DataAttributeModelType,
    "offDur",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_pulseConfig_numPls,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_pulseConfig_numPls = {
    DataAttributeModelType,
    "numPls",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_pulseConfig,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_sboTimeout,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_sboTimeout = {
    DataAttributeModelType,
    "sboTimeout",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_sboClass,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_sboClass = {
    DataAttributeModelType,
    "sboClass",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_d,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR3_CECtl_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR3_CECtl,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_MONT_CCGR4 = {
    LogicalNodeModelType,
    "CCGR4",
    (ModelNode*) &iedModel_MONT,
    (ModelNode*) &iedModel_MONT_CCGR5,
    (ModelNode*) &iedModel_MONT_CCGR4_Mod,
};

DataObject iedModel_MONT_CCGR4_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_MONT_CCGR4,
    (ModelNode*) &iedModel_MONT_CCGR4_Beh,
    (ModelNode*) &iedModel_MONT_CCGR4_Mod_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR4_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR4_Mod,
    (ModelNode*) &iedModel_MONT_CCGR4_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR4_Mod,
    (ModelNode*) &iedModel_MONT_CCGR4_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR4_Mod,
    (ModelNode*) &iedModel_MONT_CCGR4_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR4_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR4_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_MONT_CCGR4,
    (ModelNode*) &iedModel_MONT_CCGR4_Health,
    (ModelNode*) &iedModel_MONT_CCGR4_Beh_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR4_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR4_Beh,
    (ModelNode*) &iedModel_MONT_CCGR4_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR4_Beh,
    (ModelNode*) &iedModel_MONT_CCGR4_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR4_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR4_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_MONT_CCGR4,
    (ModelNode*) &iedModel_MONT_CCGR4_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR4_Health_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR4_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR4_Health,
    (ModelNode*) &iedModel_MONT_CCGR4_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR4_Health,
    (ModelNode*) &iedModel_MONT_CCGR4_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR4_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR4_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_MONT_CCGR4,
    (ModelNode*) &iedModel_MONT_CCGR4_FanA,
    (ModelNode*) &iedModel_MONT_CCGR4_NamPlt_vendor,
    0
};

DataAttribute iedModel_MONT_CCGR4_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_MONT_CCGR4_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR4_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_MONT_CCGR4_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR4_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR4_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR4_NamPlt_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_NamPlt_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR4_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR4_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_MONT_CCGR4_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR4_FanA = {
    DataObjectModelType,
    "FanA",
    (ModelNode*) &iedModel_MONT_CCGR4,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_FanA_mag,
    0
};

DataAttribute iedModel_MONT_CCGR4_FanA_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_CCGR4_FanA,
    (ModelNode*) &iedModel_MONT_CCGR4_FanA_q,
    (ModelNode*) &iedModel_MONT_CCGR4_FanA_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_FanA_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_CCGR4_FanA_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_FanA_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR4_FanA,
    (ModelNode*) &iedModel_MONT_CCGR4_FanA_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_FanA_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR4_FanA,
    (ModelNode*) &iedModel_MONT_CCGR4_FanA_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_FanA_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR4_FanA,
    (ModelNode*) &iedModel_MONT_CCGR4_FanA_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_FanA_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR4_FanA,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR4_CECtl = {
    DataObjectModelType,
    "CECtl",
    (ModelNode*) &iedModel_MONT_CCGR4,
    NULL,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_operTm,
    0
};

DataAttribute iedModel_MONT_CCGR4_CECtl_operTm = {
    DataAttributeModelType,
    "operTm",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_SBO,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_SBO = {
    DataAttributeModelType,
    "SBO",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_VISIBLE_STRING_65,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Oper = {
    DataAttributeModelType,
    "Oper",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Oper_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Oper_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Oper_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper_origin,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Oper_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Oper_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Oper_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Oper_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper_Check,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Oper_Check = {
    DataAttributeModelType,
    "Check",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Oper,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_CHECK,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Cancel = {
    DataAttributeModelType,
    "Cancel",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Cancel_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Cancel_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Cancel_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel_origin,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Cancel_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Cancel_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Cancel_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_Cancel_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_Cancel,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_origin_orCat,
    0,
    IEC61850_FC_ST,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_stVal,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_pulseConfig,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_pulseConfig = {
    DataAttributeModelType,
    "pulseConfig",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_ctlModel,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_pulseConfig_cmdQual,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_pulseConfig_cmdQual = {
    DataAttributeModelType,
    "cmdQual",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_pulseConfig_onDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_pulseConfig_onDur = {
    DataAttributeModelType,
    "onDur",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_pulseConfig_offDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_pulseConfig_offDur = {
    DataAttributeModelType,
    "offDur",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_pulseConfig_numPls,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_pulseConfig_numPls = {
    DataAttributeModelType,
    "numPls",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_pulseConfig,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_sboTimeout,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_sboTimeout = {
    DataAttributeModelType,
    "sboTimeout",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_sboClass,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_sboClass = {
    DataAttributeModelType,
    "sboClass",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_d,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR4_CECtl_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR4_CECtl,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_MONT_CCGR5 = {
    LogicalNodeModelType,
    "CCGR5",
    (ModelNode*) &iedModel_MONT,
    (ModelNode*) &iedModel_MONT_CCGR6,
    (ModelNode*) &iedModel_MONT_CCGR5_Mod,
};

DataObject iedModel_MONT_CCGR5_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_MONT_CCGR5,
    (ModelNode*) &iedModel_MONT_CCGR5_Beh,
    (ModelNode*) &iedModel_MONT_CCGR5_Mod_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR5_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR5_Mod,
    (ModelNode*) &iedModel_MONT_CCGR5_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR5_Mod,
    (ModelNode*) &iedModel_MONT_CCGR5_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR5_Mod,
    (ModelNode*) &iedModel_MONT_CCGR5_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR5_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR5_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_MONT_CCGR5,
    (ModelNode*) &iedModel_MONT_CCGR5_Health,
    (ModelNode*) &iedModel_MONT_CCGR5_Beh_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR5_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR5_Beh,
    (ModelNode*) &iedModel_MONT_CCGR5_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR5_Beh,
    (ModelNode*) &iedModel_MONT_CCGR5_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR5_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR5_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_MONT_CCGR5,
    (ModelNode*) &iedModel_MONT_CCGR5_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR5_Health_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR5_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR5_Health,
    (ModelNode*) &iedModel_MONT_CCGR5_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR5_Health,
    (ModelNode*) &iedModel_MONT_CCGR5_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR5_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR5_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_MONT_CCGR5,
    (ModelNode*) &iedModel_MONT_CCGR5_FanA,
    (ModelNode*) &iedModel_MONT_CCGR5_NamPlt_vendor,
    0
};

DataAttribute iedModel_MONT_CCGR5_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_MONT_CCGR5_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR5_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_MONT_CCGR5_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR5_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR5_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR5_NamPlt_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_NamPlt_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR5_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR5_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_MONT_CCGR5_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR5_FanA = {
    DataObjectModelType,
    "FanA",
    (ModelNode*) &iedModel_MONT_CCGR5,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_FanA_mag,
    0
};

DataAttribute iedModel_MONT_CCGR5_FanA_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_CCGR5_FanA,
    (ModelNode*) &iedModel_MONT_CCGR5_FanA_q,
    (ModelNode*) &iedModel_MONT_CCGR5_FanA_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_FanA_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_CCGR5_FanA_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_FanA_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR5_FanA,
    (ModelNode*) &iedModel_MONT_CCGR5_FanA_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_FanA_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR5_FanA,
    (ModelNode*) &iedModel_MONT_CCGR5_FanA_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_FanA_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR5_FanA,
    (ModelNode*) &iedModel_MONT_CCGR5_FanA_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_FanA_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR5_FanA,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR5_CECtl = {
    DataObjectModelType,
    "CECtl",
    (ModelNode*) &iedModel_MONT_CCGR5,
    NULL,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_operTm,
    0
};

DataAttribute iedModel_MONT_CCGR5_CECtl_operTm = {
    DataAttributeModelType,
    "operTm",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_SBO,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_SBO = {
    DataAttributeModelType,
    "SBO",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_VISIBLE_STRING_65,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Oper = {
    DataAttributeModelType,
    "Oper",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Oper_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Oper_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Oper_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper_origin,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Oper_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Oper_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Oper_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Oper_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper_Check,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Oper_Check = {
    DataAttributeModelType,
    "Check",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Oper,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_CHECK,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Cancel = {
    DataAttributeModelType,
    "Cancel",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Cancel_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Cancel_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Cancel_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel_origin,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Cancel_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Cancel_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Cancel_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_Cancel_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_Cancel,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_origin_orCat,
    0,
    IEC61850_FC_ST,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_stVal,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_pulseConfig,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_pulseConfig = {
    DataAttributeModelType,
    "pulseConfig",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_ctlModel,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_pulseConfig_cmdQual,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_pulseConfig_cmdQual = {
    DataAttributeModelType,
    "cmdQual",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_pulseConfig_onDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_pulseConfig_onDur = {
    DataAttributeModelType,
    "onDur",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_pulseConfig_offDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_pulseConfig_offDur = {
    DataAttributeModelType,
    "offDur",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_pulseConfig_numPls,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_pulseConfig_numPls = {
    DataAttributeModelType,
    "numPls",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_pulseConfig,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_sboTimeout,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_sboTimeout = {
    DataAttributeModelType,
    "sboTimeout",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_sboClass,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_sboClass = {
    DataAttributeModelType,
    "sboClass",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_d,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR5_CECtl_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR5_CECtl,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_MONT_CCGR6 = {
    LogicalNodeModelType,
    "CCGR6",
    (ModelNode*) &iedModel_MONT,
    (ModelNode*) &iedModel_MONT_CCGR7,
    (ModelNode*) &iedModel_MONT_CCGR6_Mod,
};

DataObject iedModel_MONT_CCGR6_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_MONT_CCGR6,
    (ModelNode*) &iedModel_MONT_CCGR6_Beh,
    (ModelNode*) &iedModel_MONT_CCGR6_Mod_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR6_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR6_Mod,
    (ModelNode*) &iedModel_MONT_CCGR6_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR6_Mod,
    (ModelNode*) &iedModel_MONT_CCGR6_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR6_Mod,
    (ModelNode*) &iedModel_MONT_CCGR6_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR6_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR6_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_MONT_CCGR6,
    (ModelNode*) &iedModel_MONT_CCGR6_Health,
    (ModelNode*) &iedModel_MONT_CCGR6_Beh_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR6_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR6_Beh,
    (ModelNode*) &iedModel_MONT_CCGR6_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR6_Beh,
    (ModelNode*) &iedModel_MONT_CCGR6_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR6_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR6_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_MONT_CCGR6,
    (ModelNode*) &iedModel_MONT_CCGR6_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR6_Health_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR6_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR6_Health,
    (ModelNode*) &iedModel_MONT_CCGR6_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR6_Health,
    (ModelNode*) &iedModel_MONT_CCGR6_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR6_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR6_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_MONT_CCGR6,
    (ModelNode*) &iedModel_MONT_CCGR6_FanA,
    (ModelNode*) &iedModel_MONT_CCGR6_NamPlt_vendor,
    0
};

DataAttribute iedModel_MONT_CCGR6_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_MONT_CCGR6_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR6_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_MONT_CCGR6_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR6_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR6_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR6_NamPlt_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_NamPlt_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR6_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR6_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_MONT_CCGR6_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR6_FanA = {
    DataObjectModelType,
    "FanA",
    (ModelNode*) &iedModel_MONT_CCGR6,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_FanA_mag,
    0
};

DataAttribute iedModel_MONT_CCGR6_FanA_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_CCGR6_FanA,
    (ModelNode*) &iedModel_MONT_CCGR6_FanA_q,
    (ModelNode*) &iedModel_MONT_CCGR6_FanA_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_FanA_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_CCGR6_FanA_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_FanA_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR6_FanA,
    (ModelNode*) &iedModel_MONT_CCGR6_FanA_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_FanA_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR6_FanA,
    (ModelNode*) &iedModel_MONT_CCGR6_FanA_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_FanA_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR6_FanA,
    (ModelNode*) &iedModel_MONT_CCGR6_FanA_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_FanA_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR6_FanA,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR6_CECtl = {
    DataObjectModelType,
    "CECtl",
    (ModelNode*) &iedModel_MONT_CCGR6,
    NULL,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_operTm,
    0
};

DataAttribute iedModel_MONT_CCGR6_CECtl_operTm = {
    DataAttributeModelType,
    "operTm",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_SBO,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_SBO = {
    DataAttributeModelType,
    "SBO",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_VISIBLE_STRING_65,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Oper = {
    DataAttributeModelType,
    "Oper",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Oper_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Oper_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Oper_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper_origin,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Oper_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Oper_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Oper_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Oper_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper_Check,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Oper_Check = {
    DataAttributeModelType,
    "Check",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Oper,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_CHECK,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Cancel = {
    DataAttributeModelType,
    "Cancel",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Cancel_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Cancel_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Cancel_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel_origin,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Cancel_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Cancel_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Cancel_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_Cancel_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_Cancel,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_origin_orCat,
    0,
    IEC61850_FC_ST,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_stVal,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_pulseConfig,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_pulseConfig = {
    DataAttributeModelType,
    "pulseConfig",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_ctlModel,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_pulseConfig_cmdQual,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_pulseConfig_cmdQual = {
    DataAttributeModelType,
    "cmdQual",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_pulseConfig_onDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_pulseConfig_onDur = {
    DataAttributeModelType,
    "onDur",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_pulseConfig_offDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_pulseConfig_offDur = {
    DataAttributeModelType,
    "offDur",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_pulseConfig_numPls,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_pulseConfig_numPls = {
    DataAttributeModelType,
    "numPls",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_pulseConfig,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_sboTimeout,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_sboTimeout = {
    DataAttributeModelType,
    "sboTimeout",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_sboClass,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_sboClass = {
    DataAttributeModelType,
    "sboClass",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_d,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR6_CECtl_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR6_CECtl,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_MONT_CCGR7 = {
    LogicalNodeModelType,
    "CCGR7",
    (ModelNode*) &iedModel_MONT,
    (ModelNode*) &iedModel_MONT_CCGR8,
    (ModelNode*) &iedModel_MONT_CCGR7_Mod,
};

DataObject iedModel_MONT_CCGR7_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_MONT_CCGR7,
    (ModelNode*) &iedModel_MONT_CCGR7_Beh,
    (ModelNode*) &iedModel_MONT_CCGR7_Mod_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR7_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR7_Mod,
    (ModelNode*) &iedModel_MONT_CCGR7_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR7_Mod,
    (ModelNode*) &iedModel_MONT_CCGR7_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR7_Mod,
    (ModelNode*) &iedModel_MONT_CCGR7_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR7_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR7_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_MONT_CCGR7,
    (ModelNode*) &iedModel_MONT_CCGR7_Health,
    (ModelNode*) &iedModel_MONT_CCGR7_Beh_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR7_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR7_Beh,
    (ModelNode*) &iedModel_MONT_CCGR7_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR7_Beh,
    (ModelNode*) &iedModel_MONT_CCGR7_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR7_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR7_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_MONT_CCGR7,
    (ModelNode*) &iedModel_MONT_CCGR7_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR7_Health_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR7_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR7_Health,
    (ModelNode*) &iedModel_MONT_CCGR7_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR7_Health,
    (ModelNode*) &iedModel_MONT_CCGR7_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR7_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR7_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_MONT_CCGR7,
    (ModelNode*) &iedModel_MONT_CCGR7_FanA,
    (ModelNode*) &iedModel_MONT_CCGR7_NamPlt_vendor,
    0
};

DataAttribute iedModel_MONT_CCGR7_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_MONT_CCGR7_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR7_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_MONT_CCGR7_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR7_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR7_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR7_NamPlt_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_NamPlt_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR7_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR7_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_MONT_CCGR7_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR7_FanA = {
    DataObjectModelType,
    "FanA",
    (ModelNode*) &iedModel_MONT_CCGR7,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_FanA_mag,
    0
};

DataAttribute iedModel_MONT_CCGR7_FanA_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_CCGR7_FanA,
    (ModelNode*) &iedModel_MONT_CCGR7_FanA_q,
    (ModelNode*) &iedModel_MONT_CCGR7_FanA_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_FanA_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_CCGR7_FanA_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_FanA_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR7_FanA,
    (ModelNode*) &iedModel_MONT_CCGR7_FanA_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_FanA_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR7_FanA,
    (ModelNode*) &iedModel_MONT_CCGR7_FanA_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_FanA_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR7_FanA,
    (ModelNode*) &iedModel_MONT_CCGR7_FanA_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_FanA_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR7_FanA,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR7_CECtl = {
    DataObjectModelType,
    "CECtl",
    (ModelNode*) &iedModel_MONT_CCGR7,
    NULL,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_operTm,
    0
};

DataAttribute iedModel_MONT_CCGR7_CECtl_operTm = {
    DataAttributeModelType,
    "operTm",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_SBO,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_SBO = {
    DataAttributeModelType,
    "SBO",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_VISIBLE_STRING_65,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Oper = {
    DataAttributeModelType,
    "Oper",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Oper_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Oper_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Oper_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper_origin,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Oper_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Oper_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Oper_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Oper_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper_Check,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Oper_Check = {
    DataAttributeModelType,
    "Check",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Oper,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_CHECK,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Cancel = {
    DataAttributeModelType,
    "Cancel",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Cancel_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Cancel_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Cancel_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel_origin,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Cancel_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Cancel_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Cancel_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_Cancel_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_Cancel,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_origin_orCat,
    0,
    IEC61850_FC_ST,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_stVal,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_pulseConfig,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_pulseConfig = {
    DataAttributeModelType,
    "pulseConfig",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_ctlModel,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_pulseConfig_cmdQual,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_pulseConfig_cmdQual = {
    DataAttributeModelType,
    "cmdQual",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_pulseConfig_onDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_pulseConfig_onDur = {
    DataAttributeModelType,
    "onDur",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_pulseConfig_offDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_pulseConfig_offDur = {
    DataAttributeModelType,
    "offDur",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_pulseConfig_numPls,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_pulseConfig_numPls = {
    DataAttributeModelType,
    "numPls",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_pulseConfig,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_sboTimeout,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_sboTimeout = {
    DataAttributeModelType,
    "sboTimeout",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_sboClass,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_sboClass = {
    DataAttributeModelType,
    "sboClass",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_d,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR7_CECtl_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR7_CECtl,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_MONT_CCGR8 = {
    LogicalNodeModelType,
    "CCGR8",
    (ModelNode*) &iedModel_MONT,
    (ModelNode*) &iedModel_MONT_YLTC1,
    (ModelNode*) &iedModel_MONT_CCGR8_Mod,
};

DataObject iedModel_MONT_CCGR8_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_MONT_CCGR8,
    (ModelNode*) &iedModel_MONT_CCGR8_Beh,
    (ModelNode*) &iedModel_MONT_CCGR8_Mod_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR8_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR8_Mod,
    (ModelNode*) &iedModel_MONT_CCGR8_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR8_Mod,
    (ModelNode*) &iedModel_MONT_CCGR8_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR8_Mod,
    (ModelNode*) &iedModel_MONT_CCGR8_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR8_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR8_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_MONT_CCGR8,
    (ModelNode*) &iedModel_MONT_CCGR8_Health,
    (ModelNode*) &iedModel_MONT_CCGR8_Beh_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR8_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR8_Beh,
    (ModelNode*) &iedModel_MONT_CCGR8_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR8_Beh,
    (ModelNode*) &iedModel_MONT_CCGR8_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR8_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR8_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_MONT_CCGR8,
    (ModelNode*) &iedModel_MONT_CCGR8_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR8_Health_stVal,
    0
};

DataAttribute iedModel_MONT_CCGR8_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR8_Health,
    (ModelNode*) &iedModel_MONT_CCGR8_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR8_Health,
    (ModelNode*) &iedModel_MONT_CCGR8_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR8_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR8_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_MONT_CCGR8,
    (ModelNode*) &iedModel_MONT_CCGR8_FanA,
    (ModelNode*) &iedModel_MONT_CCGR8_NamPlt_vendor,
    0
};

DataAttribute iedModel_MONT_CCGR8_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_MONT_CCGR8_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR8_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_MONT_CCGR8_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR8_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR8_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR8_NamPlt_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_NamPlt_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR8_NamPlt,
    (ModelNode*) &iedModel_MONT_CCGR8_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_MONT_CCGR8_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR8_FanA = {
    DataObjectModelType,
    "FanA",
    (ModelNode*) &iedModel_MONT_CCGR8,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_FanA_mag,
    0
};

DataAttribute iedModel_MONT_CCGR8_FanA_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_MONT_CCGR8_FanA,
    (ModelNode*) &iedModel_MONT_CCGR8_FanA_q,
    (ModelNode*) &iedModel_MONT_CCGR8_FanA_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_FanA_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_MONT_CCGR8_FanA_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_FanA_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR8_FanA,
    (ModelNode*) &iedModel_MONT_CCGR8_FanA_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_FanA_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR8_FanA,
    (ModelNode*) &iedModel_MONT_CCGR8_FanA_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_FanA_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR8_FanA,
    (ModelNode*) &iedModel_MONT_CCGR8_FanA_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_FanA_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR8_FanA,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_CCGR8_CECtl = {
    DataObjectModelType,
    "CECtl",
    (ModelNode*) &iedModel_MONT_CCGR8,
    NULL,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_operTm,
    0
};

DataAttribute iedModel_MONT_CCGR8_CECtl_operTm = {
    DataAttributeModelType,
    "operTm",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_SBO,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_SBO = {
    DataAttributeModelType,
    "SBO",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_VISIBLE_STRING_65,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Oper = {
    DataAttributeModelType,
    "Oper",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Oper_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Oper_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Oper_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper_origin,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Oper_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Oper_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Oper_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Oper_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper_Check,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Oper_Check = {
    DataAttributeModelType,
    "Check",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Oper,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_CHECK,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Cancel = {
    DataAttributeModelType,
    "Cancel",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Cancel_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Cancel_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Cancel_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel_origin,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Cancel_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Cancel_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Cancel_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_Cancel_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_Cancel,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_ctlNum,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_origin_orCat,
    0,
    IEC61850_FC_ST,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_origin,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_stVal,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_pulseConfig,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_pulseConfig = {
    DataAttributeModelType,
    "pulseConfig",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_ctlModel,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_pulseConfig_cmdQual,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_pulseConfig_cmdQual = {
    DataAttributeModelType,
    "cmdQual",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_pulseConfig_onDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_pulseConfig_onDur = {
    DataAttributeModelType,
    "onDur",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_pulseConfig_offDur,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_pulseConfig_offDur = {
    DataAttributeModelType,
    "offDur",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_pulseConfig,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_pulseConfig_numPls,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_pulseConfig_numPls = {
    DataAttributeModelType,
    "numPls",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_pulseConfig,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_sboTimeout,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_sboTimeout = {
    DataAttributeModelType,
    "sboTimeout",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_sboClass,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_sboClass = {
    DataAttributeModelType,
    "sboClass",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_d,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_CCGR8_CECtl_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_CCGR8_CECtl,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_MONT_YLTC1 = {
    LogicalNodeModelType,
    "YLTC1",
    (ModelNode*) &iedModel_MONT,
    NULL,
    (ModelNode*) &iedModel_MONT_YLTC1_Mod,
};

DataObject iedModel_MONT_YLTC1_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_MONT_YLTC1,
    (ModelNode*) &iedModel_MONT_YLTC1_Beh,
    (ModelNode*) &iedModel_MONT_YLTC1_Mod_stVal,
    0
};

DataAttribute iedModel_MONT_YLTC1_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_YLTC1_Mod,
    (ModelNode*) &iedModel_MONT_YLTC1_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_YLTC1_Mod,
    (ModelNode*) &iedModel_MONT_YLTC1_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_YLTC1_Mod,
    (ModelNode*) &iedModel_MONT_YLTC1_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_YLTC1_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_MONT_YLTC1_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_MONT_YLTC1,
    (ModelNode*) &iedModel_MONT_YLTC1_Health,
    (ModelNode*) &iedModel_MONT_YLTC1_Beh_stVal,
    0
};

DataAttribute iedModel_MONT_YLTC1_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_YLTC1_Beh,
    (ModelNode*) &iedModel_MONT_YLTC1_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_YLTC1_Beh,
    (ModelNode*) &iedModel_MONT_YLTC1_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_YLTC1_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_YLTC1_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_MONT_YLTC1,
    (ModelNode*) &iedModel_MONT_YLTC1_NamPlt,
    (ModelNode*) &iedModel_MONT_YLTC1_Health_stVal,
    0
};

DataAttribute iedModel_MONT_YLTC1_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_YLTC1_Health,
    (ModelNode*) &iedModel_MONT_YLTC1_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_YLTC1_Health,
    (ModelNode*) &iedModel_MONT_YLTC1_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_YLTC1_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_MONT_YLTC1_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_MONT_YLTC1,
    (ModelNode*) &iedModel_MONT_YLTC1_OpCnt,
    (ModelNode*) &iedModel_MONT_YLTC1_NamPlt_vendor,
    0
};

DataAttribute iedModel_MONT_YLTC1_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_MONT_YLTC1_NamPlt,
    (ModelNode*) &iedModel_MONT_YLTC1_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_MONT_YLTC1_NamPlt,
    (ModelNode*) &iedModel_MONT_YLTC1_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_YLTC1_NamPlt,
    (ModelNode*) &iedModel_MONT_YLTC1_NamPlt_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_NamPlt_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_YLTC1_NamPlt,
    (ModelNode*) &iedModel_MONT_YLTC1_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_MONT_YLTC1_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_YLTC1_OpCnt = {
    DataObjectModelType,
    "OpCnt",
    (ModelNode*) &iedModel_MONT_YLTC1,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_OpCnt_stVal,
    0
};

DataAttribute iedModel_MONT_YLTC1_OpCnt_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_YLTC1_OpCnt,
    (ModelNode*) &iedModel_MONT_YLTC1_OpCnt_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_OpCnt_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_YLTC1_OpCnt,
    (ModelNode*) &iedModel_MONT_YLTC1_OpCnt_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_OpCnt_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_YLTC1_OpCnt,
    (ModelNode*) &iedModel_MONT_YLTC1_OpCnt_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_OpCnt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_YLTC1_OpCnt,
    (ModelNode*) &iedModel_MONT_YLTC1_OpCnt_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_OpCnt_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_YLTC1_OpCnt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_YLTC1_TapChg = {
    DataObjectModelType,
    "TapChg",
    (ModelNode*) &iedModel_MONT_YLTC1,
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosR,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_operTm,
    0
};

DataAttribute iedModel_MONT_YLTC1_TapChg_operTm = {
    DataAttributeModelType,
    "operTm",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_SBO,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_SBO = {
    DataAttributeModelType,
    "SBO",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_VISIBLE_STRING_65,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Oper = {
    DataAttributeModelType,
    "Oper",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Oper_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Oper_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper_ctlNum,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Oper_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper_origin,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Oper_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Oper_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Oper_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Oper_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper_Check,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Oper_Check = {
    DataAttributeModelType,
    "Check",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Oper,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_CHECK,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Cancel = {
    DataAttributeModelType,
    "Cancel",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_origin,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel_ctlVal,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Cancel_ctlVal = {
    DataAttributeModelType,
    "ctlVal",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel_origin,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Cancel_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel_ctlNum,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel_origin_orCat,
    0,
    IEC61850_FC_CO,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Cancel_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel_origin,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Cancel_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Cancel_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel_T,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Cancel_T = {
    DataAttributeModelType,
    "T",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel_Test,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_Cancel_Test = {
    DataAttributeModelType,
    "Test",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_Cancel,
    NULL,
    NULL,
    0,
    IEC61850_FC_CO,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_origin = {
    DataAttributeModelType,
    "origin",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_ctlNum,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_origin_orCat,
    0,
    IEC61850_FC_ST,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_origin_orCat = {
    DataAttributeModelType,
    "orCat",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_origin,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_origin_orIdent,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_origin_orIdent = {
    DataAttributeModelType,
    "orIdent",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_origin,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_OCTET_STRING_64,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_ctlNum = {
    DataAttributeModelType,
    "ctlNum",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_valWTr,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_valWTr = {
    DataAttributeModelType,
    "valWTr",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_q,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_valWTr_posVal,
    0,
    IEC61850_FC_ST,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_valWTr_posVal = {
    DataAttributeModelType,
    "posVal",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_valWTr,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_valWTr_transInd,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT8,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_valWTr_transInd = {
    DataAttributeModelType,
    "transInd",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_valWTr,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_stSeld,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_stSeld = {
    DataAttributeModelType,
    "stSeld",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_persistent,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_persistent = {
    DataAttributeModelType,
    "persistent",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_ctlModel,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_sboTimeout,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_sboTimeout = {
    DataAttributeModelType,
    "sboTimeout",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_sboClass,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT32U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_sboClass = {
    DataAttributeModelType,
    "sboClass",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_minVal,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_minVal = {
    DataAttributeModelType,
    "minVal",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_maxVal,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT8,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_maxVal = {
    DataAttributeModelType,
    "maxVal",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_stepSize,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT8,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_stepSize = {
    DataAttributeModelType,
    "stepSize",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_d,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_INT8U,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_TapChg_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_YLTC1_TapChg,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_YLTC1_EndPosR = {
    DataObjectModelType,
    "EndPosR",
    (ModelNode*) &iedModel_MONT_YLTC1,
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosL,
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosR_stVal,
    0
};

DataAttribute iedModel_MONT_YLTC1_EndPosR_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosR,
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosR_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_EndPosR_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosR,
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosR_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_EndPosR_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosR,
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosR_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_EndPosR_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosR,
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosR_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_EndPosR_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosR,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_MONT_YLTC1_EndPosL = {
    DataObjectModelType,
    "EndPosL",
    (ModelNode*) &iedModel_MONT_YLTC1,
    NULL,
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosL_stVal,
    0
};

DataAttribute iedModel_MONT_YLTC1_EndPosL_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosL,
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosL_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_EndPosL_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosL,
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosL_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_EndPosL_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosL,
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosL_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_EndPosL_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosL,
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosL_dU,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_MONT_YLTC1_EndPosL_dU = {
    DataAttributeModelType,
    "dU",
    (ModelNode*) &iedModel_MONT_YLTC1_EndPosL,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_UNICODE_STRING_255,
    0,
    NULL,
    0};

extern ReportControlBlock iedModel_MONT_LLN0_report0;
extern ReportControlBlock iedModel_MONT_LLN0_report1;
extern ReportControlBlock iedModel_MONT_LLN0_report2;
extern ReportControlBlock iedModel_MONT_LLN0_report3;
extern ReportControlBlock iedModel_MONT_LLN0_report4;
extern ReportControlBlock iedModel_MONT_LLN0_report5;
extern ReportControlBlock iedModel_MONT_LLN0_report6;
extern ReportControlBlock iedModel_MONT_LLN0_report7;
extern ReportControlBlock iedModel_MONT_LLN0_report8;
extern ReportControlBlock iedModel_MONT_LLN0_report9;
extern ReportControlBlock iedModel_MONT_LLN0_report10;
extern ReportControlBlock iedModel_MONT_LLN0_report11;
extern ReportControlBlock iedModel_MONT_LLN0_report12;
extern ReportControlBlock iedModel_MONT_LLN0_report13;
extern ReportControlBlock iedModel_MONT_LLN0_report14;
extern ReportControlBlock iedModel_MONT_LLN0_report15;
extern ReportControlBlock iedModel_MONT_LLN0_report16;
extern ReportControlBlock iedModel_MONT_LLN0_report17;
extern ReportControlBlock iedModel_MONT_LLN0_report18;
extern ReportControlBlock iedModel_MONT_LLN0_report19;
extern ReportControlBlock iedModel_MONT_LLN0_report20;
extern ReportControlBlock iedModel_MONT_LLN0_report21;
extern ReportControlBlock iedModel_MONT_LLN0_report22;
extern ReportControlBlock iedModel_MONT_LLN0_report23;
extern ReportControlBlock iedModel_MONT_LLN0_report24;
extern ReportControlBlock iedModel_MONT_LLN0_report25;
extern ReportControlBlock iedModel_MONT_LLN0_report26;
extern ReportControlBlock iedModel_MONT_LLN0_report27;
extern ReportControlBlock iedModel_MONT_LLN0_report28;
extern ReportControlBlock iedModel_MONT_LLN0_report29;
extern ReportControlBlock iedModel_MONT_LLN0_report30;
extern ReportControlBlock iedModel_MONT_LLN0_report31;
extern ReportControlBlock iedModel_MONT_LLN0_report32;
extern ReportControlBlock iedModel_MONT_LLN0_report33;
extern ReportControlBlock iedModel_MONT_LLN0_report34;
extern ReportControlBlock iedModel_MONT_LLN0_report35;
extern ReportControlBlock iedModel_MONT_LLN0_report36;
extern ReportControlBlock iedModel_MONT_LLN0_report37;
extern ReportControlBlock iedModel_MONT_LLN0_report38;
extern ReportControlBlock iedModel_MONT_LLN0_report39;
extern ReportControlBlock iedModel_MONT_LLN0_report40;
extern ReportControlBlock iedModel_MONT_LLN0_report41;
extern ReportControlBlock iedModel_MONT_LLN0_report42;
extern ReportControlBlock iedModel_MONT_LLN0_report43;
extern ReportControlBlock iedModel_MONT_LLN0_report44;
extern ReportControlBlock iedModel_MONT_LLN0_report45;
extern ReportControlBlock iedModel_MONT_LLN0_report46;
extern ReportControlBlock iedModel_MONT_LLN0_report47;
extern ReportControlBlock iedModel_MONT_LLN0_report48;
extern ReportControlBlock iedModel_MONT_LLN0_report49;
extern ReportControlBlock iedModel_MONT_LLN0_report50;
extern ReportControlBlock iedModel_MONT_LLN0_report51;
extern ReportControlBlock iedModel_MONT_LLN0_report52;
extern ReportControlBlock iedModel_MONT_LLN0_report53;
extern ReportControlBlock iedModel_MONT_LLN0_report54;
extern ReportControlBlock iedModel_MONT_LLN0_report55;
extern ReportControlBlock iedModel_MONT_LLN0_report56;
extern ReportControlBlock iedModel_MONT_LLN0_report57;
extern ReportControlBlock iedModel_MONT_LLN0_report58;
extern ReportControlBlock iedModel_MONT_LLN0_report59;
extern ReportControlBlock iedModel_MONT_LLN0_report60;
extern ReportControlBlock iedModel_MONT_LLN0_report61;
extern ReportControlBlock iedModel_MONT_LLN0_report62;
extern ReportControlBlock iedModel_MONT_LLN0_report63;
extern ReportControlBlock iedModel_MONT_LLN0_report64;
extern ReportControlBlock iedModel_MONT_LLN0_report65;
extern ReportControlBlock iedModel_MONT_LLN0_report66;
extern ReportControlBlock iedModel_MONT_LLN0_report67;
extern ReportControlBlock iedModel_MONT_LLN0_report68;
extern ReportControlBlock iedModel_MONT_LLN0_report69;
extern ReportControlBlock iedModel_MONT_LLN0_report70;
extern ReportControlBlock iedModel_MONT_LLN0_report71;
extern ReportControlBlock iedModel_MONT_LLN0_report72;
extern ReportControlBlock iedModel_MONT_LLN0_report73;
extern ReportControlBlock iedModel_MONT_LLN0_report74;
extern ReportControlBlock iedModel_MONT_LLN0_report75;
extern ReportControlBlock iedModel_MONT_LLN0_report76;
extern ReportControlBlock iedModel_MONT_LLN0_report77;
extern ReportControlBlock iedModel_MONT_LLN0_report78;
extern ReportControlBlock iedModel_MONT_LLN0_report79;

ReportControlBlock iedModel_MONT_LLN0_report0 = {&iedModel_MONT_LLN0, "urcbAssetHealth01", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report1};
ReportControlBlock iedModel_MONT_LLN0_report1 = {&iedModel_MONT_LLN0, "urcbAssetHealth02", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report2};
ReportControlBlock iedModel_MONT_LLN0_report2 = {&iedModel_MONT_LLN0, "urcbAssetHealth03", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report3};
ReportControlBlock iedModel_MONT_LLN0_report3 = {&iedModel_MONT_LLN0, "urcbAssetHealth04", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report4};
ReportControlBlock iedModel_MONT_LLN0_report4 = {&iedModel_MONT_LLN0, "urcbAssetHealth05", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report5};
ReportControlBlock iedModel_MONT_LLN0_report5 = {&iedModel_MONT_LLN0, "urcbAssetHealth06", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report6};
ReportControlBlock iedModel_MONT_LLN0_report6 = {&iedModel_MONT_LLN0, "urcbAssetHealth07", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report7};
ReportControlBlock iedModel_MONT_LLN0_report7 = {&iedModel_MONT_LLN0, "urcbAssetHealth08", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report8};
ReportControlBlock iedModel_MONT_LLN0_report8 = {&iedModel_MONT_LLN0, "brcbAssetHealth01", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report9};
ReportControlBlock iedModel_MONT_LLN0_report9 = {&iedModel_MONT_LLN0, "brcbAssetHealth02", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report10};
ReportControlBlock iedModel_MONT_LLN0_report10 = {&iedModel_MONT_LLN0, "brcbAssetHealth03", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report11};
ReportControlBlock iedModel_MONT_LLN0_report11 = {&iedModel_MONT_LLN0, "brcbAssetHealth04", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report12};
ReportControlBlock iedModel_MONT_LLN0_report12 = {&iedModel_MONT_LLN0, "brcbAssetHealth05", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report13};
ReportControlBlock iedModel_MONT_LLN0_report13 = {&iedModel_MONT_LLN0, "brcbAssetHealth06", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report14};
ReportControlBlock iedModel_MONT_LLN0_report14 = {&iedModel_MONT_LLN0, "brcbAssetHealth07", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report15};
ReportControlBlock iedModel_MONT_LLN0_report15 = {&iedModel_MONT_LLN0, "brcbAssetHealth08", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report16};
ReportControlBlock iedModel_MONT_LLN0_report16 = {&iedModel_MONT_LLN0, "urcbMeas01", "urcbMeasure", false, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report17};
ReportControlBlock iedModel_MONT_LLN0_report17 = {&iedModel_MONT_LLN0, "urcbMeas02", "urcbMeasure", false, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report18};
ReportControlBlock iedModel_MONT_LLN0_report18 = {&iedModel_MONT_LLN0, "urcbMeas03", "urcbMeasure", false, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report19};
ReportControlBlock iedModel_MONT_LLN0_report19 = {&iedModel_MONT_LLN0, "urcbMeas04", "urcbMeasure", false, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report20};
ReportControlBlock iedModel_MONT_LLN0_report20 = {&iedModel_MONT_LLN0, "urcbMeas05", "urcbMeasure", false, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report21};
ReportControlBlock iedModel_MONT_LLN0_report21 = {&iedModel_MONT_LLN0, "urcbMeas06", "urcbMeasure", false, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report22};
ReportControlBlock iedModel_MONT_LLN0_report22 = {&iedModel_MONT_LLN0, "urcbMeas07", "urcbMeasure", false, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report23};
ReportControlBlock iedModel_MONT_LLN0_report23 = {&iedModel_MONT_LLN0, "urcbMeas08", "urcbMeasure", false, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report24};
ReportControlBlock iedModel_MONT_LLN0_report24 = {&iedModel_MONT_LLN0, "brcbMeas01", "brcbMeasure", true, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report25};
ReportControlBlock iedModel_MONT_LLN0_report25 = {&iedModel_MONT_LLN0, "brcbMeas02", "brcbMeasure", true, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report26};
ReportControlBlock iedModel_MONT_LLN0_report26 = {&iedModel_MONT_LLN0, "brcbMeas03", "brcbMeasure", true, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report27};
ReportControlBlock iedModel_MONT_LLN0_report27 = {&iedModel_MONT_LLN0, "brcbMeas04", "brcbMeasure", true, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report28};
ReportControlBlock iedModel_MONT_LLN0_report28 = {&iedModel_MONT_LLN0, "brcbMeas05", "brcbMeasure", true, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report29};
ReportControlBlock iedModel_MONT_LLN0_report29 = {&iedModel_MONT_LLN0, "brcbMeas06", "brcbMeasure", true, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report30};
ReportControlBlock iedModel_MONT_LLN0_report30 = {&iedModel_MONT_LLN0, "brcbMeas07", "brcbMeasure", true, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report31};
ReportControlBlock iedModel_MONT_LLN0_report31 = {&iedModel_MONT_LLN0, "brcbMeas08", "brcbMeasure", true, "dsMeasure", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report32};
ReportControlBlock iedModel_MONT_LLN0_report32 = {&iedModel_MONT_LLN0, "urcbOLTC01", "urcbOLTC", false, "dsOLTC", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report33};
ReportControlBlock iedModel_MONT_LLN0_report33 = {&iedModel_MONT_LLN0, "urcbOLTC02", "urcbOLTC", false, "dsOLTC", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report34};
ReportControlBlock iedModel_MONT_LLN0_report34 = {&iedModel_MONT_LLN0, "urcbOLTC03", "urcbOLTC", false, "dsOLTC", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report35};
ReportControlBlock iedModel_MONT_LLN0_report35 = {&iedModel_MONT_LLN0, "urcbOLTC04", "urcbOLTC", false, "dsOLTC", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report36};
ReportControlBlock iedModel_MONT_LLN0_report36 = {&iedModel_MONT_LLN0, "urcbOLTC05", "urcbOLTC", false, "dsOLTC", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report37};
ReportControlBlock iedModel_MONT_LLN0_report37 = {&iedModel_MONT_LLN0, "urcbOLTC06", "urcbOLTC", false, "dsOLTC", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report38};
ReportControlBlock iedModel_MONT_LLN0_report38 = {&iedModel_MONT_LLN0, "urcbOLTC07", "urcbOLTC", false, "dsOLTC", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report39};
ReportControlBlock iedModel_MONT_LLN0_report39 = {&iedModel_MONT_LLN0, "urcbOLTC08", "urcbOLTC", false, "dsOLTC", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report40};
ReportControlBlock iedModel_MONT_LLN0_report40 = {&iedModel_MONT_LLN0, "urcbCal101", "urcbCalculate1", false, "dsCalculate1", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report41};
ReportControlBlock iedModel_MONT_LLN0_report41 = {&iedModel_MONT_LLN0, "urcbCal102", "urcbCalculate1", false, "dsCalculate1", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report42};
ReportControlBlock iedModel_MONT_LLN0_report42 = {&iedModel_MONT_LLN0, "urcbCal103", "urcbCalculate1", false, "dsCalculate1", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report43};
ReportControlBlock iedModel_MONT_LLN0_report43 = {&iedModel_MONT_LLN0, "urcbCal104", "urcbCalculate1", false, "dsCalculate1", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report44};
ReportControlBlock iedModel_MONT_LLN0_report44 = {&iedModel_MONT_LLN0, "urcbCal105", "urcbCalculate1", false, "dsCalculate1", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report45};
ReportControlBlock iedModel_MONT_LLN0_report45 = {&iedModel_MONT_LLN0, "urcbCal106", "urcbCalculate1", false, "dsCalculate1", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report46};
ReportControlBlock iedModel_MONT_LLN0_report46 = {&iedModel_MONT_LLN0, "urcbCal107", "urcbCalculate1", false, "dsCalculate1", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report47};
ReportControlBlock iedModel_MONT_LLN0_report47 = {&iedModel_MONT_LLN0, "urcbCal108", "urcbCalculate1", false, "dsCalculate1", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report48};
ReportControlBlock iedModel_MONT_LLN0_report48 = {&iedModel_MONT_LLN0, "urcbCal201", "urcbCalculate2", false, "dsCalculate2", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report49};
ReportControlBlock iedModel_MONT_LLN0_report49 = {&iedModel_MONT_LLN0, "urcbCal202", "urcbCalculate2", false, "dsCalculate2", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report50};
ReportControlBlock iedModel_MONT_LLN0_report50 = {&iedModel_MONT_LLN0, "urcbCal203", "urcbCalculate2", false, "dsCalculate2", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report51};
ReportControlBlock iedModel_MONT_LLN0_report51 = {&iedModel_MONT_LLN0, "urcbCal204", "urcbCalculate2", false, "dsCalculate2", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report52};
ReportControlBlock iedModel_MONT_LLN0_report52 = {&iedModel_MONT_LLN0, "urcbCal205", "urcbCalculate2", false, "dsCalculate2", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report53};
ReportControlBlock iedModel_MONT_LLN0_report53 = {&iedModel_MONT_LLN0, "urcbCal206", "urcbCalculate2", false, "dsCalculate2", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report54};
ReportControlBlock iedModel_MONT_LLN0_report54 = {&iedModel_MONT_LLN0, "urcbCal207", "urcbCalculate2", false, "dsCalculate2", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report55};
ReportControlBlock iedModel_MONT_LLN0_report55 = {&iedModel_MONT_LLN0, "urcbCal208", "urcbCalculate2", false, "dsCalculate2", 1, 25, 47, 0, 10000, &iedModel_MONT_LLN0_report56};
ReportControlBlock iedModel_MONT_LLN0_report56 = {&iedModel_MONT_LLN0, "brcbSt01", "brcbState", true, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report57};
ReportControlBlock iedModel_MONT_LLN0_report57 = {&iedModel_MONT_LLN0, "brcbSt02", "brcbState", true, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report58};
ReportControlBlock iedModel_MONT_LLN0_report58 = {&iedModel_MONT_LLN0, "brcbSt03", "brcbState", true, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report59};
ReportControlBlock iedModel_MONT_LLN0_report59 = {&iedModel_MONT_LLN0, "brcbSt04", "brcbState", true, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report60};
ReportControlBlock iedModel_MONT_LLN0_report60 = {&iedModel_MONT_LLN0, "brcbSt05", "brcbState", true, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report61};
ReportControlBlock iedModel_MONT_LLN0_report61 = {&iedModel_MONT_LLN0, "brcbSt06", "brcbState", true, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report62};
ReportControlBlock iedModel_MONT_LLN0_report62 = {&iedModel_MONT_LLN0, "brcbSt07", "brcbState", true, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report63};
ReportControlBlock iedModel_MONT_LLN0_report63 = {&iedModel_MONT_LLN0, "brcbSt08", "brcbState", true, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report64};
ReportControlBlock iedModel_MONT_LLN0_report64 = {&iedModel_MONT_LLN0, "urcbSt01", "urcbState", false, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report65};
ReportControlBlock iedModel_MONT_LLN0_report65 = {&iedModel_MONT_LLN0, "urcbSt02", "urcbState", false, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report66};
ReportControlBlock iedModel_MONT_LLN0_report66 = {&iedModel_MONT_LLN0, "urcbSt03", "urcbState", false, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report67};
ReportControlBlock iedModel_MONT_LLN0_report67 = {&iedModel_MONT_LLN0, "urcbSt04", "urcbState", false, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report68};
ReportControlBlock iedModel_MONT_LLN0_report68 = {&iedModel_MONT_LLN0, "urcbSt05", "urcbState", false, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report69};
ReportControlBlock iedModel_MONT_LLN0_report69 = {&iedModel_MONT_LLN0, "urcbSt06", "urcbState", false, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report70};
ReportControlBlock iedModel_MONT_LLN0_report70 = {&iedModel_MONT_LLN0, "urcbSt07", "urcbState", false, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report71};
ReportControlBlock iedModel_MONT_LLN0_report71 = {&iedModel_MONT_LLN0, "urcbSt08", "urcbState", false, "dsState", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report72};
ReportControlBlock iedModel_MONT_LLN0_report72 = {&iedModel_MONT_LLN0, "brcbAlm01", "brcbAlm", true, "dsAlm", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report73};
ReportControlBlock iedModel_MONT_LLN0_report73 = {&iedModel_MONT_LLN0, "brcbAlm02", "brcbAlm", true, "dsAlm", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report74};
ReportControlBlock iedModel_MONT_LLN0_report74 = {&iedModel_MONT_LLN0, "brcbAlm03", "brcbAlm", true, "dsAlm", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report75};
ReportControlBlock iedModel_MONT_LLN0_report75 = {&iedModel_MONT_LLN0, "brcbAlm04", "brcbAlm", true, "dsAlm", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report76};
ReportControlBlock iedModel_MONT_LLN0_report76 = {&iedModel_MONT_LLN0, "brcbAlm05", "brcbAlm", true, "dsAlm", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report77};
ReportControlBlock iedModel_MONT_LLN0_report77 = {&iedModel_MONT_LLN0, "brcbAlm06", "brcbAlm", true, "dsAlm", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report78};
ReportControlBlock iedModel_MONT_LLN0_report78 = {&iedModel_MONT_LLN0, "brcbAlm07", "brcbAlm", true, "dsAlm", 1, 27, 255, 0, 60000, &iedModel_MONT_LLN0_report79};
ReportControlBlock iedModel_MONT_LLN0_report79 = {&iedModel_MONT_LLN0, "brcbAlm08", "brcbAlm", true, "dsAlm", 1, 27, 255, 0, 60000, NULL};


extern GSEControlBlock iedModel_MONT_LLN0_gse0;

static PhyComAddress iedModel_MONT_LLN0_gse0_address = {
  4,
  0,
  12338,
  {0x9, 0xba, 0xad, 0xc0, 0xff, 0xff}
};

GSEControlBlock iedModel_MONT_LLN0_gse0 = {&iedModel_MONT_LLN0, "Gocb0", "GOID", "dsAlm", 1, false, &iedModel_MONT_LLN0_gse0_address, -1, -1, NULL};





IedModel iedModel = {
    "TEC",
    &iedModel_MONT,
    &iedModelds_MONT_LLN0_dsAssetHealth,
    &iedModel_MONT_LLN0_report0,
    &iedModel_MONT_LLN0_gse0,
    NULL,
    NULL,
    NULL,
    NULL,
    initializeValues
};

static void
initializeValues()
{

iedModel_MONT_LLN0_Mod_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_LLN0_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_MONT_LLN0_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_LLN0_Health_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_LLN0_NamPlt_ldNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2003");

iedModel_MONT_LPHD1_PhyHealth_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_SIML1_Mod_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_SIML1_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_MONT_SIML1_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_SIML1_Health_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_SIML1_Tmp1_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_SIML1_Tmp2_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_SIML1_Tmp3_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_SIML1_Tmp4_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_SIML1_H2O1_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_SIML1_H2O2_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_SIML1_H2O3_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_SIML1_H2ppm_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_H2ppm1_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_H2ppm2_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_H2ppm3_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_N2ppm_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_N2ppm1_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_N2ppm2_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_N2ppm3_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_COppm_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_COppm1_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_COppm2_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_COppm3_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CO2ppm_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CO2ppm1_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CO2ppm2_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CO2ppm3_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CH4ppm_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CH4ppm1_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CH4ppm2_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CH4ppm3_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_C2H2ppm_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_C2H2ppm1_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_C2H2ppm2_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_C2H2ppm3_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_C2H4ppm_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_C2H4ppm1_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_C2H4ppm2_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_C2H4ppm3_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_C2H6ppm_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_C2H6ppm1_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_C2H6ppm2_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_C2H6ppm3_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_O2ppm_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_O2ppm1_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_O2ppm2_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_O2ppm3_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CmbuGas_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CmbuGas1_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CmbuGas2_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CmbuGas3_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CmbuGas4_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CmbuGas5_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CmbuGas6_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_SIML1_CmbuGas7_dataNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2007");

iedModel_MONT_GGIO1_Mod_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_GGIO1_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_MONT_GGIO1_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_GGIO1_Health_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_GGIO1_AnIn1_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn2_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn3_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn4_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn5_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn6_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn7_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn8_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn9_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn10_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn11_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn12_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn13_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn14_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn15_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn16_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn17_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn18_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn19_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn20_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn21_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn22_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn23_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn24_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn25_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn26_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn27_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn28_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn29_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn30_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn31_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn32_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn33_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn34_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn35_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn36_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn37_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn38_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn39_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn40_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn41_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn42_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn43_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn44_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn45_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn46_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn47_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn48_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn49_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn50_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn51_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn52_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn53_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn54_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn55_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn56_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn57_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn58_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn59_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn60_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn61_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn62_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn63_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn64_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn65_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn66_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn67_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn68_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn69_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn70_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn71_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn72_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn73_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn74_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn75_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn76_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn77_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn78_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn79_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn80_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn81_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn82_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn83_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn84_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn85_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn86_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn87_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn88_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn89_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn90_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn91_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn92_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn93_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn94_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn95_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn96_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn97_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn98_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn99_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn100_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn101_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn102_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn103_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn104_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn105_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn106_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn107_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn108_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn109_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn110_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn111_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn112_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn113_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn114_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn115_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn116_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn117_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn118_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn119_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn120_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_AnIn121_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn1_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn2_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn3_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn4_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn5_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn6_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn7_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn8_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn9_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn10_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn11_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn12_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn13_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn14_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn15_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn16_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn17_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn18_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn19_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn20_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn21_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn22_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn23_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn24_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn25_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn26_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn27_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn28_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn29_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn30_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn31_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn32_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn33_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn34_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO1_IntIn35_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Mod_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_GGIO2_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_MONT_GGIO2_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_GGIO2_Health_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_GGIO2_Alm1_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm2_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm3_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm4_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm5_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm6_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm7_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm8_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm9_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm10_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm11_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm12_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm13_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm14_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm15_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm16_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm17_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm18_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm19_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm20_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm21_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm22_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm23_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm24_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm25_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm26_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm27_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm28_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm29_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm30_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm31_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm32_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm33_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm34_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm35_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm36_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm37_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm38_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm39_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm40_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm41_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm42_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm43_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm44_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm45_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm46_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm47_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm48_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm49_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Alm50_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind1_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind2_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind3_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind4_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind5_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind6_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind7_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind8_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind9_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind10_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind11_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind12_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind13_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind14_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind15_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind16_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind17_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind18_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind19_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind20_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind21_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind22_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind23_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind24_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind25_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind26_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind27_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind28_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind29_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind30_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind31_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind32_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind33_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind34_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind35_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind36_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind37_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind38_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind39_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind40_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind41_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind42_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind43_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind44_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind45_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind46_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind47_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind48_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_GGIO2_Ind49_dataNs.mmsValue = MmsValue_newVisibleString("ABB CoreTec:2016");

iedModel_MONT_CCGR1_Mod_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR1_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_MONT_CCGR1_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR1_Health_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR1_CECtl_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR2_Mod_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR2_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_MONT_CCGR2_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR2_Health_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR2_CECtl_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR3_Mod_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR3_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_MONT_CCGR3_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR3_Health_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR3_CECtl_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR4_Mod_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR4_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_MONT_CCGR4_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR4_Health_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR4_CECtl_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR5_Mod_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR5_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_MONT_CCGR5_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR5_Health_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR5_CECtl_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR6_Mod_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR6_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_MONT_CCGR6_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR6_Health_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR6_CECtl_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR7_Mod_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR7_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_MONT_CCGR7_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR7_Health_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR7_CECtl_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR8_Mod_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR8_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_MONT_CCGR8_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR8_Health_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_CCGR8_CECtl_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_YLTC1_Mod_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_YLTC1_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_MONT_YLTC1_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_YLTC1_Health_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_YLTC1_TapChg_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_MONT_YLTC1_TapChg_sboTimeout.mmsValue = MmsValue_newUnsignedFromUint32(10000);
}
