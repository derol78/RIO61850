/*
 *  server_example3.c
 *
 *  - How to use simple control models
 *  - How to serve analog measurement data
 */

#include "iec61850_server.h"
#include "hal_thread.h"
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
/*####### Inserted by David Erol to incoperate Sensor reading##########*/
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
/*######################################################################*/
#include "static_model.h"

/* import IEC 61850 device model created from SCL-File */
extern IedModel iedModel;

static int running = 0;
static IedServer iedServer = NULL;
static int stAlm1 = -1;
static int limAlm1 = 25;
static int stAlm2 = -1;
static int limAlm2 = 40;
static int stAlm3 = -1;
static int limAlm3 = -1;

void
sigint_handler(int signalId)
{
    running = 0;
}

static void
connectionHandler (IedServer self, ClientConnection connection, bool connected, void* parameter)
{
    if (connected)
        printf("Connection opened\n");
    else
        printf("Connection closed\n");
}

int
main(int argc, char** argv)
{
    printf("Using libIEC61850 version %s\n", LibIEC61850_getVersionString());

    iedServer = IedServer_create(&iedModel);

    /* Set the base path for the MMS file services */
    MmsServer mmsServer = IedServer_getMmsServer(iedServer);
    MmsServer_setFilestoreBasepath(mmsServer, "./vmd-filestore/");

    IedServer_setConnectionIndicationHandler(iedServer, (IedConnectionIndicationHandler) connectionHandler, NULL);

    /* MMS server will be instructed to start listening to client connections. */
    IedServer_start(iedServer, 102);

    if (!IedServer_isRunning(iedServer)) {
        printf("Starting server failed! Exit.\n");
        IedServer_destroy(iedServer);
        exit(-1);
    }

/*##############Davids Sensor Reading Code Start################################*/
DIR *dir;
 struct dirent *dirent;
 char dev[16];      // Dev ID
 char devPath[128]; // Path to device
 char buf[256];     // Data from device
 char tmpData[6];   // Temp C * 1000 reported by device 
 char path[] = "/sys/bus/w1/devices"; 
 ssize_t numRead;
 
 dir = opendir (path);
 if (dir != NULL)
 {
  while ((dirent = readdir (dir)))
   // 1-wire devices are links beginning with 28-
   if (dirent->d_type == DT_LNK && 
     strstr(dirent->d_name, "28-") != NULL) { 
    strcpy(dev, dirent->d_name);
    printf("\nDevice: %s\n", dev);
   }
        (void) closedir (dir);
        }
 else
 {
  perror ("Couldn't open the w1 devices directory");
  return 1;
 }

        // Assemble path to OneWire device
 sprintf(devPath, "%s/%s/w1_slave", path, dev);
 // Read temp continuously
 // Opening the device's file triggers new reading
/*###############Davids Sensor Reading Code End#############################*/
/*##########################################################################*/
    running = 1;

    signal(SIGINT, sigint_handler);

    while (running) {
        uint64_t timestamp = Hal_getTimeInMs();	
        
		IedServer_lockDataModel(iedServer);
        Timestamp iecTimestamp;
        Timestamp_clearFlags(&iecTimestamp);
        Timestamp_setTimeInMilliseconds(&iecTimestamp, timestamp);
        Timestamp_setLeapSecondKnown(&iecTimestamp, true);

/*##############Davids Sensor Reading Code Start################################*/
int fd = open(devPath, O_RDONLY);
  if(fd == -1)
  {
   perror ("Couldn't open the w1 device.");
   return 1;   
  }
  while((numRead = read(fd, buf, 256)) > 0) 
  {
	strncpy(tmpData, strstr(buf, "t=") + 2, 5); 
	float temp = strtof(tmpData, NULL);
	printf("Device: %s  - ", dev); 
	printf("Temp: %.3f C  ", temp / 1000);
/*######################Modification made by David Start ############*/
	float tmpC = roundf(temp)/1000;
  time_t rawtime;
  struct tm * timeinfo;
  time ( &rawtime );
  timeinfo = localtime ( &rawtime );
  const char* from = asctime (timeinfo);
  char *to;
  to=strndup(from+18, 1);
  int sek = atoi(to);
   printf("Time: %s  \n" , asctime (timeinfo));
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_Tmp_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_Tmp_mag_f, tmpC);
    if(sek<2){
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_Tmp1_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_Tmp1_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_Tmp2_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_Tmp2_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_Tmp3_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_Tmp3_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_Tmp4_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_Tmp4_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2O_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2O_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2O1_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2O1_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2O2_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2O2_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2O3_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2O3_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2ppm_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2ppm_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2ppm1_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2ppm1_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2ppm2_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2ppm2_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2ppm3_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_H2ppm3_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_N2ppm_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_N2ppm_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_N2ppm1_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_N2ppm1_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_N2ppm2_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_N2ppm2_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_N2ppm3_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_N2ppm3_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_COppm_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_COppm_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_COppm1_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_COppm1_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_COppm2_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_COppm2_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_COppm3_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_COppm3_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CO2ppm_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CO2ppm_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CO2ppm1_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CO2ppm1_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CO2ppm2_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CO2ppm2_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CO2ppm3_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CO2ppm3_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CH4ppm_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CH4ppm_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CH4ppm1_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CH4ppm1_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CH4ppm2_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CH4ppm2_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CH4ppm3_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CH4ppm3_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H2ppm_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H2ppm_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H2ppm1_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H2ppm1_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H2ppm2_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H2ppm2_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H2ppm3_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H2ppm3_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H4ppm_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H4ppm_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H4ppm1_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H4ppm1_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H4ppm2_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H4ppm2_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H4ppm3_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H4ppm3_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H6ppm_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H6ppm_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H6ppm1_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H6ppm1_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H6ppm2_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H6ppm2_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H6ppm3_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_C2H6ppm3_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_O2ppm_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_O2ppm_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_O2ppm1_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_O2ppm1_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_O2ppm2_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_O2ppm2_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_O2ppm3_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_O2ppm3_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas_t, &iecTimestamp);
	IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas1_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas1_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas2_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas2_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas3_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas3_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas4_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas4_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas5_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas5_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas6_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas6_mag_f, tmpC);
	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas7_t, &iecTimestamp);
    IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_MONT_SIML1_CmbuGas7_mag_f, tmpC);
   }
   
/*######################Modification made by David End ############*/
  }
  close(fd);
        /* return 0; --never called due to loop *
/*###############Davids Sensor Reading Code End################################*/

        IedServer_unlockDataModel(iedServer);

        Thread_sleep(100);
    }

    /* stop MMS server - close TCP server socket and all client sockets */
    IedServer_stop(iedServer);

    /* Cleanup - free all resources */
    IedServer_destroy(iedServer);

} /* main() */
