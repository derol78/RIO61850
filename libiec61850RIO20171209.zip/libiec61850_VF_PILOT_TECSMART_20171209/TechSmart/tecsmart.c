/*
 *  server_example3.c
 *
 *  - How to use simple control models
 *  - How to serve analog measurement data
 */

#include "iec61850_server.h"
#include "hal_thread.h"
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
/*####### Inserted by David Erol to incoperate Sensor reading##########*/
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
/*######################################################################*/
#include "static_model.h"

/* import IEC 61850 device model created from SCL-File */
extern IedModel iedModel;

static int running = 0;
static IedServer iedServer = NULL;

void
sigint_handler(int signalId)
{
    running = 0;
}

static void
connectionHandler (IedServer self, ClientConnection connection, bool connected, void* parameter)
{
    if (connected)
        printf("Connection opened\n");
    else
        printf("Connection closed\n");
}

int main(int argc, char** argv)
{
    printf("Using libIEC61850 version %s\n", LibIEC61850_getVersionString());

    iedServer = IedServer_create(&iedModel);

    /* Set the base path for the MMS file services */
    MmsServer mmsServer = IedServer_getMmsServer(iedServer);
    MmsServer_setFilestoreBasepath(mmsServer, "./vmd-filestore/");

    IedServer_setConnectionIndicationHandler(iedServer, (IedConnectionIndicationHandler) connectionHandler, NULL);

    /* MMS server will be instructed to start listening to client connections. */
    IedServer_start(iedServer, 102);

    if (!IedServer_isRunning(iedServer)) {
        printf("Starting server failed! Exit.\n");
        IedServer_destroy(iedServer);
        exit(-1);
    }

    running = 1;
    signal(SIGINT, sigint_handler);
    FILE *fp;
    char str1[60];
    char str2[60];
    char str3[60];
    char str4[60];
    while (running) {
        uint64_t timestamp = Hal_getTimeInMs();	
        
		IedServer_lockDataModel(iedServer);
        Timestamp iecTimestamp;
        Timestamp_clearFlags(&iecTimestamp);
        Timestamp_setTimeInMilliseconds(&iecTimestamp, timestamp);
        Timestamp_setLeapSecondKnown(&iecTimestamp, true);

        	fp = fopen("c:\\temp\\test.txt" , "r");
        	  if(fp == NULL) {
        		 perror("Error opening file");
        		 return(-1);
        	  }
        	  if( fgets (str1, 60, fp)!=NULL ) {
        		 /* writing content to stdout */
         		 printf("----------\n");
        		 printf(str1);
        		 /* char ref[60] = str;*/
        		 fgets (str2, 60, fp);
        		 printf(str2);
        		 fgets (str3, 60, fp);
        		 printf(str3);
        		 fgets (str4, 60, fp);
        		 printf(str4);
        		 IedServer_updateFloatAttributeValue(iedServer,IEDMODEL_MONT_SIML1_Tmp1_mag_f, str2);
        		 printf("----------\n");
        	  }

	IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_MONT_SIML1_Tmp1_t, &iecTimestamp);
	fclose(fp);
        /* return 0; --never called due to loop *
/*###############Davids Sensor Reading Code End################################*/

        IedServer_unlockDataModel(iedServer);

        Thread_sleep(1000);
    }

    /* stop MMS server - close TCP server socket and all client sockets */
    IedServer_stop(iedServer);

    /* Cleanup - free all resources */
    IedServer_destroy(iedServer);

} /* main() */
