/*
 * static_model.c
 *
 * automatically generated from RIO_TRFX.icd
 */
#include "static_model.h"

static void initializeValues();

extern DataSet iedModelds_External_LLN0_AnIn_std;
extern DataSet iedModelds_External_LLN0_dsAssetHealth;
extern DataSet iedModelds_External_LLN0_DGA;
extern DataSet iedModelds_External_LLN0_Al_St_Gas_Conc;
extern DataSet iedModelds_External_LLN0_Al_St_Gas_ROC;
extern DataSet iedModelds_External_LLN0_Al_St_Outputs;
extern DataSet iedModelds_External_LLN0_SysInd_Meas_Flags;
extern DataSet iedModelds_External_LLN0_SysInd_PGA_State;
extern DataSet iedModelds_External_LLN0_AnIn_opt;
extern DataSet iedModelds_External_LLN0_AI1_Param;
extern DataSet iedModelds_External_LLN0_AI2_Param;
extern DataSet iedModelds_External_LLN0_AI3_Param;
extern DataSet iedModelds_External_LLN0_AI4_Param;
extern DataSet iedModelds_External_LLN0_AI5_Param;
extern DataSet iedModelds_External_LLN0_AI6_Param;
extern DataSet iedModelds_External_LLN0_SysInd_Peripheral_Sch;
extern DataSet iedModelds_External_LLN0_Device_Status;


extern DataSetEntry iedModelds_External_LLN0_AnIn_std_fcda0;
extern DataSetEntry iedModelds_External_LLN0_AnIn_std_fcda1;
extern DataSetEntry iedModelds_External_LLN0_AnIn_std_fcda2;
extern DataSetEntry iedModelds_External_LLN0_AnIn_std_fcda3;
extern DataSetEntry iedModelds_External_LLN0_AnIn_std_fcda4;

DataSetEntry iedModelds_External_LLN0_AnIn_std_fcda0 = {
  "OilSourceA",
  false,
  "MeasGGIO1$MX$AnIn1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AnIn_std_fcda1
};

DataSetEntry iedModelds_External_LLN0_AnIn_std_fcda1 = {
  "OilSourceA",
  false,
  "MeasGGIO1$MX$AnIn2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AnIn_std_fcda2
};

DataSetEntry iedModelds_External_LLN0_AnIn_std_fcda2 = {
  "OilSourceA",
  false,
  "MeasGGIO1$MX$AnIn3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AnIn_std_fcda3
};

DataSetEntry iedModelds_External_LLN0_AnIn_std_fcda3 = {
  "OilSourceA",
  false,
  "MeasGGIO1$MX$AnIn4",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AnIn_std_fcda4
};

DataSetEntry iedModelds_External_LLN0_AnIn_std_fcda4 = {
  "OilSourceA",
  false,
  "MeasGGIO1$MX$AnIn5",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_AnIn_std = {
  "External",
  "LLN0$AnIn_std",
  5,
  &iedModelds_External_LLN0_AnIn_std_fcda0,
  &iedModelds_External_LLN0_dsAssetHealth
};

extern DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda0;
extern DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda1;
extern DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda2;
extern DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda3;
extern DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda4;
extern DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda5;
extern DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda6;
extern DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda7;
extern DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda8;
extern DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda9;
extern DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda10;
extern DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda11;
extern DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda12;

DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda0 = {
  "OilSourceA",
  false,
  "SIML1$MX$H2O",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_dsAssetHealth_fcda1
};

DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda1 = {
  "OilSourceA",
  false,
  "SIML1$MX$Pres",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_dsAssetHealth_fcda2
};

DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda2 = {
  "OilSourceA",
  false,
  "SIML1$MX$H2OTmp",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_dsAssetHealth_fcda3
};

DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda3 = {
  "OilSourceA",
  false,
  "SIML1$MX$H2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_dsAssetHealth_fcda4
};

DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda4 = {
  "OilSourceA",
  false,
  "SIML1$MX$N2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_dsAssetHealth_fcda5
};

DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda5 = {
  "OilSourceA",
  false,
  "SIML1$MX$COppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_dsAssetHealth_fcda6
};

DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda6 = {
  "OilSourceA",
  false,
  "SIML1$MX$CO2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_dsAssetHealth_fcda7
};

DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda7 = {
  "OilSourceA",
  false,
  "SIML1$MX$CH4ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_dsAssetHealth_fcda8
};

DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda8 = {
  "OilSourceA",
  false,
  "SIML1$MX$C2H2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_dsAssetHealth_fcda9
};

DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda9 = {
  "OilSourceA",
  false,
  "SIML1$MX$C2H4ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_dsAssetHealth_fcda10
};

DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda10 = {
  "OilSourceA",
  false,
  "SIML1$MX$C2H6ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_dsAssetHealth_fcda11
};

DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda11 = {
  "OilSourceA",
  false,
  "SIML1$MX$O2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_dsAssetHealth_fcda12
};

DataSetEntry iedModelds_External_LLN0_dsAssetHealth_fcda12 = {
  "OilSourceA",
  false,
  "SIML1$MX$CmbuGas",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_dsAssetHealth = {
  "External",
  "LLN0$dsAssetHealth",
  13,
  &iedModelds_External_LLN0_dsAssetHealth_fcda0,
  &iedModelds_External_LLN0_DGA
};

extern DataSetEntry iedModelds_External_LLN0_DGA_fcda0;
extern DataSetEntry iedModelds_External_LLN0_DGA_fcda1;
extern DataSetEntry iedModelds_External_LLN0_DGA_fcda2;
extern DataSetEntry iedModelds_External_LLN0_DGA_fcda3;
extern DataSetEntry iedModelds_External_LLN0_DGA_fcda4;
extern DataSetEntry iedModelds_External_LLN0_DGA_fcda5;
extern DataSetEntry iedModelds_External_LLN0_DGA_fcda6;
extern DataSetEntry iedModelds_External_LLN0_DGA_fcda7;
extern DataSetEntry iedModelds_External_LLN0_DGA_fcda8;
extern DataSetEntry iedModelds_External_LLN0_DGA_fcda9;
extern DataSetEntry iedModelds_External_LLN0_DGA_fcda10;
extern DataSetEntry iedModelds_External_LLN0_DGA_fcda11;
extern DataSetEntry iedModelds_External_LLN0_DGA_fcda12;

DataSetEntry iedModelds_External_LLN0_DGA_fcda0 = {
  "OilSourceA",
  false,
  "SIML1$MX$H2O",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_DGA_fcda1
};

DataSetEntry iedModelds_External_LLN0_DGA_fcda1 = {
  "OilSourceA",
  false,
  "SIML1$MX$Pres",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_DGA_fcda2
};

DataSetEntry iedModelds_External_LLN0_DGA_fcda2 = {
  "OilSourceA",
  false,
  "SIML1$MX$H2OTmp",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_DGA_fcda3
};

DataSetEntry iedModelds_External_LLN0_DGA_fcda3 = {
  "OilSourceA",
  false,
  "SIML1$MX$H2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_DGA_fcda4
};

DataSetEntry iedModelds_External_LLN0_DGA_fcda4 = {
  "OilSourceA",
  false,
  "SIML1$MX$N2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_DGA_fcda5
};

DataSetEntry iedModelds_External_LLN0_DGA_fcda5 = {
  "OilSourceA",
  false,
  "SIML1$MX$COppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_DGA_fcda6
};

DataSetEntry iedModelds_External_LLN0_DGA_fcda6 = {
  "OilSourceA",
  false,
  "SIML1$MX$CO2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_DGA_fcda7
};

DataSetEntry iedModelds_External_LLN0_DGA_fcda7 = {
  "OilSourceA",
  false,
  "SIML1$MX$CH4ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_DGA_fcda8
};

DataSetEntry iedModelds_External_LLN0_DGA_fcda8 = {
  "OilSourceA",
  false,
  "SIML1$MX$C2H2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_DGA_fcda9
};

DataSetEntry iedModelds_External_LLN0_DGA_fcda9 = {
  "OilSourceA",
  false,
  "SIML1$MX$C2H4ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_DGA_fcda10
};

DataSetEntry iedModelds_External_LLN0_DGA_fcda10 = {
  "OilSourceA",
  false,
  "SIML1$MX$C2H6ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_DGA_fcda11
};

DataSetEntry iedModelds_External_LLN0_DGA_fcda11 = {
  "OilSourceA",
  false,
  "SIML1$MX$O2ppm",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_DGA_fcda12
};

DataSetEntry iedModelds_External_LLN0_DGA_fcda12 = {
  "OilSourceA",
  false,
  "SIML1$MX$CmbuGas",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_DGA = {
  "External",
  "LLN0$DGA",
  13,
  &iedModelds_External_LLN0_DGA_fcda0,
  &iedModelds_External_LLN0_Al_St_Gas_Conc
};

extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda0;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda1;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda2;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda3;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda4;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda5;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda6;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda7;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda8;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda9;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda10;

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda0 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_Conc_fcda1
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda1 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_Conc_fcda2
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda2 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_Conc_fcda3
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda3 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm4",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_Conc_fcda4
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda4 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm5",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_Conc_fcda5
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda5 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm6",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_Conc_fcda6
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda6 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm7",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_Conc_fcda7
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda7 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm8",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_Conc_fcda8
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda8 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm9",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_Conc_fcda9
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda9 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm10",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_Conc_fcda10
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_Conc_fcda10 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm11",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_Al_St_Gas_Conc = {
  "External",
  "LLN0$Al_St_Gas_Conc",
  11,
  &iedModelds_External_LLN0_Al_St_Gas_Conc_fcda0,
  &iedModelds_External_LLN0_Al_St_Gas_ROC
};

extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda0;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda1;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda2;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda3;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda4;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda5;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda6;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda7;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda8;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda9;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda10;

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda0 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm12",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_ROC_fcda1
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda1 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm13",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_ROC_fcda2
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda2 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm14",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_ROC_fcda3
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda3 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm15",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_ROC_fcda4
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda4 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm16",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_ROC_fcda5
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda5 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm17",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_ROC_fcda6
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda6 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm18",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_ROC_fcda7
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda7 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm19",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_ROC_fcda8
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda8 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm20",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_ROC_fcda9
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda9 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm21",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Gas_ROC_fcda10
};

DataSetEntry iedModelds_External_LLN0_Al_St_Gas_ROC_fcda10 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Alm22",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_Al_St_Gas_ROC = {
  "External",
  "LLN0$Al_St_Gas_ROC",
  11,
  &iedModelds_External_LLN0_Al_St_Gas_ROC_fcda0,
  &iedModelds_External_LLN0_Al_St_Outputs
};

extern DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda0;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda1;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda2;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda3;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda4;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda5;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda6;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda7;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda8;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda9;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda10;
extern DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda11;

DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda0 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Outputs_fcda1
};

DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda1 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Outputs_fcda2
};

DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda2 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Outputs_fcda3
};

DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda3 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind4",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Outputs_fcda4
};

DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda4 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind5",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Outputs_fcda5
};

DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda5 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind6",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Outputs_fcda6
};

DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda6 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind7",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Outputs_fcda7
};

DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda7 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind8",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Outputs_fcda8
};

DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda8 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind9",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Outputs_fcda9
};

DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda9 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind10",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Outputs_fcda10
};

DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda10 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind11",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Al_St_Outputs_fcda11
};

DataSetEntry iedModelds_External_LLN0_Al_St_Outputs_fcda11 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind12",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_Al_St_Outputs = {
  "External",
  "LLN0$Al_St_Outputs",
  12,
  &iedModelds_External_LLN0_Al_St_Outputs_fcda0,
  &iedModelds_External_LLN0_SysInd_Meas_Flags
};

extern DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda0;
extern DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda1;
extern DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda2;
extern DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda3;
extern DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda4;
extern DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda5;
extern DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda6;
extern DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda7;
extern DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda8;
extern DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda9;
extern DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda10;
extern DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda11;

DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda0 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind13",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_Meas_Flags_fcda1
};

DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda1 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind14",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_Meas_Flags_fcda2
};

DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda2 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind15",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_Meas_Flags_fcda3
};

DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda3 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind16",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_Meas_Flags_fcda4
};

DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda4 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind17",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_Meas_Flags_fcda5
};

DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda5 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind18",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_Meas_Flags_fcda6
};

DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda6 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind19",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_Meas_Flags_fcda7
};

DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda7 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind20",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_Meas_Flags_fcda8
};

DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda8 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind21",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_Meas_Flags_fcda9
};

DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda9 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind22",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_Meas_Flags_fcda10
};

DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda10 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind23",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_Meas_Flags_fcda11
};

DataSetEntry iedModelds_External_LLN0_SysInd_Meas_Flags_fcda11 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind24",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_SysInd_Meas_Flags = {
  "External",
  "LLN0$SysInd_Meas_Flags",
  12,
  &iedModelds_External_LLN0_SysInd_Meas_Flags_fcda0,
  &iedModelds_External_LLN0_SysInd_PGA_State
};

extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda0;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda1;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda2;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda3;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda4;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda5;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda6;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda7;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda8;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda9;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda10;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda11;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda12;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda13;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda14;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda15;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda16;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda17;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda18;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda19;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda20;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda21;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda22;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda23;
extern DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda24;

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda0 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind25",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda1
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda1 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind26",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda2
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda2 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind27",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda3
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda3 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind28",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda4
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda4 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind29",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda5
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda5 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind30",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda6
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda6 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind31",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda7
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda7 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind32",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda8
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda8 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind33",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda9
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda9 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind34",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda10
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda10 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind35",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda11
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda11 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind36",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda12
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda12 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind37",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda13
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda13 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind38",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda14
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda14 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind39",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda15
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda15 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind40",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda16
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda16 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind41",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda17
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda17 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind42",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda18
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda18 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind43",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda19
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda19 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind44",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda20
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda20 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind45",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda21
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda21 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind46",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda22
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda22 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind47",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda23
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda23 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind48",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda24
};

DataSetEntry iedModelds_External_LLN0_SysInd_PGA_State_fcda24 = {
  "OilSourceA",
  false,
  "MeasGGIO1$ST$Ind49",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_SysInd_PGA_State = {
  "External",
  "LLN0$SysInd_PGA_State",
  25,
  &iedModelds_External_LLN0_SysInd_PGA_State_fcda0,
  &iedModelds_External_LLN0_AnIn_opt
};

extern DataSetEntry iedModelds_External_LLN0_AnIn_opt_fcda0;
extern DataSetEntry iedModelds_External_LLN0_AnIn_opt_fcda1;
extern DataSetEntry iedModelds_External_LLN0_AnIn_opt_fcda2;
extern DataSetEntry iedModelds_External_LLN0_AnIn_opt_fcda3;
extern DataSetEntry iedModelds_External_LLN0_AnIn_opt_fcda4;

DataSetEntry iedModelds_External_LLN0_AnIn_opt_fcda0 = {
  "OilSourceA",
  false,
  "MeasGGIO1$MX$AnIn6",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AnIn_opt_fcda1
};

DataSetEntry iedModelds_External_LLN0_AnIn_opt_fcda1 = {
  "OilSourceA",
  false,
  "MeasGGIO1$MX$AnIn7",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AnIn_opt_fcda2
};

DataSetEntry iedModelds_External_LLN0_AnIn_opt_fcda2 = {
  "OilSourceA",
  false,
  "MeasGGIO1$MX$AnIn8",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AnIn_opt_fcda3
};

DataSetEntry iedModelds_External_LLN0_AnIn_opt_fcda3 = {
  "OilSourceA",
  false,
  "MeasGGIO1$MX$AnIn9",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AnIn_opt_fcda4
};

DataSetEntry iedModelds_External_LLN0_AnIn_opt_fcda4 = {
  "OilSourceA",
  false,
  "MeasGGIO1$MX$AnIn10",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_AnIn_opt = {
  "External",
  "LLN0$AnIn_opt",
  5,
  &iedModelds_External_LLN0_AnIn_opt_fcda0,
  &iedModelds_External_LLN0_AI1_Param
};

extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda0;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda1;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda2;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda3;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda4;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda5;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda6;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda7;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda8;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda9;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda10;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda11;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda12;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda13;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda14;
extern DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda15;

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda0 = {
  "General",
  false,
  "AnIn1GGIO2$MX$AnIn1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda1
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda1 = {
  "General",
  false,
  "AnIn1GGIO2$MX$AnIn2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda2
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda2 = {
  "General",
  false,
  "AnIn1GGIO2$ST$Alm1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda3
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda3 = {
  "General",
  false,
  "AnIn1GGIO2$ST$Alm2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda4
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda4 = {
  "General",
  false,
  "AnIn1GGIO2$ST$Alm3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda5
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda5 = {
  "General",
  false,
  "AnIn1GGIO2$ST$Ind1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda6
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda6 = {
  "General",
  false,
  "AnIn1GGIO2$ST$Ind2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda7
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda7 = {
  "General",
  false,
  "AnIn1GGIO2$ST$Ind3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda8
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda8 = {
  "General",
  false,
  "AnIn1GGIO2$ST$Ind4",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda9
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda9 = {
  "General",
  false,
  "AnIn1GGIO2$ST$Ind5",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda10
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda10 = {
  "General",
  false,
  "AnIn1GGIO2$ST$Ind6",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda11
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda11 = {
  "General",
  false,
  "AnIn1GGIO2$ST$Ind7",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda12
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda12 = {
  "General",
  false,
  "AnIn1GGIO2$ST$Ind8",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda13
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda13 = {
  "General",
  false,
  "AnIn1GGIO2$ST$Ind9",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda14
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda14 = {
  "General",
  false,
  "AnIn1GGIO2$ST$Ind10",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI1_Param_fcda15
};

DataSetEntry iedModelds_External_LLN0_AI1_Param_fcda15 = {
  "General",
  false,
  "AnIn1GGIO2$ST$Ind11",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_AI1_Param = {
  "External",
  "LLN0$AI1_Param",
  16,
  &iedModelds_External_LLN0_AI1_Param_fcda0,
  &iedModelds_External_LLN0_AI2_Param
};

extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda0;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda1;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda2;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda3;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda4;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda5;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda6;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda7;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda8;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda9;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda10;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda11;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda12;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda13;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda14;
extern DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda15;

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda0 = {
  "General",
  false,
  "AnIn2GGIO3$MX$AnIn1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda1
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda1 = {
  "General",
  false,
  "AnIn2GGIO3$MX$AnIn2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda2
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda2 = {
  "General",
  false,
  "AnIn2GGIO3$ST$Alm1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda3
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda3 = {
  "General",
  false,
  "AnIn2GGIO3$ST$Alm2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda4
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda4 = {
  "General",
  false,
  "AnIn2GGIO3$ST$Alm3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda5
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda5 = {
  "General",
  false,
  "AnIn2GGIO3$ST$Ind1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda6
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda6 = {
  "General",
  false,
  "AnIn2GGIO3$ST$Ind2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda7
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda7 = {
  "General",
  false,
  "AnIn2GGIO3$ST$Ind3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda8
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda8 = {
  "General",
  false,
  "AnIn2GGIO3$ST$Ind4",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda9
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda9 = {
  "General",
  false,
  "AnIn2GGIO3$ST$Ind5",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda10
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda10 = {
  "General",
  false,
  "AnIn2GGIO3$ST$Ind6",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda11
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda11 = {
  "General",
  false,
  "AnIn2GGIO3$ST$Ind7",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda12
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda12 = {
  "General",
  false,
  "AnIn2GGIO3$ST$Ind8",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda13
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda13 = {
  "General",
  false,
  "AnIn2GGIO3$ST$Ind9",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda14
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda14 = {
  "General",
  false,
  "AnIn2GGIO3$ST$Ind10",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI2_Param_fcda15
};

DataSetEntry iedModelds_External_LLN0_AI2_Param_fcda15 = {
  "General",
  false,
  "AnIn2GGIO3$ST$Ind11",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_AI2_Param = {
  "External",
  "LLN0$AI2_Param",
  16,
  &iedModelds_External_LLN0_AI2_Param_fcda0,
  &iedModelds_External_LLN0_AI3_Param
};

extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda0;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda1;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda2;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda3;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda4;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda5;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda6;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda7;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda8;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda9;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda10;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda11;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda12;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda13;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda14;
extern DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda15;

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda0 = {
  "General",
  false,
  "AnIn3GGIO4$MX$AnIn1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda1
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda1 = {
  "General",
  false,
  "AnIn3GGIO4$MX$AnIn2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda2
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda2 = {
  "General",
  false,
  "AnIn3GGIO4$ST$Alm1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda3
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda3 = {
  "General",
  false,
  "AnIn3GGIO4$ST$Alm2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda4
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda4 = {
  "General",
  false,
  "AnIn3GGIO4$ST$Alm3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda5
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda5 = {
  "General",
  false,
  "AnIn3GGIO4$ST$Ind1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda6
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda6 = {
  "General",
  false,
  "AnIn3GGIO4$ST$Ind2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda7
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda7 = {
  "General",
  false,
  "AnIn3GGIO4$ST$Ind3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda8
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda8 = {
  "General",
  false,
  "AnIn3GGIO4$ST$Ind4",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda9
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda9 = {
  "General",
  false,
  "AnIn3GGIO4$ST$Ind5",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda10
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda10 = {
  "General",
  false,
  "AnIn3GGIO4$ST$Ind6",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda11
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda11 = {
  "General",
  false,
  "AnIn3GGIO4$ST$Ind7",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda12
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda12 = {
  "General",
  false,
  "AnIn3GGIO4$ST$Ind8",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda13
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda13 = {
  "General",
  false,
  "AnIn3GGIO4$ST$Ind9",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda14
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda14 = {
  "General",
  false,
  "AnIn3GGIO4$ST$Ind10",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI3_Param_fcda15
};

DataSetEntry iedModelds_External_LLN0_AI3_Param_fcda15 = {
  "General",
  false,
  "AnIn3GGIO4$ST$Ind11",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_AI3_Param = {
  "External",
  "LLN0$AI3_Param",
  16,
  &iedModelds_External_LLN0_AI3_Param_fcda0,
  &iedModelds_External_LLN0_AI4_Param
};

extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda0;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda1;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda2;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda3;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda4;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda5;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda6;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda7;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda8;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda9;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda10;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda11;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda12;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda13;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda14;
extern DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda15;

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda0 = {
  "General",
  false,
  "AnIn4GGIO5$MX$AnIn1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda1
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda1 = {
  "General",
  false,
  "AnIn4GGIO5$MX$AnIn2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda2
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda2 = {
  "General",
  false,
  "AnIn4GGIO5$ST$Alm1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda3
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda3 = {
  "General",
  false,
  "AnIn4GGIO5$ST$Alm2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda4
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda4 = {
  "General",
  false,
  "AnIn4GGIO5$ST$Alm3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda5
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda5 = {
  "General",
  false,
  "AnIn4GGIO5$ST$Ind1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda6
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda6 = {
  "General",
  false,
  "AnIn4GGIO5$ST$Ind2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda7
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda7 = {
  "General",
  false,
  "AnIn4GGIO5$ST$Ind3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda8
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda8 = {
  "General",
  false,
  "AnIn4GGIO5$ST$Ind4",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda9
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda9 = {
  "General",
  false,
  "AnIn4GGIO5$ST$Ind5",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda10
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda10 = {
  "General",
  false,
  "AnIn4GGIO5$ST$Ind6",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda11
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda11 = {
  "General",
  false,
  "AnIn4GGIO5$ST$Ind7",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda12
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda12 = {
  "General",
  false,
  "AnIn4GGIO5$ST$Ind8",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda13
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda13 = {
  "General",
  false,
  "AnIn4GGIO5$ST$Ind9",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda14
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda14 = {
  "General",
  false,
  "AnIn4GGIO5$ST$Ind10",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI4_Param_fcda15
};

DataSetEntry iedModelds_External_LLN0_AI4_Param_fcda15 = {
  "General",
  false,
  "AnIn4GGIO5$ST$Ind11",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_AI4_Param = {
  "External",
  "LLN0$AI4_Param",
  16,
  &iedModelds_External_LLN0_AI4_Param_fcda0,
  &iedModelds_External_LLN0_AI5_Param
};

extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda0;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda1;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda2;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda3;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda4;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda5;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda6;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda7;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda8;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda9;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda10;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda11;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda12;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda13;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda14;
extern DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda15;

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda0 = {
  "General",
  false,
  "AnIn5GGIO6$MX$AnIn1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda1
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda1 = {
  "General",
  false,
  "AnIn5GGIO6$MX$AnIn2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda2
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda2 = {
  "General",
  false,
  "AnIn5GGIO6$ST$Alm1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda3
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda3 = {
  "General",
  false,
  "AnIn5GGIO6$ST$Alm2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda4
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda4 = {
  "General",
  false,
  "AnIn5GGIO6$ST$Alm3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda5
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda5 = {
  "General",
  false,
  "AnIn5GGIO6$ST$Ind1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda6
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda6 = {
  "General",
  false,
  "AnIn5GGIO6$ST$Ind2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda7
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda7 = {
  "General",
  false,
  "AnIn5GGIO6$ST$Ind3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda8
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda8 = {
  "General",
  false,
  "AnIn5GGIO6$ST$Ind4",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda9
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda9 = {
  "General",
  false,
  "AnIn5GGIO6$ST$Ind5",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda10
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda10 = {
  "General",
  false,
  "AnIn5GGIO6$ST$Ind6",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda11
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda11 = {
  "General",
  false,
  "AnIn5GGIO6$ST$Ind7",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda12
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda12 = {
  "General",
  false,
  "AnIn5GGIO6$ST$Ind8",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda13
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda13 = {
  "General",
  false,
  "AnIn5GGIO6$ST$Ind9",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda14
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda14 = {
  "General",
  false,
  "AnIn5GGIO6$ST$Ind10",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI5_Param_fcda15
};

DataSetEntry iedModelds_External_LLN0_AI5_Param_fcda15 = {
  "General",
  false,
  "AnIn5GGIO6$ST$Ind11",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_AI5_Param = {
  "External",
  "LLN0$AI5_Param",
  16,
  &iedModelds_External_LLN0_AI5_Param_fcda0,
  &iedModelds_External_LLN0_AI6_Param
};

extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda0;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda1;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda2;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda3;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda4;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda5;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda6;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda7;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda8;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda9;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda10;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda11;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda12;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda13;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda14;
extern DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda15;

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda0 = {
  "General",
  false,
  "AnIn6GGIO7$MX$AnIn1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda1
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda1 = {
  "General",
  false,
  "AnIn6GGIO7$MX$AnIn2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda2
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda2 = {
  "General",
  false,
  "AnIn6GGIO7$ST$Alm1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda3
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda3 = {
  "General",
  false,
  "AnIn6GGIO7$ST$Alm2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda4
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda4 = {
  "General",
  false,
  "AnIn6GGIO7$ST$Alm3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda5
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda5 = {
  "General",
  false,
  "AnIn6GGIO7$ST$Ind1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda6
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda6 = {
  "General",
  false,
  "AnIn6GGIO7$ST$Ind2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda7
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda7 = {
  "General",
  false,
  "AnIn6GGIO7$ST$Ind3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda8
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda8 = {
  "General",
  false,
  "AnIn6GGIO7$ST$Ind4",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda9
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda9 = {
  "General",
  false,
  "AnIn6GGIO7$ST$Ind5",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda10
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda10 = {
  "General",
  false,
  "AnIn6GGIO7$ST$Ind6",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda11
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda11 = {
  "General",
  false,
  "AnIn6GGIO7$ST$Ind7",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda12
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda12 = {
  "General",
  false,
  "AnIn6GGIO7$ST$Ind8",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda13
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda13 = {
  "General",
  false,
  "AnIn6GGIO7$ST$Ind9",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda14
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda14 = {
  "General",
  false,
  "AnIn6GGIO7$ST$Ind10",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_AI6_Param_fcda15
};

DataSetEntry iedModelds_External_LLN0_AI6_Param_fcda15 = {
  "General",
  false,
  "AnIn6GGIO7$ST$Ind11",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_AI6_Param = {
  "External",
  "LLN0$AI6_Param",
  16,
  &iedModelds_External_LLN0_AI6_Param_fcda0,
  &iedModelds_External_LLN0_SysInd_Peripheral_Sch
};

extern DataSetEntry iedModelds_External_LLN0_SysInd_Peripheral_Sch_fcda0;
extern DataSetEntry iedModelds_External_LLN0_SysInd_Peripheral_Sch_fcda1;
extern DataSetEntry iedModelds_External_LLN0_SysInd_Peripheral_Sch_fcda2;
extern DataSetEntry iedModelds_External_LLN0_SysInd_Peripheral_Sch_fcda3;

DataSetEntry iedModelds_External_LLN0_SysInd_Peripheral_Sch_fcda0 = {
  "General",
  false,
  "DevSchGGIO12$ST$Ind1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_Peripheral_Sch_fcda1
};

DataSetEntry iedModelds_External_LLN0_SysInd_Peripheral_Sch_fcda1 = {
  "General",
  false,
  "DevSchGGIO12$ST$Ind2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_Peripheral_Sch_fcda2
};

DataSetEntry iedModelds_External_LLN0_SysInd_Peripheral_Sch_fcda2 = {
  "General",
  false,
  "DevSchGGIO12$ST$Ind3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_SysInd_Peripheral_Sch_fcda3
};

DataSetEntry iedModelds_External_LLN0_SysInd_Peripheral_Sch_fcda3 = {
  "General",
  false,
  "DevSchGGIO12$ST$Ind4",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_SysInd_Peripheral_Sch = {
  "External",
  "LLN0$SysInd_Peripheral_Sch",
  4,
  &iedModelds_External_LLN0_SysInd_Peripheral_Sch_fcda0,
  &iedModelds_External_LLN0_Device_Status
};

extern DataSetEntry iedModelds_External_LLN0_Device_Status_fcda0;
extern DataSetEntry iedModelds_External_LLN0_Device_Status_fcda1;
extern DataSetEntry iedModelds_External_LLN0_Device_Status_fcda2;
extern DataSetEntry iedModelds_External_LLN0_Device_Status_fcda3;
extern DataSetEntry iedModelds_External_LLN0_Device_Status_fcda4;
extern DataSetEntry iedModelds_External_LLN0_Device_Status_fcda5;
extern DataSetEntry iedModelds_External_LLN0_Device_Status_fcda6;
extern DataSetEntry iedModelds_External_LLN0_Device_Status_fcda7;
extern DataSetEntry iedModelds_External_LLN0_Device_Status_fcda8;
extern DataSetEntry iedModelds_External_LLN0_Device_Status_fcda9;

DataSetEntry iedModelds_External_LLN0_Device_Status_fcda0 = {
  "General",
  false,
  "TFXStGGIO11$ST$Ind1",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Device_Status_fcda1
};

DataSetEntry iedModelds_External_LLN0_Device_Status_fcda1 = {
  "General",
  false,
  "TFXStGGIO11$ST$Ind2",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Device_Status_fcda2
};

DataSetEntry iedModelds_External_LLN0_Device_Status_fcda2 = {
  "General",
  false,
  "TFXStGGIO11$ST$Ind3",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Device_Status_fcda3
};

DataSetEntry iedModelds_External_LLN0_Device_Status_fcda3 = {
  "General",
  false,
  "TFXStGGIO11$ST$Ind4",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Device_Status_fcda4
};

DataSetEntry iedModelds_External_LLN0_Device_Status_fcda4 = {
  "General",
  false,
  "TFXStGGIO11$ST$Ind5",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Device_Status_fcda5
};

DataSetEntry iedModelds_External_LLN0_Device_Status_fcda5 = {
  "General",
  false,
  "TFXStGGIO11$ST$Ind6",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Device_Status_fcda6
};

DataSetEntry iedModelds_External_LLN0_Device_Status_fcda6 = {
  "General",
  false,
  "TFXStGGIO11$ST$Ind7",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Device_Status_fcda7
};

DataSetEntry iedModelds_External_LLN0_Device_Status_fcda7 = {
  "General",
  false,
  "TFXStGGIO11$ST$Ind8",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Device_Status_fcda8
};

DataSetEntry iedModelds_External_LLN0_Device_Status_fcda8 = {
  "General",
  false,
  "TFXStGGIO11$ST$Ind9",
  -1,
  NULL,
  NULL,
  &iedModelds_External_LLN0_Device_Status_fcda9
};

DataSetEntry iedModelds_External_LLN0_Device_Status_fcda9 = {
  "General",
  false,
  "TFXStGGIO11$ST$Ind10",
  -1,
  NULL,
  NULL,
  NULL
};

DataSet iedModelds_External_LLN0_Device_Status = {
  "External",
  "LLN0$Device_Status",
  10,
  &iedModelds_External_LLN0_Device_Status_fcda0,
  NULL
};

LogicalDevice iedModel_OilSourceA = {
    LogicalDeviceModelType,
    "OilSourceA",
    (ModelNode*) &iedModel,
    (ModelNode*) &iedModel_General,
    (ModelNode*) &iedModel_OilSourceA_LLN0
};

LogicalNode iedModel_OilSourceA_LLN0 = {
    LogicalNodeModelType,
    "LLN0",
    (ModelNode*) &iedModel_OilSourceA,
    (ModelNode*) &iedModel_OilSourceA_LPHD1,
    (ModelNode*) &iedModel_OilSourceA_LLN0_Mod,
};

DataObject iedModel_OilSourceA_LLN0_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_OilSourceA_LLN0,
    (ModelNode*) &iedModel_OilSourceA_LLN0_Beh,
    (ModelNode*) &iedModel_OilSourceA_LLN0_Mod_stVal,
    0
};

DataAttribute iedModel_OilSourceA_LLN0_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_LLN0_Mod,
    (ModelNode*) &iedModel_OilSourceA_LLN0_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LLN0_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_LLN0_Mod,
    (ModelNode*) &iedModel_OilSourceA_LLN0_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LLN0_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_LLN0_Mod,
    (ModelNode*) &iedModel_OilSourceA_LLN0_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LLN0_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_OilSourceA_LLN0_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_LLN0_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_OilSourceA_LLN0,
    (ModelNode*) &iedModel_OilSourceA_LLN0_Health,
    (ModelNode*) &iedModel_OilSourceA_LLN0_Beh_stVal,
    0
};

DataAttribute iedModel_OilSourceA_LLN0_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_LLN0_Beh,
    (ModelNode*) &iedModel_OilSourceA_LLN0_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LLN0_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_LLN0_Beh,
    (ModelNode*) &iedModel_OilSourceA_LLN0_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LLN0_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_LLN0_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_LLN0_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_OilSourceA_LLN0,
    (ModelNode*) &iedModel_OilSourceA_LLN0_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_LLN0_Health_stVal,
    0
};

DataAttribute iedModel_OilSourceA_LLN0_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_LLN0_Health,
    (ModelNode*) &iedModel_OilSourceA_LLN0_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LLN0_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_LLN0_Health,
    (ModelNode*) &iedModel_OilSourceA_LLN0_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LLN0_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_LLN0_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_LLN0_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_OilSourceA_LLN0,
    NULL,
    (ModelNode*) &iedModel_OilSourceA_LLN0_NamPlt_vendor,
    0
};

DataAttribute iedModel_OilSourceA_LLN0_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_OilSourceA_LLN0_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_LLN0_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LLN0_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_OilSourceA_LLN0_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_LLN0_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LLN0_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_LLN0_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_LLN0_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LLN0_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_OilSourceA_LLN0_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_LLN0_NamPlt_ldNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LLN0_NamPlt_ldNs = {
    DataAttributeModelType,
    "ldNs",
    (ModelNode*) &iedModel_OilSourceA_LLN0_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_OilSourceA_LPHD1 = {
    LogicalNodeModelType,
    "LPHD1",
    (ModelNode*) &iedModel_OilSourceA,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyNam,
};

DataObject iedModel_OilSourceA_LPHD1_PhyNam = {
    DataObjectModelType,
    "PhyNam",
    (ModelNode*) &iedModel_OilSourceA_LPHD1,
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyNam_vendor,
    0
};

DataAttribute iedModel_OilSourceA_LPHD1_PhyNam_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyNam,
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyNam_hwRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LPHD1_PhyNam_hwRev = {
    DataAttributeModelType,
    "hwRev",
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyNam,
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyNam_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LPHD1_PhyNam_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyNam,
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyNam_model,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LPHD1_PhyNam_model = {
    DataAttributeModelType,
    "model",
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyNam,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_LPHD1_PhyHealth = {
    DataObjectModelType,
    "PhyHealth",
    (ModelNode*) &iedModel_OilSourceA_LPHD1,
    (ModelNode*) &iedModel_OilSourceA_LPHD1_Proxy,
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyHealth_stVal,
    0
};

DataAttribute iedModel_OilSourceA_LPHD1_PhyHealth_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyHealth_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LPHD1_PhyHealth_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyHealth_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LPHD1_PhyHealth_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_LPHD1_PhyHealth,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_LPHD1_Proxy = {
    DataObjectModelType,
    "Proxy",
    (ModelNode*) &iedModel_OilSourceA_LPHD1,
    NULL,
    (ModelNode*) &iedModel_OilSourceA_LPHD1_Proxy_stVal,
    0
};

DataAttribute iedModel_OilSourceA_LPHD1_Proxy_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_LPHD1_Proxy,
    (ModelNode*) &iedModel_OilSourceA_LPHD1_Proxy_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LPHD1_Proxy_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_LPHD1_Proxy,
    (ModelNode*) &iedModel_OilSourceA_LPHD1_Proxy_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_LPHD1_Proxy_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_LPHD1_Proxy,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

LogicalNode iedModel_OilSourceA_MeasGGIO1 = {
    LogicalNodeModelType,
    "MeasGGIO1",
    (ModelNode*) &iedModel_OilSourceA,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Mod,
};

DataObject iedModel_OilSourceA_MeasGGIO1_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Beh,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Mod_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Mod,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Mod,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Mod,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Health,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Beh_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Beh,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Beh,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Health_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Health,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Health,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_NamPlt_vendor,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_NamPlt_lnNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_NamPlt_lnNs = {
    DataAttributeModelType,
    "lnNs",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_AnIn1 = {
    DataObjectModelType,
    "AnIn1",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1_mag,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1_q,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn1_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1_d,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn1_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_AnIn2 = {
    DataObjectModelType,
    "AnIn2",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2_mag,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2_q,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn2_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2_d,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn2_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2_units,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2_units_multiplier,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn2_units_multiplier = {
    DataAttributeModelType,
    "multiplier",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_AnIn3 = {
    DataObjectModelType,
    "AnIn3",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3_mag,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3_q,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn3_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3_d,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn3_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3_units,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3_units_multiplier,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn3_units_multiplier = {
    DataAttributeModelType,
    "multiplier",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_AnIn4 = {
    DataObjectModelType,
    "AnIn4",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4_mag,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn4_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4_q,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn4_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn4_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4_d,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn4_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4_units,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4_units_multiplier,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn4_units_multiplier = {
    DataAttributeModelType,
    "multiplier",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_AnIn5 = {
    DataObjectModelType,
    "AnIn5",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5_mag,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn5_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5_q,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn5_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn5_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5_d,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn5_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5_units,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5_units_multiplier,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn5_units_multiplier = {
    DataAttributeModelType,
    "multiplier",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn5,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_AnIn6 = {
    DataObjectModelType,
    "AnIn6",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6_mag,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn6_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6_q,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn6_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn6_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6_d,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn6_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6_units,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6_units_multiplier,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn6_units_multiplier = {
    DataAttributeModelType,
    "multiplier",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn6,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_AnIn7 = {
    DataObjectModelType,
    "AnIn7",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7_mag,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn7_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7_q,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn7_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn7_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7_d,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn7_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7_units,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7_units_multiplier,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn7_units_multiplier = {
    DataAttributeModelType,
    "multiplier",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn7,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_AnIn8 = {
    DataObjectModelType,
    "AnIn8",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8_mag,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn8_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8_q,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn8_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn8_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8_d,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn8_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8_units,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8_units_multiplier,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn8_units_multiplier = {
    DataAttributeModelType,
    "multiplier",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn8,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_AnIn9 = {
    DataObjectModelType,
    "AnIn9",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9_mag,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn9_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9_q,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn9_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn9_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9_d,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn9_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9_units,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9_units_multiplier,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn9_units_multiplier = {
    DataAttributeModelType,
    "multiplier",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn9,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_AnIn10 = {
    DataObjectModelType,
    "AnIn10",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10_mag,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn10_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10_q,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn10_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn10_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10_d,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn10_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10_units,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10_units_multiplier,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn10_units_multiplier = {
    DataAttributeModelType,
    "multiplier",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_AnIn10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_AnIn10,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm1 = {
    DataObjectModelType,
    "Alm1",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm2,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm1_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm2 = {
    DataObjectModelType,
    "Alm2",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm3,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm2_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm2,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm2,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm2,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm3 = {
    DataObjectModelType,
    "Alm3",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm4,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm3_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm3,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm3,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm3,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm4 = {
    DataObjectModelType,
    "Alm4",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm5,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm4_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm4,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm4,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm4,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm5 = {
    DataObjectModelType,
    "Alm5",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm6,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm5_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm5,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm5,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm5,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm5,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm6 = {
    DataObjectModelType,
    "Alm6",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm7,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm6_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm6,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm6,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm6,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm6,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm7 = {
    DataObjectModelType,
    "Alm7",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm8,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm7_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm7,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm7,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm7,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm7,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm8 = {
    DataObjectModelType,
    "Alm8",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm9,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm8_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm8,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm8,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm8,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm8,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm9 = {
    DataObjectModelType,
    "Alm9",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm10,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm9_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm9,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm9,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm9,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm9,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm10 = {
    DataObjectModelType,
    "Alm10",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm11,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm10_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm10,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm10,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm10,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm10,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm11 = {
    DataObjectModelType,
    "Alm11",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm12,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm11_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm11,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm11,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm11,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm11_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm11,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm12 = {
    DataObjectModelType,
    "Alm12",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm13,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm12_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm12_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm12,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm12_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm12_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm12,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm12_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm12_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm12,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm12_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm12_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm12,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm13 = {
    DataObjectModelType,
    "Alm13",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm14,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm13_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm13_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm13,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm13_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm13_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm13,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm13_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm13_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm13,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm13_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm13_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm13,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm14 = {
    DataObjectModelType,
    "Alm14",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm15,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm14_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm14_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm14,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm14_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm14_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm14,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm14_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm14_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm14,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm14_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm14_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm14,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm15 = {
    DataObjectModelType,
    "Alm15",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm16,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm15_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm15_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm15,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm15_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm15_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm15,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm15_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm15_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm15,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm15_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm15_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm15,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm16 = {
    DataObjectModelType,
    "Alm16",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm17,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm16_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm16_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm16,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm16_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm16_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm16,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm16_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm16_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm16,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm16_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm16_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm16,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm17 = {
    DataObjectModelType,
    "Alm17",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm18,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm17_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm17_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm17,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm17_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm17_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm17,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm17_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm17_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm17,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm17_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm17_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm17,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm18 = {
    DataObjectModelType,
    "Alm18",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm19,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm18_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm18_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm18,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm18_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm18_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm18,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm18_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm18_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm18,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm18_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm18_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm18,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm19 = {
    DataObjectModelType,
    "Alm19",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm20,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm19_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm19_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm19,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm19_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm19_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm19,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm19_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm19_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm19,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm19_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm19_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm19,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm20 = {
    DataObjectModelType,
    "Alm20",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm21,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm20_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm20_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm20,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm20_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm20_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm20,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm20_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm20_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm20,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm20_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm20_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm20,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm21 = {
    DataObjectModelType,
    "Alm21",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm22,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm21_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm21_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm21,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm21_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm21_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm21,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm21_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm21_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm21,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm21_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm21_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm21,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Alm22 = {
    DataObjectModelType,
    "Alm22",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm22_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm22_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm22,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm22_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm22_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm22,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm22_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm22_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm22,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm22_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Alm22_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Alm22,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind2,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind1_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind3,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind2_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind2,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind2,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind2,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind4,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind3_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind3,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind3,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind3,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind5,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind4_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind4,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind4,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind4,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind5 = {
    DataObjectModelType,
    "Ind5",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind6,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind5_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind5,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind5,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind5,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind5,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind6 = {
    DataObjectModelType,
    "Ind6",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind7,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind6_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind6,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind6,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind6,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind6,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind7 = {
    DataObjectModelType,
    "Ind7",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind8,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind7_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind7,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind7,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind7,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind7,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind8 = {
    DataObjectModelType,
    "Ind8",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind9,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind8_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind8,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind8,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind8,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind8,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind9 = {
    DataObjectModelType,
    "Ind9",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind10,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind9_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind9,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind9,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind9,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind9,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind10 = {
    DataObjectModelType,
    "Ind10",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind11,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind10_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind10,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind10,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind10,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind10,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind11 = {
    DataObjectModelType,
    "Ind11",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind12,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind11_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind11,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind11,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind11,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind11_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind11,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind12 = {
    DataObjectModelType,
    "Ind12",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind13,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind12_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind12_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind12,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind12_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind12_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind12,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind12_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind12_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind12,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind12_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind12_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind12,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind13 = {
    DataObjectModelType,
    "Ind13",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind14,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind13_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind13_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind13,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind13_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind13_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind13,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind13_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind13_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind13,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind13_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind13_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind13,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind14 = {
    DataObjectModelType,
    "Ind14",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind15,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind14_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind14_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind14,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind14_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind14_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind14,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind14_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind14_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind14,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind14_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind14_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind14,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind15 = {
    DataObjectModelType,
    "Ind15",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind16,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind15_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind15_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind15,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind15_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind15_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind15,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind15_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind15_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind15,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind15_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind15_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind15,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind16 = {
    DataObjectModelType,
    "Ind16",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind17,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind16_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind16_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind16,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind16_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind16_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind16,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind16_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind16_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind16,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind16_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind16_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind16,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind17 = {
    DataObjectModelType,
    "Ind17",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind18,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind17_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind17_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind17,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind17_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind17_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind17,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind17_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind17_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind17,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind17_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind17_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind17,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind18 = {
    DataObjectModelType,
    "Ind18",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind19,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind18_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind18_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind18,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind18_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind18_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind18,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind18_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind18_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind18,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind18_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind18_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind18,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind19 = {
    DataObjectModelType,
    "Ind19",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind20,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind19_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind19_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind19,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind19_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind19_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind19,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind19_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind19_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind19,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind19_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind19_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind19,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind20 = {
    DataObjectModelType,
    "Ind20",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind21,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind20_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind20_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind20,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind20_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind20_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind20,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind20_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind20_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind20,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind20_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind20_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind20,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind21 = {
    DataObjectModelType,
    "Ind21",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind22,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind21_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind21_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind21,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind21_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind21_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind21,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind21_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind21_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind21,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind21_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind21_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind21,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind22 = {
    DataObjectModelType,
    "Ind22",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind23,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind22_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind22_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind22,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind22_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind22_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind22,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind22_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind22_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind22,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind22_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind22_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind22,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind23 = {
    DataObjectModelType,
    "Ind23",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind24,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind23_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind23_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind23,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind23_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind23_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind23,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind23_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind23_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind23,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind23_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind23_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind23,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind24 = {
    DataObjectModelType,
    "Ind24",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind25,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind24_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind24_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind24,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind24_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind24_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind24,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind24_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind24_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind24,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind24_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind24_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind24,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind25 = {
    DataObjectModelType,
    "Ind25",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind26,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind25_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind25_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind25,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind25_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind25_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind25,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind25_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind25_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind25,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind25_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind25_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind25,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind26 = {
    DataObjectModelType,
    "Ind26",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind27,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind26_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind26_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind26,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind26_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind26_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind26,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind26_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind26_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind26,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind26_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind26_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind26,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind27 = {
    DataObjectModelType,
    "Ind27",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind28,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind27_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind27_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind27,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind27_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind27_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind27,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind27_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind27_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind27,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind27_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind27_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind27,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind28 = {
    DataObjectModelType,
    "Ind28",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind29,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind28_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind28_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind28,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind28_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind28_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind28,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind28_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind28_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind28,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind28_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind28_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind28,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind29 = {
    DataObjectModelType,
    "Ind29",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind30,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind29_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind29_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind29,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind29_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind29_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind29,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind29_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind29_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind29,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind29_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind29_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind29,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind30 = {
    DataObjectModelType,
    "Ind30",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind31,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind30_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind30_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind30,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind30_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind30_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind30,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind30_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind30_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind30,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind30_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind30_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind30,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind31 = {
    DataObjectModelType,
    "Ind31",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind32,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind31_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind31_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind31,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind31_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind31_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind31,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind31_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind31_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind31,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind31_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind31_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind31,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind32 = {
    DataObjectModelType,
    "Ind32",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind33,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind32_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind32_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind32,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind32_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind32_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind32,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind32_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind32_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind32,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind32_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind32_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind32,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind33 = {
    DataObjectModelType,
    "Ind33",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind34,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind33_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind33_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind33,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind33_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind33_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind33,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind33_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind33_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind33,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind33_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind33_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind33,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind34 = {
    DataObjectModelType,
    "Ind34",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind35,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind34_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind34_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind34,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind34_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind34_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind34,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind34_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind34_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind34,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind34_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind34_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind34,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind35 = {
    DataObjectModelType,
    "Ind35",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind36,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind35_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind35_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind35,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind35_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind35_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind35,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind35_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind35_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind35,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind35_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind35_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind35,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind36 = {
    DataObjectModelType,
    "Ind36",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind37,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind36_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind36_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind36,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind36_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind36_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind36,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind36_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind36_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind36,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind36_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind36_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind36,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind37 = {
    DataObjectModelType,
    "Ind37",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind38,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind37_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind37_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind37,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind37_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind37_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind37,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind37_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind37_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind37,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind37_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind37_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind37,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind38 = {
    DataObjectModelType,
    "Ind38",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind39,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind38_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind38_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind38,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind38_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind38_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind38,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind38_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind38_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind38,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind38_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind38_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind38,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind39 = {
    DataObjectModelType,
    "Ind39",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind40,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind39_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind39_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind39,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind39_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind39_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind39,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind39_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind39_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind39,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind39_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind39_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind39,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind40 = {
    DataObjectModelType,
    "Ind40",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind41,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind40_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind40_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind40,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind40_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind40_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind40,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind40_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind40_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind40,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind40_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind40_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind40,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind41 = {
    DataObjectModelType,
    "Ind41",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind42,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind41_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind41_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind41,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind41_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind41_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind41,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind41_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind41_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind41,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind41_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind41_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind41,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind42 = {
    DataObjectModelType,
    "Ind42",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind43,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind42_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind42_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind42,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind42_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind42_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind42,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind42_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind42_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind42,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind42_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind42_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind42,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind43 = {
    DataObjectModelType,
    "Ind43",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind44,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind43_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind43_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind43,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind43_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind43_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind43,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind43_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind43_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind43,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind43_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind43_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind43,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind44 = {
    DataObjectModelType,
    "Ind44",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind45,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind44_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind44_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind44,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind44_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind44_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind44,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind44_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind44_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind44,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind44_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind44_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind44,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind45 = {
    DataObjectModelType,
    "Ind45",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind46,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind45_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind45_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind45,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind45_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind45_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind45,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind45_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind45_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind45,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind45_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind45_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind45,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind46 = {
    DataObjectModelType,
    "Ind46",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind47,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind46_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind46_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind46,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind46_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind46_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind46,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind46_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind46_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind46,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind46_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind46_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind46,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind47 = {
    DataObjectModelType,
    "Ind47",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind48,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind47_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind47_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind47,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind47_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind47_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind47,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind47_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind47_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind47,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind47_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind47_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind47,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind48 = {
    DataObjectModelType,
    "Ind48",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind49,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind48_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind48_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind48,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind48_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind48_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind48,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind48_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind48_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind48,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind48_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind48_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind48,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_MeasGGIO1_Ind49 = {
    DataObjectModelType,
    "Ind49",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1,
    NULL,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind49_stVal,
    0
};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind49_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind49,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind49_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind49_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind49,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind49_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind49_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind49,
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind49_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_MeasGGIO1_Ind49_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_MeasGGIO1_Ind49,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_OilSourceA_StGGIO2 = {
    LogicalNodeModelType,
    "StGGIO2",
    (ModelNode*) &iedModel_OilSourceA,
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Mod,
};

DataObject iedModel_OilSourceA_StGGIO2_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Beh,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Mod_stVal,
    0
};

DataAttribute iedModel_OilSourceA_StGGIO2_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Mod,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Mod,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Mod,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_StGGIO2_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Health,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Beh_stVal,
    0
};

DataAttribute iedModel_OilSourceA_StGGIO2_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Beh,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Beh,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_StGGIO2_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Health_stVal,
    0
};

DataAttribute iedModel_OilSourceA_StGGIO2_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Health,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Health,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_StGGIO2_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind1,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_NamPlt_vendor,
    0
};

DataAttribute iedModel_OilSourceA_StGGIO2_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_NamPlt_lnNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_NamPlt_lnNs = {
    DataAttributeModelType,
    "lnNs",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_StGGIO2_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind2,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind1_stVal,
    0
};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind1,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind1,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind1,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_StGGIO2_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind3,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind2_stVal,
    0
};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind2,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind2,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind2,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_StGGIO2_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind4,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind3_stVal,
    0
};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind3,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind3,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind3,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_StGGIO2_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind5,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind4_stVal,
    0
};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind4,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind4,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind4,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_StGGIO2_Ind5 = {
    DataObjectModelType,
    "Ind5",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2,
    NULL,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind5_stVal,
    0
};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind5,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind5,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind5,
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_StGGIO2_Ind5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_StGGIO2_Ind5,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_OilSourceA_SIML1 = {
    LogicalNodeModelType,
    "SIML1",
    (ModelNode*) &iedModel_OilSourceA,
    NULL,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Mod,
};

DataObject iedModel_OilSourceA_SIML1_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Beh,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Mod_stVal,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Mod,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Mod,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Mod,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Health,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Beh_stVal,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Beh,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Beh,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Health_stVal,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Health,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Health,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres,
    (ModelNode*) &iedModel_OilSourceA_SIML1_NamPlt_vendor,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_OilSourceA_SIML1_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_SIML1_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_OilSourceA_SIML1_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_SIML1_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_SIML1_NamPlt,
    (ModelNode*) &iedModel_OilSourceA_SIML1_NamPlt_lnNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_NamPlt_lnNs = {
    DataAttributeModelType,
    "lnNs",
    (ModelNode*) &iedModel_OilSourceA_SIML1_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_Pres = {
    DataObjectModelType,
    "Pres",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres_mag,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_Pres_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres_q,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_Pres_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_Pres_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_Pres_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_Pres_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres_d,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_Pres_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres_units,
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres_units_multiplier,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_Pres_units_multiplier = {
    DataAttributeModelType,
    "multiplier",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_Pres_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_SIML1_Pres,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_H2O = {
    DataObjectModelType,
    "H2O",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O_mag,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_H2O_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O_q,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2O_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2O_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2O_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2O_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O_d,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2O_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2O_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2O,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_H2OTmp = {
    DataObjectModelType,
    "H2OTmp",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp_mag,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_H2OTmp_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp_q,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2OTmp_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2OTmp_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2OTmp_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2OTmp_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp_d,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2OTmp_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2OTmp_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2OTmp,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_H2ppm = {
    DataObjectModelType,
    "H2ppm",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm_mag,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_H2ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm_q,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2ppm_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm_d,
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2ppm_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_H2ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_SIML1_H2ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_N2ppm = {
    DataObjectModelType,
    "N2ppm",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm_mag,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_N2ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm_q,
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_N2ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_N2ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_N2ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_N2ppm_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm_d,
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_N2ppm_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_N2ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_SIML1_N2ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_COppm = {
    DataObjectModelType,
    "COppm",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm_mag,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_COppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm_q,
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_COppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_COppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_COppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_COppm_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm_d,
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_COppm_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_COppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_SIML1_COppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_CO2ppm = {
    DataObjectModelType,
    "CO2ppm",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm_mag,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_CO2ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm_q,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CO2ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CO2ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CO2ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CO2ppm_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm_d,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CO2ppm_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CO2ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CO2ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_CH4ppm = {
    DataObjectModelType,
    "CH4ppm",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm_mag,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_CH4ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm_q,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CH4ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CH4ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CH4ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CH4ppm_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm_d,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CH4ppm_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CH4ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CH4ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_C2H2ppm = {
    DataObjectModelType,
    "C2H2ppm",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm_mag,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_C2H2ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm_q,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H2ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H2ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H2ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H2ppm_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm_d,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H2ppm_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H2ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H2ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_C2H4ppm = {
    DataObjectModelType,
    "C2H4ppm",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm_mag,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_C2H4ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm_q,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H4ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H4ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H4ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H4ppm_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm_d,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H4ppm_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H4ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H4ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_C2H6ppm = {
    DataObjectModelType,
    "C2H6ppm",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm_mag,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_C2H6ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm_q,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H6ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H6ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H6ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H6ppm_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm_d,
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H6ppm_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_C2H6ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_SIML1_C2H6ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_O2ppm = {
    DataObjectModelType,
    "O2ppm",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas,
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm_mag,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_O2ppm_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm_q,
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_O2ppm_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_O2ppm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_O2ppm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_O2ppm_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm_d,
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_O2ppm_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_O2ppm_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_SIML1_O2ppm,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_CmbuGas = {
    DataObjectModelType,
    "CmbuGas",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_InsAlm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas_mag,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_CmbuGas_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas_q,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CmbuGas_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CmbuGas_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CmbuGas_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CmbuGas_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas_d,
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CmbuGas_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_CmbuGas_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_OilSourceA_SIML1_CmbuGas,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_InsAlm = {
    DataObjectModelType,
    "InsAlm",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    (ModelNode*) &iedModel_OilSourceA_SIML1_TmpAlm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_InsAlm_stVal,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_InsAlm_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_SIML1_InsAlm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_InsAlm_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_InsAlm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_InsAlm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_InsAlm_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_InsAlm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_InsAlm,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_OilSourceA_SIML1_TmpAlm = {
    DataObjectModelType,
    "TmpAlm",
    (ModelNode*) &iedModel_OilSourceA_SIML1,
    NULL,
    (ModelNode*) &iedModel_OilSourceA_SIML1_TmpAlm_stVal,
    0
};

DataAttribute iedModel_OilSourceA_SIML1_TmpAlm_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_OilSourceA_SIML1_TmpAlm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_TmpAlm_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_TmpAlm_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_OilSourceA_SIML1_TmpAlm,
    (ModelNode*) &iedModel_OilSourceA_SIML1_TmpAlm_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_OilSourceA_SIML1_TmpAlm_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_OilSourceA_SIML1_TmpAlm,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};


LogicalDevice iedModel_General = {
    LogicalDeviceModelType,
    "General",
    (ModelNode*) &iedModel,
    (ModelNode*) &iedModel_Dummy,
    (ModelNode*) &iedModel_General_LLN0
};

LogicalNode iedModel_General_LLN0 = {
    LogicalNodeModelType,
    "LLN0",
    (ModelNode*) &iedModel_General,
    (ModelNode*) &iedModel_General_LPHD1,
    (ModelNode*) &iedModel_General_LLN0_Mod,
};

DataObject iedModel_General_LLN0_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_General_LLN0,
    (ModelNode*) &iedModel_General_LLN0_Beh,
    (ModelNode*) &iedModel_General_LLN0_Mod_stVal,
    0
};

DataAttribute iedModel_General_LLN0_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_LLN0_Mod,
    (ModelNode*) &iedModel_General_LLN0_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_LLN0_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_LLN0_Mod,
    (ModelNode*) &iedModel_General_LLN0_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_LLN0_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_LLN0_Mod,
    (ModelNode*) &iedModel_General_LLN0_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_LLN0_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_General_LLN0_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_General_LLN0_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_General_LLN0,
    (ModelNode*) &iedModel_General_LLN0_Health,
    (ModelNode*) &iedModel_General_LLN0_Beh_stVal,
    0
};

DataAttribute iedModel_General_LLN0_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_LLN0_Beh,
    (ModelNode*) &iedModel_General_LLN0_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_LLN0_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_LLN0_Beh,
    (ModelNode*) &iedModel_General_LLN0_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_LLN0_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_LLN0_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_LLN0_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_General_LLN0,
    (ModelNode*) &iedModel_General_LLN0_NamPlt,
    (ModelNode*) &iedModel_General_LLN0_Health_stVal,
    0
};

DataAttribute iedModel_General_LLN0_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_LLN0_Health,
    (ModelNode*) &iedModel_General_LLN0_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_LLN0_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_LLN0_Health,
    (ModelNode*) &iedModel_General_LLN0_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_LLN0_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_LLN0_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_LLN0_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_General_LLN0,
    NULL,
    (ModelNode*) &iedModel_General_LLN0_NamPlt_vendor,
    0
};

DataAttribute iedModel_General_LLN0_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_General_LLN0_NamPlt,
    (ModelNode*) &iedModel_General_LLN0_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_LLN0_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_General_LLN0_NamPlt,
    (ModelNode*) &iedModel_General_LLN0_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_LLN0_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_LLN0_NamPlt,
    (ModelNode*) &iedModel_General_LLN0_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_LLN0_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_General_LLN0_NamPlt,
    (ModelNode*) &iedModel_General_LLN0_NamPlt_ldNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_LLN0_NamPlt_ldNs = {
    DataAttributeModelType,
    "ldNs",
    (ModelNode*) &iedModel_General_LLN0_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_General_LPHD1 = {
    LogicalNodeModelType,
    "LPHD1",
    (ModelNode*) &iedModel_General,
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_LPHD1_PhyNam,
};

DataObject iedModel_General_LPHD1_PhyNam = {
    DataObjectModelType,
    "PhyNam",
    (ModelNode*) &iedModel_General_LPHD1,
    (ModelNode*) &iedModel_General_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_General_LPHD1_PhyNam_vendor,
    0
};

DataAttribute iedModel_General_LPHD1_PhyNam_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_General_LPHD1_PhyNam,
    (ModelNode*) &iedModel_General_LPHD1_PhyNam_hwRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_LPHD1_PhyNam_hwRev = {
    DataAttributeModelType,
    "hwRev",
    (ModelNode*) &iedModel_General_LPHD1_PhyNam,
    (ModelNode*) &iedModel_General_LPHD1_PhyNam_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_LPHD1_PhyNam_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_General_LPHD1_PhyNam,
    (ModelNode*) &iedModel_General_LPHD1_PhyNam_model,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_LPHD1_PhyNam_model = {
    DataAttributeModelType,
    "model",
    (ModelNode*) &iedModel_General_LPHD1_PhyNam,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_LPHD1_PhyHealth = {
    DataObjectModelType,
    "PhyHealth",
    (ModelNode*) &iedModel_General_LPHD1,
    (ModelNode*) &iedModel_General_LPHD1_Proxy,
    (ModelNode*) &iedModel_General_LPHD1_PhyHealth_stVal,
    0
};

DataAttribute iedModel_General_LPHD1_PhyHealth_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_General_LPHD1_PhyHealth_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_LPHD1_PhyHealth_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_General_LPHD1_PhyHealth_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_LPHD1_PhyHealth_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_LPHD1_PhyHealth,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_LPHD1_Proxy = {
    DataObjectModelType,
    "Proxy",
    (ModelNode*) &iedModel_General_LPHD1,
    NULL,
    (ModelNode*) &iedModel_General_LPHD1_Proxy_stVal,
    0
};

DataAttribute iedModel_General_LPHD1_Proxy_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_LPHD1_Proxy,
    (ModelNode*) &iedModel_General_LPHD1_Proxy_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_LPHD1_Proxy_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_LPHD1_Proxy,
    (ModelNode*) &iedModel_General_LPHD1_Proxy_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_LPHD1_Proxy_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_LPHD1_Proxy,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

LogicalNode iedModel_General_AnIn1GGIO2 = {
    LogicalNodeModelType,
    "AnIn1GGIO2",
    (ModelNode*) &iedModel_General,
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Mod,
};

DataObject iedModel_General_AnIn1GGIO2_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Beh,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Mod_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Mod,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Mod,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Mod,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Health,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Beh_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Beh,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Beh,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_NamPlt,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Health_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Health,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Health,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn1,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_NamPlt_vendor,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_NamPlt,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_NamPlt,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_NamPlt,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_NamPlt_lnNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_NamPlt_lnNs = {
    DataAttributeModelType,
    "lnNs",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_AnIn1 = {
    DataObjectModelType,
    "AnIn1",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn1_mag,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_AnIn1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn1,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn1_q,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn1_mag_i,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_AnIn1_mag_i = {
    DataAttributeModelType,
    "i",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_AnIn1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn1,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_AnIn1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn1,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_AnIn1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_AnIn2 = {
    DataObjectModelType,
    "AnIn2",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm1,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2_mag,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_AnIn2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2_q,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_AnIn2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_AnIn2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_AnIn2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_AnIn2_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2_d,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_AnIn2_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_AnIn2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_AnIn2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Alm1 = {
    DataObjectModelType,
    "Alm1",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm1_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Alm1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm1,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Alm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm1,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Alm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm1,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Alm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Alm2 = {
    DataObjectModelType,
    "Alm2",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm3,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm2_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Alm2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Alm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Alm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Alm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Alm3 = {
    DataObjectModelType,
    "Alm3",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind1,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm3_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Alm3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm3,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Alm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm3,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Alm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm3,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Alm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Alm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind1_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind1,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind1,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind1,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind3,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind2_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind4,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind3_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind3,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind3,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind3,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind5,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind4_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind4,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind4,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind4,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Ind5 = {
    DataObjectModelType,
    "Ind5",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind6,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind5_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Ind5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind5,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind5,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind5,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind5,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Ind6 = {
    DataObjectModelType,
    "Ind6",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind7,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind6_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Ind6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind6,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind6,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind6,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind6,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Ind7 = {
    DataObjectModelType,
    "Ind7",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind8,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind7_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Ind7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind7,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind7,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind7,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind7,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Ind8 = {
    DataObjectModelType,
    "Ind8",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind9,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind8_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Ind8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind8,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind8,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind8,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind8,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Ind9 = {
    DataObjectModelType,
    "Ind9",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind10,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind9_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Ind9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind9,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind9,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind9,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind9,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Ind10 = {
    DataObjectModelType,
    "Ind10",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind11,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind10_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Ind10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind10,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind10,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind10,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind10,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn1GGIO2_Ind11 = {
    DataObjectModelType,
    "Ind11",
    (ModelNode*) &iedModel_General_AnIn1GGIO2,
    NULL,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind11_stVal,
    0
};

DataAttribute iedModel_General_AnIn1GGIO2_Ind11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind11,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind11,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind11,
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind11_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn1GGIO2_Ind11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn1GGIO2_Ind11,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_General_AnIn2GGIO3 = {
    LogicalNodeModelType,
    "AnIn2GGIO3",
    (ModelNode*) &iedModel_General,
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Mod,
};

DataObject iedModel_General_AnIn2GGIO3_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Beh,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Mod_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Mod,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Mod,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Mod,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Health,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Beh_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Beh,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Beh,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_NamPlt,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Health_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Health,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Health,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn1,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_NamPlt_vendor,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_NamPlt,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_NamPlt,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_NamPlt,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_NamPlt_lnNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_NamPlt_lnNs = {
    DataAttributeModelType,
    "lnNs",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_AnIn1 = {
    DataObjectModelType,
    "AnIn1",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn1_mag,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_AnIn1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn1,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn1_q,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn1_mag_i,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_AnIn1_mag_i = {
    DataAttributeModelType,
    "i",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_AnIn1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn1,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_AnIn1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn1,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_AnIn1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_AnIn2 = {
    DataObjectModelType,
    "AnIn2",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm1,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2_mag,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_AnIn2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2_q,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_AnIn2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_AnIn2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_AnIn2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_AnIn2_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2_d,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_AnIn2_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_AnIn2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_AnIn2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Alm1 = {
    DataObjectModelType,
    "Alm1",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm2,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm1_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Alm1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm1,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Alm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm1,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Alm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm1,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Alm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Alm2 = {
    DataObjectModelType,
    "Alm2",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm2_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Alm2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm2,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Alm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm2,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Alm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm2,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Alm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Alm3 = {
    DataObjectModelType,
    "Alm3",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind1,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm3_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Alm3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Alm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Alm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Alm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Alm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind2,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind1_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind1,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind1,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind1,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind2_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind2,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind2,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind2,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind4,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind3_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind5,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind4_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind4,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind4,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind4,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Ind5 = {
    DataObjectModelType,
    "Ind5",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind6,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind5_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Ind5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind5,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind5,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind5,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind5,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Ind6 = {
    DataObjectModelType,
    "Ind6",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind7,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind6_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Ind6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind6,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind6,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind6,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind6,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Ind7 = {
    DataObjectModelType,
    "Ind7",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind8,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind7_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Ind7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind7,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind7,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind7,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind7,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Ind8 = {
    DataObjectModelType,
    "Ind8",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind9,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind8_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Ind8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind8,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind8,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind8,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind8,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Ind9 = {
    DataObjectModelType,
    "Ind9",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind10,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind9_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Ind9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind9,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind9,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind9,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind9,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Ind10 = {
    DataObjectModelType,
    "Ind10",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind11,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind10_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Ind10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind10,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind10,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind10,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind10,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn2GGIO3_Ind11 = {
    DataObjectModelType,
    "Ind11",
    (ModelNode*) &iedModel_General_AnIn2GGIO3,
    NULL,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind11_stVal,
    0
};

DataAttribute iedModel_General_AnIn2GGIO3_Ind11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind11,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind11,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind11,
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind11_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn2GGIO3_Ind11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn2GGIO3_Ind11,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_General_AnIn3GGIO4 = {
    LogicalNodeModelType,
    "AnIn3GGIO4",
    (ModelNode*) &iedModel_General,
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Mod,
};

DataObject iedModel_General_AnIn3GGIO4_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Beh,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Mod_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Mod,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Mod,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Mod,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Health,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Beh_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Beh,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Beh,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_NamPlt,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Health_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Health,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Health,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn1,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_NamPlt_vendor,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_NamPlt,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_NamPlt,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_NamPlt,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_NamPlt_lnNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_NamPlt_lnNs = {
    DataAttributeModelType,
    "lnNs",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_AnIn1 = {
    DataObjectModelType,
    "AnIn1",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn1_mag,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_AnIn1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn1,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn1_q,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn1_mag_i,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_AnIn1_mag_i = {
    DataAttributeModelType,
    "i",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_AnIn1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn1,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_AnIn1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn1,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_AnIn1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_AnIn2 = {
    DataObjectModelType,
    "AnIn2",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm1,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2_mag,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_AnIn2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2_q,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_AnIn2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_AnIn2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_AnIn2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_AnIn2_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2_d,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_AnIn2_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_AnIn2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_AnIn2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Alm1 = {
    DataObjectModelType,
    "Alm1",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm2,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm1_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Alm1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm1,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Alm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm1,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Alm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm1,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Alm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Alm2 = {
    DataObjectModelType,
    "Alm2",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm3,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm2_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Alm2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm2,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Alm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm2,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Alm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm2,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Alm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Alm3 = {
    DataObjectModelType,
    "Alm3",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind1,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm3_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Alm3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm3,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Alm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm3,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Alm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm3,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Alm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Alm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind2,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind1_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind1,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind1,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind1,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind3,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind2_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind2,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind2,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind2,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind3_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind3,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind3,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind3,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind5,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind4_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Ind5 = {
    DataObjectModelType,
    "Ind5",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind6,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind5_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Ind5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind5,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind5,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind5,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind5,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Ind6 = {
    DataObjectModelType,
    "Ind6",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind7,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind6_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Ind6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind6,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind6,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind6,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind6,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Ind7 = {
    DataObjectModelType,
    "Ind7",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind8,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind7_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Ind7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind7,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind7,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind7,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind7,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Ind8 = {
    DataObjectModelType,
    "Ind8",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind9,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind8_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Ind8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind8,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind8,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind8,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind8,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Ind9 = {
    DataObjectModelType,
    "Ind9",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind10,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind9_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Ind9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind9,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind9,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind9,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind9,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Ind10 = {
    DataObjectModelType,
    "Ind10",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind11,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind10_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Ind10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind10,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind10,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind10,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind10,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn3GGIO4_Ind11 = {
    DataObjectModelType,
    "Ind11",
    (ModelNode*) &iedModel_General_AnIn3GGIO4,
    NULL,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind11_stVal,
    0
};

DataAttribute iedModel_General_AnIn3GGIO4_Ind11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind11,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind11,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind11,
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind11_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn3GGIO4_Ind11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn3GGIO4_Ind11,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_General_AnIn5GGIO6 = {
    LogicalNodeModelType,
    "AnIn5GGIO6",
    (ModelNode*) &iedModel_General,
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Mod,
};

DataObject iedModel_General_AnIn5GGIO6_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Beh,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Mod_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Mod,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Mod,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Mod,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Health,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Beh_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Beh,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Beh,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_NamPlt,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Health_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Health,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Health,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn1,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_NamPlt_vendor,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_NamPlt,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_NamPlt,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_NamPlt,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_NamPlt_lnNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_NamPlt_lnNs = {
    DataAttributeModelType,
    "lnNs",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_AnIn1 = {
    DataObjectModelType,
    "AnIn1",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn1_mag,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_AnIn1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn1,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn1_q,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn1_mag_i,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_AnIn1_mag_i = {
    DataAttributeModelType,
    "i",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_AnIn1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn1,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_AnIn1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn1,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_AnIn1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_AnIn2 = {
    DataObjectModelType,
    "AnIn2",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm1,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2_mag,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_AnIn2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2_q,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_AnIn2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_AnIn2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_AnIn2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_AnIn2_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2_d,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_AnIn2_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_AnIn2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_AnIn2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Alm1 = {
    DataObjectModelType,
    "Alm1",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm2,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm1_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Alm1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm1,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Alm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm1,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Alm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm1,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Alm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Alm2 = {
    DataObjectModelType,
    "Alm2",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm3,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm2_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Alm2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm2,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Alm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm2,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Alm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm2,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Alm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Alm3 = {
    DataObjectModelType,
    "Alm3",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind1,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm3_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Alm3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm3,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Alm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm3,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Alm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm3,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Alm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Alm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind2,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind1_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind1,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind1,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind1,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind3,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind2_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind2,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind2,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind2,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind4,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind3_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind3,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind3,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind3,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind5,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind4_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind4,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind4,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind4,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Ind5 = {
    DataObjectModelType,
    "Ind5",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind5_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Ind5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind5,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind5,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind5,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind5,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Ind6 = {
    DataObjectModelType,
    "Ind6",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind7,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind6_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Ind6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind6,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Ind7 = {
    DataObjectModelType,
    "Ind7",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind8,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind7_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Ind7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind7,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind7,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind7,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind7,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Ind8 = {
    DataObjectModelType,
    "Ind8",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind9,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind8_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Ind8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind8,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind8,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind8,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind8,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Ind9 = {
    DataObjectModelType,
    "Ind9",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind10,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind9_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Ind9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind9,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind9,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind9,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind9,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Ind10 = {
    DataObjectModelType,
    "Ind10",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind11,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind10_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Ind10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind10,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind10,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind10,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind10,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn5GGIO6_Ind11 = {
    DataObjectModelType,
    "Ind11",
    (ModelNode*) &iedModel_General_AnIn5GGIO6,
    NULL,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind11_stVal,
    0
};

DataAttribute iedModel_General_AnIn5GGIO6_Ind11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind11,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind11,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind11,
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind11_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn5GGIO6_Ind11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn5GGIO6_Ind11,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_General_AnIn4GGIO5 = {
    LogicalNodeModelType,
    "AnIn4GGIO5",
    (ModelNode*) &iedModel_General,
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Mod,
};

DataObject iedModel_General_AnIn4GGIO5_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Beh,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Mod_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Mod,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Mod,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Mod,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Health,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Beh_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Beh,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Beh,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_NamPlt,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Health_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Health,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Health,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn1,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_NamPlt_vendor,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_NamPlt,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_NamPlt,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_NamPlt,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_NamPlt_lnNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_NamPlt_lnNs = {
    DataAttributeModelType,
    "lnNs",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_AnIn1 = {
    DataObjectModelType,
    "AnIn1",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn1_mag,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_AnIn1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn1,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn1_q,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn1_mag_i,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_AnIn1_mag_i = {
    DataAttributeModelType,
    "i",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_AnIn1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn1,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_AnIn1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn1,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_AnIn1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_AnIn2 = {
    DataObjectModelType,
    "AnIn2",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm1,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2_mag,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_AnIn2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2_q,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_AnIn2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_AnIn2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_AnIn2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_AnIn2_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2_d,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_AnIn2_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_AnIn2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_AnIn2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Alm1 = {
    DataObjectModelType,
    "Alm1",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm2,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm1_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Alm1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm1,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Alm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm1,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Alm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm1,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Alm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Alm2 = {
    DataObjectModelType,
    "Alm2",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm3,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm2_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Alm2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm2,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Alm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm2,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Alm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm2,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Alm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Alm3 = {
    DataObjectModelType,
    "Alm3",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind1,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm3_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Alm3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm3,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Alm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm3,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Alm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm3,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Alm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Alm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind2,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind1_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind1,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind1,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind1,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind3,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind2_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind2,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind2,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind2,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind4,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind3_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind3,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind3,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind3,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind4_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind4,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind4,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind4,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Ind5 = {
    DataObjectModelType,
    "Ind5",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind6,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind5_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Ind5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind5,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Ind6 = {
    DataObjectModelType,
    "Ind6",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind7,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind6_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Ind6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind6,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind6,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind6,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind6,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Ind7 = {
    DataObjectModelType,
    "Ind7",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind8,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind7_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Ind7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind7,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind7,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind7,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind7,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Ind8 = {
    DataObjectModelType,
    "Ind8",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind9,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind8_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Ind8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind8,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind8,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind8,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind8,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Ind9 = {
    DataObjectModelType,
    "Ind9",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind10,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind9_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Ind9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind9,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind9,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind9,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind9,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Ind10 = {
    DataObjectModelType,
    "Ind10",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind11,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind10_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Ind10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind10,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind10,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind10,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind10,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn4GGIO5_Ind11 = {
    DataObjectModelType,
    "Ind11",
    (ModelNode*) &iedModel_General_AnIn4GGIO5,
    NULL,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind11_stVal,
    0
};

DataAttribute iedModel_General_AnIn4GGIO5_Ind11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind11,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind11,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind11,
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind11_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn4GGIO5_Ind11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn4GGIO5_Ind11,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_General_AnIn6GGIO7 = {
    LogicalNodeModelType,
    "AnIn6GGIO7",
    (ModelNode*) &iedModel_General,
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Mod,
};

DataObject iedModel_General_AnIn6GGIO7_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Beh,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Mod_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Mod,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Mod,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Mod,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Health,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Beh_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Beh,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Beh,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_NamPlt,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Health_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Health,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Health,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn1,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_NamPlt_vendor,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_NamPlt,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_NamPlt,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_NamPlt,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_NamPlt_lnNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_NamPlt_lnNs = {
    DataAttributeModelType,
    "lnNs",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_AnIn1 = {
    DataObjectModelType,
    "AnIn1",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn1_mag,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_AnIn1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn1,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn1_q,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn1_mag_i,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_AnIn1_mag_i = {
    DataAttributeModelType,
    "i",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_AnIn1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn1,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_AnIn1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn1,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_AnIn1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_AnIn2 = {
    DataObjectModelType,
    "AnIn2",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm1,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2_mag,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_AnIn2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2_q,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_AnIn2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_AnIn2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_AnIn2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2_units,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_AnIn2_units = {
    DataAttributeModelType,
    "units",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2_d,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2_units_SIUnit,
    0,
    IEC61850_FC_CF,
    IEC61850_CONSTRUCTED,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_AnIn2_units_SIUnit = {
    DataAttributeModelType,
    "SIUnit",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2_units,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_AnIn2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_AnIn2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Alm1 = {
    DataObjectModelType,
    "Alm1",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm2,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm1_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Alm1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm1,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Alm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm1,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Alm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm1,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Alm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Alm2 = {
    DataObjectModelType,
    "Alm2",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm3,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm2_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Alm2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm2,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Alm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm2,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Alm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm2,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Alm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Alm3 = {
    DataObjectModelType,
    "Alm3",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind1,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm3_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Alm3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm3,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Alm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm3,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Alm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm3,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Alm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Alm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind2,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind1_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind1,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind1,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind1,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind3,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind2_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind2,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind2,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind2,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind4,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind3_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind3,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind3,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind3,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind5,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind4_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind4,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind4,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind4,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Ind5 = {
    DataObjectModelType,
    "Ind5",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind6,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind5_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Ind5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind5,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind5,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind5,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind5,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Ind6 = {
    DataObjectModelType,
    "Ind6",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind6_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Ind6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind6,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind6,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind6,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind6,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Ind7 = {
    DataObjectModelType,
    "Ind7",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind8,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind7_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Ind7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind7,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Ind8 = {
    DataObjectModelType,
    "Ind8",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind9,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind8_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Ind8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind8,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind8,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind8,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind8,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Ind9 = {
    DataObjectModelType,
    "Ind9",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind10,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind9_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Ind9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind9,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind9,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind9,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind9,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Ind10 = {
    DataObjectModelType,
    "Ind10",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind11,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind10_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Ind10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind10,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind10,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind10,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind10,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_AnIn6GGIO7_Ind11 = {
    DataObjectModelType,
    "Ind11",
    (ModelNode*) &iedModel_General_AnIn6GGIO7,
    NULL,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind11_stVal,
    0
};

DataAttribute iedModel_General_AnIn6GGIO7_Ind11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind11,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind11,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind11,
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind11_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_AnIn6GGIO7_Ind11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_AnIn6GGIO7_Ind11,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_General_TFXStGGIO11 = {
    LogicalNodeModelType,
    "TFXStGGIO11",
    (ModelNode*) &iedModel_General,
    (ModelNode*) &iedModel_General_DevSchGGIO12,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Mod,
};

DataObject iedModel_General_TFXStGGIO11_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Beh,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Mod_stVal,
    0
};

DataAttribute iedModel_General_TFXStGGIO11_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Mod,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Mod,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Mod,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_General_TFXStGGIO11_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Health,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Beh_stVal,
    0
};

DataAttribute iedModel_General_TFXStGGIO11_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Beh,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Beh,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_TFXStGGIO11_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    (ModelNode*) &iedModel_General_TFXStGGIO11_NamPlt,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Health_stVal,
    0
};

DataAttribute iedModel_General_TFXStGGIO11_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Health,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Health,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_TFXStGGIO11_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind1,
    (ModelNode*) &iedModel_General_TFXStGGIO11_NamPlt_vendor,
    0
};

DataAttribute iedModel_General_TFXStGGIO11_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_General_TFXStGGIO11_NamPlt,
    (ModelNode*) &iedModel_General_TFXStGGIO11_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_General_TFXStGGIO11_NamPlt,
    (ModelNode*) &iedModel_General_TFXStGGIO11_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_TFXStGGIO11_NamPlt,
    (ModelNode*) &iedModel_General_TFXStGGIO11_NamPlt_lnNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_NamPlt_lnNs = {
    DataAttributeModelType,
    "lnNs",
    (ModelNode*) &iedModel_General_TFXStGGIO11_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_TFXStGGIO11_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind2,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind1_stVal,
    0
};

DataAttribute iedModel_General_TFXStGGIO11_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind1,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind1,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind1,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_TFXStGGIO11_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind3,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind2_stVal,
    0
};

DataAttribute iedModel_General_TFXStGGIO11_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind2,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind2,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind2,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_TFXStGGIO11_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind4,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind3_stVal,
    0
};

DataAttribute iedModel_General_TFXStGGIO11_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind3,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind3,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind3,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_TFXStGGIO11_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind5,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind4_stVal,
    0
};

DataAttribute iedModel_General_TFXStGGIO11_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind4,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind4,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind4,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_TFXStGGIO11_Ind5 = {
    DataObjectModelType,
    "Ind5",
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind6,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind5_stVal,
    0
};

DataAttribute iedModel_General_TFXStGGIO11_Ind5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind5,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind5,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind5,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind5,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_TFXStGGIO11_Ind6 = {
    DataObjectModelType,
    "Ind6",
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind7,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind6_stVal,
    0
};

DataAttribute iedModel_General_TFXStGGIO11_Ind6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind6,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind6,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind6,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind6,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_TFXStGGIO11_Ind7 = {
    DataObjectModelType,
    "Ind7",
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind8,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind7_stVal,
    0
};

DataAttribute iedModel_General_TFXStGGIO11_Ind7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind7,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind7,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind7,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind7,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_TFXStGGIO11_Ind8 = {
    DataObjectModelType,
    "Ind8",
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind9,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind8_stVal,
    0
};

DataAttribute iedModel_General_TFXStGGIO11_Ind8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind8,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind8,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind8,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind8,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_TFXStGGIO11_Ind9 = {
    DataObjectModelType,
    "Ind9",
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind10,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind9_stVal,
    0
};

DataAttribute iedModel_General_TFXStGGIO11_Ind9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind9,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind9,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind9,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind9,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_TFXStGGIO11_Ind10 = {
    DataObjectModelType,
    "Ind10",
    (ModelNode*) &iedModel_General_TFXStGGIO11,
    NULL,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind10_stVal,
    0
};

DataAttribute iedModel_General_TFXStGGIO11_Ind10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind10,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind10,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind10,
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_TFXStGGIO11_Ind10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_TFXStGGIO11_Ind10,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_General_DevSchGGIO12 = {
    LogicalNodeModelType,
    "DevSchGGIO12",
    (ModelNode*) &iedModel_General,
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Mod,
};

DataObject iedModel_General_DevSchGGIO12_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_General_DevSchGGIO12,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Beh,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Mod_stVal,
    0
};

DataAttribute iedModel_General_DevSchGGIO12_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Mod,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Mod,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Mod,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_General_DevSchGGIO12_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_General_DevSchGGIO12,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Health,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Beh_stVal,
    0
};

DataAttribute iedModel_General_DevSchGGIO12_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Beh,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Beh,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_DevSchGGIO12_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_General_DevSchGGIO12,
    (ModelNode*) &iedModel_General_DevSchGGIO12_NamPlt,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Health_stVal,
    0
};

DataAttribute iedModel_General_DevSchGGIO12_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Health,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Health,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_DevSchGGIO12_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_General_DevSchGGIO12,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind1,
    (ModelNode*) &iedModel_General_DevSchGGIO12_NamPlt_vendor,
    0
};

DataAttribute iedModel_General_DevSchGGIO12_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_General_DevSchGGIO12_NamPlt,
    (ModelNode*) &iedModel_General_DevSchGGIO12_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_General_DevSchGGIO12_NamPlt,
    (ModelNode*) &iedModel_General_DevSchGGIO12_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DevSchGGIO12_NamPlt,
    (ModelNode*) &iedModel_General_DevSchGGIO12_NamPlt_lnNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_NamPlt_lnNs = {
    DataAttributeModelType,
    "lnNs",
    (ModelNode*) &iedModel_General_DevSchGGIO12_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DevSchGGIO12_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_General_DevSchGGIO12,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind2,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind1_stVal,
    0
};

DataAttribute iedModel_General_DevSchGGIO12_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind1,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind1,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind1,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Ind1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DevSchGGIO12_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_General_DevSchGGIO12,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind3,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind2_stVal,
    0
};

DataAttribute iedModel_General_DevSchGGIO12_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind2,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind2,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind2,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Ind2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DevSchGGIO12_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_General_DevSchGGIO12,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind4,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind3_stVal,
    0
};

DataAttribute iedModel_General_DevSchGGIO12_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind3,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind3,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind3,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Ind3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DevSchGGIO12_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_General_DevSchGGIO12,
    NULL,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind4_stVal,
    0
};

DataAttribute iedModel_General_DevSchGGIO12_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind4,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind4,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind4,
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DevSchGGIO12_Ind4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DevSchGGIO12_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_General_DIGGIO8 = {
    LogicalNodeModelType,
    "DIGGIO8",
    (ModelNode*) &iedModel_General,
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO8_Mod,
};

DataObject iedModel_General_DIGGIO8_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Beh,
    (ModelNode*) &iedModel_General_DIGGIO8_Mod_q,
    0
};

DataAttribute iedModel_General_DIGGIO8_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Mod,
    (ModelNode*) &iedModel_General_DIGGIO8_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Mod,
    (ModelNode*) &iedModel_General_DIGGIO8_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_General_DIGGIO8_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Health,
    (ModelNode*) &iedModel_General_DIGGIO8_Beh_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Beh,
    (ModelNode*) &iedModel_General_DIGGIO8_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Beh,
    (ModelNode*) &iedModel_General_DIGGIO8_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_NamPlt,
    (ModelNode*) &iedModel_General_DIGGIO8_Health_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Health,
    (ModelNode*) &iedModel_General_DIGGIO8_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Health,
    (ModelNode*) &iedModel_General_DIGGIO8_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn1,
    (ModelNode*) &iedModel_General_DIGGIO8_NamPlt_vendor,
    0
};

DataAttribute iedModel_General_DIGGIO8_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_General_DIGGIO8_NamPlt,
    (ModelNode*) &iedModel_General_DIGGIO8_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_General_DIGGIO8_NamPlt,
    (ModelNode*) &iedModel_General_DIGGIO8_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_AnIn1 = {
    DataObjectModelType,
    "AnIn1",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn2,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn1_mag,
    0
};

DataAttribute iedModel_General_DIGGIO8_AnIn1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn1,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn1_q,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_AnIn1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_AnIn1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn1,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_AnIn1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn1,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_AnIn1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_AnIn2 = {
    DataObjectModelType,
    "AnIn2",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn3,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn2_mag,
    0
};

DataAttribute iedModel_General_DIGGIO8_AnIn2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn2,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn2_q,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_AnIn2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_AnIn2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn2,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_AnIn2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn2,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_AnIn2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_AnIn3 = {
    DataObjectModelType,
    "AnIn3",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm1,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn3_mag,
    0
};

DataAttribute iedModel_General_DIGGIO8_AnIn3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn3,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn3_q,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_AnIn3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_AnIn3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn3,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_AnIn3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn3,
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_AnIn3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_AnIn3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Alm1 = {
    DataObjectModelType,
    "Alm1",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm2,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm1_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Alm1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Alm1,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Alm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Alm1,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Alm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Alm1,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Alm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Alm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Alm2 = {
    DataObjectModelType,
    "Alm2",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm3,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm2_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Alm2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Alm2,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Alm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Alm2,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Alm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Alm2,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Alm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Alm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Alm3 = {
    DataObjectModelType,
    "Alm3",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind1,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm3_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Alm3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Alm3,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Alm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Alm3,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Alm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Alm3,
    (ModelNode*) &iedModel_General_DIGGIO8_Alm3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Alm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Alm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind2,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind1_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind1,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind1,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind1,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind3,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind2_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind2,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind2,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind2,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind4,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind3_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind3,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind3,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind3,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind5,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind4_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind4,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind4,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind4,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Ind5 = {
    DataObjectModelType,
    "Ind5",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind6,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind5_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Ind5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind5,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind5,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind5,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind5,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Ind6 = {
    DataObjectModelType,
    "Ind6",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind7,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind6_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Ind6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind6,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind6,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind6,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind6,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Ind7 = {
    DataObjectModelType,
    "Ind7",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind7_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Ind7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind7,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind7,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind7,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind7,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Ind8 = {
    DataObjectModelType,
    "Ind8",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind9,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind8_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Ind8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind8,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Ind9 = {
    DataObjectModelType,
    "Ind9",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind10,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind9_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Ind9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind9,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind9,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind9,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind9,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Ind10 = {
    DataObjectModelType,
    "Ind10",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind11,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind10_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Ind10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind10,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind10,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind10,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind10,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Ind11 = {
    DataObjectModelType,
    "Ind11",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind12,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind11_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Ind11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind11,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind11,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind11,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind11_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind11,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Ind12 = {
    DataObjectModelType,
    "Ind12",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind13,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind12_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Ind12_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind12,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind12_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind12_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind12,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind12_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind12_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind12,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind12_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind12_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind12,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Ind13 = {
    DataObjectModelType,
    "Ind13",
    (ModelNode*) &iedModel_General_DIGGIO8,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind14,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind13_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Ind13_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind13,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind13_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind13_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind13,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind13_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind13_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind13,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind13_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind13_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind13,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO8_Ind14 = {
    DataObjectModelType,
    "Ind14",
    (ModelNode*) &iedModel_General_DIGGIO8,
    NULL,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind14_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO8_Ind14_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind14,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind14_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind14_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind14,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind14_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind14_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind14,
    (ModelNode*) &iedModel_General_DIGGIO8_Ind14_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO8_Ind14_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO8_Ind14,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_General_DIGGIO9 = {
    LogicalNodeModelType,
    "DIGGIO9",
    (ModelNode*) &iedModel_General,
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO9_Mod,
};

DataObject iedModel_General_DIGGIO9_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Beh,
    (ModelNode*) &iedModel_General_DIGGIO9_Mod_q,
    0
};

DataAttribute iedModel_General_DIGGIO9_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Mod,
    (ModelNode*) &iedModel_General_DIGGIO9_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Mod,
    (ModelNode*) &iedModel_General_DIGGIO9_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_General_DIGGIO9_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Health,
    (ModelNode*) &iedModel_General_DIGGIO9_Beh_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Beh,
    (ModelNode*) &iedModel_General_DIGGIO9_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Beh,
    (ModelNode*) &iedModel_General_DIGGIO9_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_NamPlt,
    (ModelNode*) &iedModel_General_DIGGIO9_Health_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Health,
    (ModelNode*) &iedModel_General_DIGGIO9_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Health,
    (ModelNode*) &iedModel_General_DIGGIO9_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn1,
    (ModelNode*) &iedModel_General_DIGGIO9_NamPlt_vendor,
    0
};

DataAttribute iedModel_General_DIGGIO9_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_General_DIGGIO9_NamPlt,
    (ModelNode*) &iedModel_General_DIGGIO9_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_General_DIGGIO9_NamPlt,
    (ModelNode*) &iedModel_General_DIGGIO9_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_AnIn1 = {
    DataObjectModelType,
    "AnIn1",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn2,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn1_mag,
    0
};

DataAttribute iedModel_General_DIGGIO9_AnIn1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn1,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn1_q,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_AnIn1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_AnIn1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn1,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_AnIn1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn1,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_AnIn1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_AnIn2 = {
    DataObjectModelType,
    "AnIn2",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn3,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn2_mag,
    0
};

DataAttribute iedModel_General_DIGGIO9_AnIn2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn2,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn2_q,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_AnIn2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_AnIn2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn2,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_AnIn2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn2,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_AnIn2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_AnIn3 = {
    DataObjectModelType,
    "AnIn3",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm1,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn3_mag,
    0
};

DataAttribute iedModel_General_DIGGIO9_AnIn3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn3,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn3_q,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_AnIn3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_AnIn3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn3,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_AnIn3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn3,
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_AnIn3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_AnIn3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Alm1 = {
    DataObjectModelType,
    "Alm1",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm2,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm1_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Alm1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Alm1,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Alm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Alm1,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Alm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Alm1,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Alm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Alm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Alm2 = {
    DataObjectModelType,
    "Alm2",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm3,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm2_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Alm2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Alm2,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Alm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Alm2,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Alm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Alm2,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Alm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Alm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Alm3 = {
    DataObjectModelType,
    "Alm3",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind1,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm3_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Alm3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Alm3,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Alm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Alm3,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Alm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Alm3,
    (ModelNode*) &iedModel_General_DIGGIO9_Alm3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Alm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Alm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind2,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind1_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind1,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind1,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind1,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind3,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind2_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind2,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind2,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind2,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind4,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind3_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind3,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind3,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind3,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind5,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind4_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind4,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind4,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind4,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Ind5 = {
    DataObjectModelType,
    "Ind5",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind6,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind5_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Ind5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind5,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind5,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind5,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind5,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Ind6 = {
    DataObjectModelType,
    "Ind6",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind7,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind6_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Ind6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind6,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind6,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind6,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind6,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Ind7 = {
    DataObjectModelType,
    "Ind7",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind8,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind7_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Ind7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind7,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind7,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind7,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind7,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Ind8 = {
    DataObjectModelType,
    "Ind8",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind8_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Ind8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind8,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind8,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind8,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind8,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Ind9 = {
    DataObjectModelType,
    "Ind9",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind10,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind9_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Ind9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind9,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Ind10 = {
    DataObjectModelType,
    "Ind10",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind11,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind10_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Ind10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind10,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind10,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind10,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind10,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Ind11 = {
    DataObjectModelType,
    "Ind11",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind12,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind11_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Ind11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind11,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind11,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind11,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind11_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind11,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Ind12 = {
    DataObjectModelType,
    "Ind12",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind13,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind12_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Ind12_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind12,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind12_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind12_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind12,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind12_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind12_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind12,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind12_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind12_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind12,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Ind13 = {
    DataObjectModelType,
    "Ind13",
    (ModelNode*) &iedModel_General_DIGGIO9,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind14,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind13_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Ind13_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind13,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind13_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind13_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind13,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind13_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind13_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind13,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind13_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind13_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind13,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO9_Ind14 = {
    DataObjectModelType,
    "Ind14",
    (ModelNode*) &iedModel_General_DIGGIO9,
    NULL,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind14_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO9_Ind14_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind14,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind14_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind14_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind14,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind14_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind14_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind14,
    (ModelNode*) &iedModel_General_DIGGIO9_Ind14_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO9_Ind14_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO9_Ind14,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_General_DIGGIO10 = {
    LogicalNodeModelType,
    "DIGGIO10",
    (ModelNode*) &iedModel_General,
    NULL,
    (ModelNode*) &iedModel_General_DIGGIO10_Mod,
};

DataObject iedModel_General_DIGGIO10_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Beh,
    (ModelNode*) &iedModel_General_DIGGIO10_Mod_q,
    0
};

DataAttribute iedModel_General_DIGGIO10_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Mod,
    (ModelNode*) &iedModel_General_DIGGIO10_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Mod,
    (ModelNode*) &iedModel_General_DIGGIO10_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_General_DIGGIO10_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Health,
    (ModelNode*) &iedModel_General_DIGGIO10_Beh_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Beh,
    (ModelNode*) &iedModel_General_DIGGIO10_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Beh,
    (ModelNode*) &iedModel_General_DIGGIO10_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_NamPlt,
    (ModelNode*) &iedModel_General_DIGGIO10_Health_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Health,
    (ModelNode*) &iedModel_General_DIGGIO10_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Health,
    (ModelNode*) &iedModel_General_DIGGIO10_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn1,
    (ModelNode*) &iedModel_General_DIGGIO10_NamPlt_vendor,
    0
};

DataAttribute iedModel_General_DIGGIO10_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_General_DIGGIO10_NamPlt,
    (ModelNode*) &iedModel_General_DIGGIO10_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_General_DIGGIO10_NamPlt,
    (ModelNode*) &iedModel_General_DIGGIO10_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_AnIn1 = {
    DataObjectModelType,
    "AnIn1",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn2,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn1_mag,
    0
};

DataAttribute iedModel_General_DIGGIO10_AnIn1_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn1,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn1_q,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn1_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_AnIn1_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn1_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_AnIn1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn1,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn1_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_AnIn1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn1,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn1_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_AnIn1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_AnIn2 = {
    DataObjectModelType,
    "AnIn2",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn3,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn2_mag,
    0
};

DataAttribute iedModel_General_DIGGIO10_AnIn2_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn2,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn2_q,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn2_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_AnIn2_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn2_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_AnIn2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn2,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn2_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_AnIn2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn2,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn2_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_AnIn2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_AnIn3 = {
    DataObjectModelType,
    "AnIn3",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm1,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn3_mag,
    0
};

DataAttribute iedModel_General_DIGGIO10_AnIn3_mag = {
    DataAttributeModelType,
    "mag",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn3,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn3_q,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn3_mag_f,
    0,
    IEC61850_FC_MX,
    IEC61850_CONSTRUCTED,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_AnIn3_mag_f = {
    DataAttributeModelType,
    "f",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn3_mag,
    NULL,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_FLOAT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_AnIn3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn3,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn3_t,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_AnIn3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn3,
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn3_d,
    NULL,
    0,
    IEC61850_FC_MX,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_AnIn3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_AnIn3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Alm1 = {
    DataObjectModelType,
    "Alm1",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm2,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm1_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Alm1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Alm1,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Alm1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Alm1,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Alm1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Alm1,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Alm1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Alm1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Alm2 = {
    DataObjectModelType,
    "Alm2",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm3,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm2_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Alm2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Alm2,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Alm2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Alm2,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Alm2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Alm2,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Alm2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Alm2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Alm3 = {
    DataObjectModelType,
    "Alm3",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind1,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm3_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Alm3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Alm3,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Alm3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Alm3,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Alm3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Alm3,
    (ModelNode*) &iedModel_General_DIGGIO10_Alm3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Alm3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Alm3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind2,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind1_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind1,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind1,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind1,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind1_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind1_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind3,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind2_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind2,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind2,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind2,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind2_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind2_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind4,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind3_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind3,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind3,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind3,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind3_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind3_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind5,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind4_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind4,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind4,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind4,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind4_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind4_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Ind5 = {
    DataObjectModelType,
    "Ind5",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind6,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind5_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Ind5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind5,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind5,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind5,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind5_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind5_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind5,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Ind6 = {
    DataObjectModelType,
    "Ind6",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind7,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind6_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Ind6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind6,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind6,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind6,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind6_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind6_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind6,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Ind7 = {
    DataObjectModelType,
    "Ind7",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind8,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind7_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Ind7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind7,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind7,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind7,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind7_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind7_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind7,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Ind8 = {
    DataObjectModelType,
    "Ind8",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind9,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind8_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Ind8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind8,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind8,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind8,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind8_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind8_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind8,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Ind9 = {
    DataObjectModelType,
    "Ind9",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind9_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Ind9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind9,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind9,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind9,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind9_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind9_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind9,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Ind10 = {
    DataObjectModelType,
    "Ind10",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind11,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind10_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Ind10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind10_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind10_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind10,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Ind11 = {
    DataObjectModelType,
    "Ind11",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind12,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind11_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Ind11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind11,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind11,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind11,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind11_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind11_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind11,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Ind12 = {
    DataObjectModelType,
    "Ind12",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind13,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind12_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Ind12_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind12,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind12_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind12_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind12,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind12_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind12_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind12,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind12_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind12_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind12,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Ind13 = {
    DataObjectModelType,
    "Ind13",
    (ModelNode*) &iedModel_General_DIGGIO10,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind14,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind13_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Ind13_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind13,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind13_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind13_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind13,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind13_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind13_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind13,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind13_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind13_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind13,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_General_DIGGIO10_Ind14 = {
    DataObjectModelType,
    "Ind14",
    (ModelNode*) &iedModel_General_DIGGIO10,
    NULL,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind14_stVal,
    0
};

DataAttribute iedModel_General_DIGGIO10_Ind14_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind14,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind14_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind14_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind14,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind14_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind14_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind14,
    (ModelNode*) &iedModel_General_DIGGIO10_Ind14_d,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_General_DIGGIO10_Ind14_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_General_DIGGIO10_Ind14,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};


LogicalDevice iedModel_Dummy = {
    LogicalDeviceModelType,
    "Dummy",
    (ModelNode*) &iedModel,
    (ModelNode*) &iedModel_External,
    (ModelNode*) &iedModel_Dummy_LLN0
};

LogicalNode iedModel_Dummy_LLN0 = {
    LogicalNodeModelType,
    "LLN0",
    (ModelNode*) &iedModel_Dummy,
    (ModelNode*) &iedModel_Dummy_LPHD1,
    (ModelNode*) &iedModel_Dummy_LLN0_Mod,
};

DataObject iedModel_Dummy_LLN0_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_Dummy_LLN0,
    (ModelNode*) &iedModel_Dummy_LLN0_Beh,
    (ModelNode*) &iedModel_Dummy_LLN0_Mod_stVal,
    0
};

DataAttribute iedModel_Dummy_LLN0_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_LLN0_Mod,
    (ModelNode*) &iedModel_Dummy_LLN0_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_LLN0_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_LLN0_Mod,
    (ModelNode*) &iedModel_Dummy_LLN0_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_LLN0_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_LLN0_Mod,
    (ModelNode*) &iedModel_Dummy_LLN0_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_Dummy_LLN0_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_Dummy_LLN0_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_LLN0_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_Dummy_LLN0,
    (ModelNode*) &iedModel_Dummy_LLN0_Health,
    (ModelNode*) &iedModel_Dummy_LLN0_Beh_stVal,
    0
};

DataAttribute iedModel_Dummy_LLN0_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_LLN0_Beh,
    (ModelNode*) &iedModel_Dummy_LLN0_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_LLN0_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_LLN0_Beh,
    (ModelNode*) &iedModel_Dummy_LLN0_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_LLN0_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_LLN0_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_LLN0_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_Dummy_LLN0,
    (ModelNode*) &iedModel_Dummy_LLN0_NamPlt,
    (ModelNode*) &iedModel_Dummy_LLN0_Health_stVal,
    0
};

DataAttribute iedModel_Dummy_LLN0_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_LLN0_Health,
    (ModelNode*) &iedModel_Dummy_LLN0_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_LLN0_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_LLN0_Health,
    (ModelNode*) &iedModel_Dummy_LLN0_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_LLN0_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_LLN0_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_LLN0_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_Dummy_LLN0,
    NULL,
    (ModelNode*) &iedModel_Dummy_LLN0_NamPlt_vendor,
    0
};

DataAttribute iedModel_Dummy_LLN0_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_Dummy_LLN0_NamPlt,
    (ModelNode*) &iedModel_Dummy_LLN0_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_Dummy_LLN0_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_Dummy_LLN0_NamPlt,
    (ModelNode*) &iedModel_Dummy_LLN0_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_Dummy_LLN0_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_Dummy_LLN0_NamPlt,
    (ModelNode*) &iedModel_Dummy_LLN0_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_Dummy_LLN0_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_Dummy_LLN0_NamPlt,
    (ModelNode*) &iedModel_Dummy_LLN0_NamPlt_ldNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_Dummy_LLN0_NamPlt_ldNs = {
    DataAttributeModelType,
    "ldNs",
    (ModelNode*) &iedModel_Dummy_LLN0_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_Dummy_LPHD1 = {
    LogicalNodeModelType,
    "LPHD1",
    (ModelNode*) &iedModel_Dummy,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyNam,
};

DataObject iedModel_Dummy_LPHD1_PhyNam = {
    DataObjectModelType,
    "PhyNam",
    (ModelNode*) &iedModel_Dummy_LPHD1,
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyNam_vendor,
    0
};

DataAttribute iedModel_Dummy_LPHD1_PhyNam_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyNam,
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyNam_hwRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_Dummy_LPHD1_PhyNam_hwRev = {
    DataAttributeModelType,
    "hwRev",
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyNam,
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyNam_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_Dummy_LPHD1_PhyNam_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyNam,
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyNam_model,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_Dummy_LPHD1_PhyNam_model = {
    DataAttributeModelType,
    "model",
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyNam,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_LPHD1_PhyHealth = {
    DataObjectModelType,
    "PhyHealth",
    (ModelNode*) &iedModel_Dummy_LPHD1,
    (ModelNode*) &iedModel_Dummy_LPHD1_Proxy,
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyHealth_stVal,
    0
};

DataAttribute iedModel_Dummy_LPHD1_PhyHealth_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyHealth_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_LPHD1_PhyHealth_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyHealth_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_LPHD1_PhyHealth_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_LPHD1_PhyHealth,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_LPHD1_Proxy = {
    DataObjectModelType,
    "Proxy",
    (ModelNode*) &iedModel_Dummy_LPHD1,
    NULL,
    (ModelNode*) &iedModel_Dummy_LPHD1_Proxy_stVal,
    0
};

DataAttribute iedModel_Dummy_LPHD1_Proxy_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_LPHD1_Proxy,
    (ModelNode*) &iedModel_Dummy_LPHD1_Proxy_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_LPHD1_Proxy_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_LPHD1_Proxy,
    (ModelNode*) &iedModel_Dummy_LPHD1_Proxy_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_LPHD1_Proxy_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_LPHD1_Proxy,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

LogicalNode iedModel_Dummy_DummyGGIO1 = {
    LogicalNodeModelType,
    "DummyGGIO1",
    (ModelNode*) &iedModel_Dummy,
    NULL,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Mod,
};

DataObject iedModel_Dummy_DummyGGIO1_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Beh,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Mod_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Mod,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Mod,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Mod,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Health,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Beh_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Beh,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Beh,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_NamPlt,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Health_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Health,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Health,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_NamPlt_vendor,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_NamPlt,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_NamPlt,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_NamPlt,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_NamPlt_lnNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_NamPlt_lnNs = {
    DataAttributeModelType,
    "lnNs",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind1 = {
    DataObjectModelType,
    "Ind1",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind2,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind1_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind1_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind1_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind1_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind1_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind1_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind1,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind2 = {
    DataObjectModelType,
    "Ind2",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind3,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind2_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind2_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind2,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind2_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind2_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind2,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind2_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind2_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind2,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind3 = {
    DataObjectModelType,
    "Ind3",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind4,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind3_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind3_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind3,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind3_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind3_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind3,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind3_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind3_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind3,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind4 = {
    DataObjectModelType,
    "Ind4",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind5,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind4_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind4_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind4,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind4_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind4_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind4,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind4_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind4_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind4,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind5 = {
    DataObjectModelType,
    "Ind5",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind6,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind5_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind5_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind5,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind5_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind5_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind5,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind5_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind5_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind5,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind6 = {
    DataObjectModelType,
    "Ind6",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind7,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind6_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind6_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind6,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind6_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind6_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind6,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind6_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind6_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind6,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind7 = {
    DataObjectModelType,
    "Ind7",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind8,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind7_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind7_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind7,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind7_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind7_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind7,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind7_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind7_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind7,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind8 = {
    DataObjectModelType,
    "Ind8",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind9,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind8_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind8_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind8,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind8_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind8_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind8,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind8_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind8_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind8,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind9 = {
    DataObjectModelType,
    "Ind9",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind10,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind9_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind9_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind9,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind9_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind9_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind9,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind9_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind9_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind9,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind10 = {
    DataObjectModelType,
    "Ind10",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind11,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind10_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind10_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind10,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind10_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind10_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind10,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind10_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind10_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind10,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind11 = {
    DataObjectModelType,
    "Ind11",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind12,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind11_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind11_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind11,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind11_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind11_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind11,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind11_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind11_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind11,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind12 = {
    DataObjectModelType,
    "Ind12",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind13,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind12_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind12_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind12,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind12_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind12_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind12,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind12_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind12_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind12,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind13 = {
    DataObjectModelType,
    "Ind13",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind14,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind13_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind13_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind13,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind13_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind13_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind13,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind13_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind13_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind13,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind14 = {
    DataObjectModelType,
    "Ind14",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind15,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind14_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind14_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind14,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind14_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind14_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind14,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind14_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind14_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind14,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind15 = {
    DataObjectModelType,
    "Ind15",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind16,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind15_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind15_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind15,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind15_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind15_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind15,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind15_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind15_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind15,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind16 = {
    DataObjectModelType,
    "Ind16",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind17,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind16_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind16_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind16,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind16_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind16_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind16,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind16_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind16_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind16,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind17 = {
    DataObjectModelType,
    "Ind17",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind18,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind17_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind17_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind17,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind17_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind17_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind17,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind17_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind17_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind17,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind18 = {
    DataObjectModelType,
    "Ind18",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind19,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind18_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind18_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind18,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind18_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind18_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind18,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind18_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind18_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind18,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind19 = {
    DataObjectModelType,
    "Ind19",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind20,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind19_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind19_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind19,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind19_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind19_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind19,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind19_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind19_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind19,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_Dummy_DummyGGIO1_Ind20 = {
    DataObjectModelType,
    "Ind20",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1,
    NULL,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind20_stVal,
    0
};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind20_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind20,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind20_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind20_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind20,
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind20_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_Dummy_DummyGGIO1_Ind20_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_Dummy_DummyGGIO1_Ind20,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};


LogicalDevice iedModel_External = {
    LogicalDeviceModelType,
    "External",
    (ModelNode*) &iedModel,
    NULL,
    (ModelNode*) &iedModel_External_LLN0
};

LogicalNode iedModel_External_LLN0 = {
    LogicalNodeModelType,
    "LLN0",
    (ModelNode*) &iedModel_External,
    (ModelNode*) &iedModel_External_LPHD1,
    (ModelNode*) &iedModel_External_LLN0_Mod,
};

DataObject iedModel_External_LLN0_Mod = {
    DataObjectModelType,
    "Mod",
    (ModelNode*) &iedModel_External_LLN0,
    (ModelNode*) &iedModel_External_LLN0_Beh,
    (ModelNode*) &iedModel_External_LLN0_Mod_stVal,
    0
};

DataAttribute iedModel_External_LLN0_Mod_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_External_LLN0_Mod,
    (ModelNode*) &iedModel_External_LLN0_Mod_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_External_LLN0_Mod_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_External_LLN0_Mod,
    (ModelNode*) &iedModel_External_LLN0_Mod_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_External_LLN0_Mod_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_External_LLN0_Mod,
    (ModelNode*) &iedModel_External_LLN0_Mod_ctlModel,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataAttribute iedModel_External_LLN0_Mod_ctlModel = {
    DataAttributeModelType,
    "ctlModel",
    (ModelNode*) &iedModel_External_LLN0_Mod,
    NULL,
    NULL,
    0,
    IEC61850_FC_CF,
    IEC61850_ENUMERATED,
    0,
    NULL,
    0};

DataObject iedModel_External_LLN0_Beh = {
    DataObjectModelType,
    "Beh",
    (ModelNode*) &iedModel_External_LLN0,
    (ModelNode*) &iedModel_External_LLN0_Health,
    (ModelNode*) &iedModel_External_LLN0_Beh_stVal,
    0
};

DataAttribute iedModel_External_LLN0_Beh_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_External_LLN0_Beh,
    (ModelNode*) &iedModel_External_LLN0_Beh_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_External_LLN0_Beh_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_External_LLN0_Beh,
    (ModelNode*) &iedModel_External_LLN0_Beh_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_External_LLN0_Beh_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_External_LLN0_Beh,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_External_LLN0_Health = {
    DataObjectModelType,
    "Health",
    (ModelNode*) &iedModel_External_LLN0,
    (ModelNode*) &iedModel_External_LLN0_NamPlt,
    (ModelNode*) &iedModel_External_LLN0_Health_stVal,
    0
};

DataAttribute iedModel_External_LLN0_Health_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_External_LLN0_Health,
    (ModelNode*) &iedModel_External_LLN0_Health_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_External_LLN0_Health_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_External_LLN0_Health,
    (ModelNode*) &iedModel_External_LLN0_Health_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_External_LLN0_Health_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_External_LLN0_Health,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_External_LLN0_NamPlt = {
    DataObjectModelType,
    "NamPlt",
    (ModelNode*) &iedModel_External_LLN0,
    NULL,
    (ModelNode*) &iedModel_External_LLN0_NamPlt_vendor,
    0
};

DataAttribute iedModel_External_LLN0_NamPlt_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_External_LLN0_NamPlt,
    (ModelNode*) &iedModel_External_LLN0_NamPlt_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_External_LLN0_NamPlt_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_External_LLN0_NamPlt,
    (ModelNode*) &iedModel_External_LLN0_NamPlt_d,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_External_LLN0_NamPlt_d = {
    DataAttributeModelType,
    "d",
    (ModelNode*) &iedModel_External_LLN0_NamPlt,
    (ModelNode*) &iedModel_External_LLN0_NamPlt_configRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_External_LLN0_NamPlt_configRev = {
    DataAttributeModelType,
    "configRev",
    (ModelNode*) &iedModel_External_LLN0_NamPlt,
    (ModelNode*) &iedModel_External_LLN0_NamPlt_ldNs,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_External_LLN0_NamPlt_ldNs = {
    DataAttributeModelType,
    "ldNs",
    (ModelNode*) &iedModel_External_LLN0_NamPlt,
    NULL,
    NULL,
    0,
    IEC61850_FC_EX,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

LogicalNode iedModel_External_LPHD1 = {
    LogicalNodeModelType,
    "LPHD1",
    (ModelNode*) &iedModel_External,
    NULL,
    (ModelNode*) &iedModel_External_LPHD1_PhyNam,
};

DataObject iedModel_External_LPHD1_PhyNam = {
    DataObjectModelType,
    "PhyNam",
    (ModelNode*) &iedModel_External_LPHD1,
    (ModelNode*) &iedModel_External_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_External_LPHD1_PhyNam_vendor,
    0
};

DataAttribute iedModel_External_LPHD1_PhyNam_vendor = {
    DataAttributeModelType,
    "vendor",
    (ModelNode*) &iedModel_External_LPHD1_PhyNam,
    (ModelNode*) &iedModel_External_LPHD1_PhyNam_hwRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_External_LPHD1_PhyNam_hwRev = {
    DataAttributeModelType,
    "hwRev",
    (ModelNode*) &iedModel_External_LPHD1_PhyNam,
    (ModelNode*) &iedModel_External_LPHD1_PhyNam_swRev,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_External_LPHD1_PhyNam_swRev = {
    DataAttributeModelType,
    "swRev",
    (ModelNode*) &iedModel_External_LPHD1_PhyNam,
    (ModelNode*) &iedModel_External_LPHD1_PhyNam_serNum,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_External_LPHD1_PhyNam_serNum = {
    DataAttributeModelType,
    "serNum",
    (ModelNode*) &iedModel_External_LPHD1_PhyNam,
    (ModelNode*) &iedModel_External_LPHD1_PhyNam_model,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_External_LPHD1_PhyNam_model = {
    DataAttributeModelType,
    "model",
    (ModelNode*) &iedModel_External_LPHD1_PhyNam,
    (ModelNode*) &iedModel_External_LPHD1_PhyNam_location,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataAttribute iedModel_External_LPHD1_PhyNam_location = {
    DataAttributeModelType,
    "location",
    (ModelNode*) &iedModel_External_LPHD1_PhyNam,
    NULL,
    NULL,
    0,
    IEC61850_FC_DC,
    IEC61850_VISIBLE_STRING_255,
    0,
    NULL,
    0};

DataObject iedModel_External_LPHD1_PhyHealth = {
    DataObjectModelType,
    "PhyHealth",
    (ModelNode*) &iedModel_External_LPHD1,
    (ModelNode*) &iedModel_External_LPHD1_Proxy,
    (ModelNode*) &iedModel_External_LPHD1_PhyHealth_stVal,
    0
};

DataAttribute iedModel_External_LPHD1_PhyHealth_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_External_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_External_LPHD1_PhyHealth_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_INT32,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_External_LPHD1_PhyHealth_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_External_LPHD1_PhyHealth,
    (ModelNode*) &iedModel_External_LPHD1_PhyHealth_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_External_LPHD1_PhyHealth_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_External_LPHD1_PhyHealth,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

DataObject iedModel_External_LPHD1_Proxy = {
    DataObjectModelType,
    "Proxy",
    (ModelNode*) &iedModel_External_LPHD1,
    NULL,
    (ModelNode*) &iedModel_External_LPHD1_Proxy_stVal,
    0
};

DataAttribute iedModel_External_LPHD1_Proxy_stVal = {
    DataAttributeModelType,
    "stVal",
    (ModelNode*) &iedModel_External_LPHD1_Proxy,
    (ModelNode*) &iedModel_External_LPHD1_Proxy_q,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_BOOLEAN,
    0 + TRG_OPT_DATA_CHANGED,
    NULL,
    0};

DataAttribute iedModel_External_LPHD1_Proxy_q = {
    DataAttributeModelType,
    "q",
    (ModelNode*) &iedModel_External_LPHD1_Proxy,
    (ModelNode*) &iedModel_External_LPHD1_Proxy_t,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_QUALITY,
    0 + TRG_OPT_QUALITY_CHANGED,
    NULL,
    0};

DataAttribute iedModel_External_LPHD1_Proxy_t = {
    DataAttributeModelType,
    "t",
    (ModelNode*) &iedModel_External_LPHD1_Proxy,
    NULL,
    NULL,
    0,
    IEC61850_FC_ST,
    IEC61850_TIMESTAMP,
    0,
    NULL,
    0};

extern ReportControlBlock iedModel_External_LLN0_report0;
extern ReportControlBlock iedModel_External_LLN0_report1;
extern ReportControlBlock iedModel_External_LLN0_report2;
extern ReportControlBlock iedModel_External_LLN0_report3;
extern ReportControlBlock iedModel_External_LLN0_report4;
extern ReportControlBlock iedModel_External_LLN0_report5;
extern ReportControlBlock iedModel_External_LLN0_report6;
extern ReportControlBlock iedModel_External_LLN0_report7;
extern ReportControlBlock iedModel_External_LLN0_report8;
extern ReportControlBlock iedModel_External_LLN0_report9;
extern ReportControlBlock iedModel_External_LLN0_report10;
extern ReportControlBlock iedModel_External_LLN0_report11;
extern ReportControlBlock iedModel_External_LLN0_report12;
extern ReportControlBlock iedModel_External_LLN0_report13;
extern ReportControlBlock iedModel_External_LLN0_report14;
extern ReportControlBlock iedModel_External_LLN0_report15;
extern ReportControlBlock iedModel_External_LLN0_report16;
extern ReportControlBlock iedModel_External_LLN0_report17;
extern ReportControlBlock iedModel_External_LLN0_report18;
extern ReportControlBlock iedModel_External_LLN0_report19;
extern ReportControlBlock iedModel_External_LLN0_report20;
extern ReportControlBlock iedModel_External_LLN0_report21;
extern ReportControlBlock iedModel_External_LLN0_report22;
extern ReportControlBlock iedModel_External_LLN0_report23;
extern ReportControlBlock iedModel_External_LLN0_report24;
extern ReportControlBlock iedModel_External_LLN0_report25;
extern ReportControlBlock iedModel_External_LLN0_report26;
extern ReportControlBlock iedModel_External_LLN0_report27;
extern ReportControlBlock iedModel_External_LLN0_report28;
extern ReportControlBlock iedModel_External_LLN0_report29;
extern ReportControlBlock iedModel_External_LLN0_report30;
extern ReportControlBlock iedModel_External_LLN0_report31;
extern ReportControlBlock iedModel_External_LLN0_report32;
extern ReportControlBlock iedModel_External_LLN0_report33;
extern ReportControlBlock iedModel_External_LLN0_report34;
extern ReportControlBlock iedModel_External_LLN0_report35;
extern ReportControlBlock iedModel_External_LLN0_report36;
extern ReportControlBlock iedModel_External_LLN0_report37;
extern ReportControlBlock iedModel_External_LLN0_report38;
extern ReportControlBlock iedModel_External_LLN0_report39;
extern ReportControlBlock iedModel_External_LLN0_report40;
extern ReportControlBlock iedModel_External_LLN0_report41;
extern ReportControlBlock iedModel_External_LLN0_report42;
extern ReportControlBlock iedModel_External_LLN0_report43;
extern ReportControlBlock iedModel_External_LLN0_report44;
extern ReportControlBlock iedModel_External_LLN0_report45;
extern ReportControlBlock iedModel_External_LLN0_report46;
extern ReportControlBlock iedModel_External_LLN0_report47;
extern ReportControlBlock iedModel_External_LLN0_report48;
extern ReportControlBlock iedModel_External_LLN0_report49;
extern ReportControlBlock iedModel_External_LLN0_report50;
extern ReportControlBlock iedModel_External_LLN0_report51;
extern ReportControlBlock iedModel_External_LLN0_report52;
extern ReportControlBlock iedModel_External_LLN0_report53;
extern ReportControlBlock iedModel_External_LLN0_report54;

ReportControlBlock iedModel_External_LLN0_report0 = {&iedModel_External_LLN0, "urcbAssetHealth01", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report1};
ReportControlBlock iedModel_External_LLN0_report1 = {&iedModel_External_LLN0, "urcbAssetHealth02", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report2};
ReportControlBlock iedModel_External_LLN0_report2 = {&iedModel_External_LLN0, "urcbAssetHealth03", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report3};
ReportControlBlock iedModel_External_LLN0_report3 = {&iedModel_External_LLN0, "urcbAssetHealth04", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report4};
ReportControlBlock iedModel_External_LLN0_report4 = {&iedModel_External_LLN0, "urcbAssetHealth05", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report5};
ReportControlBlock iedModel_External_LLN0_report5 = {&iedModel_External_LLN0, "urcbAssetHealth06", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report6};
ReportControlBlock iedModel_External_LLN0_report6 = {&iedModel_External_LLN0, "urcbAssetHealth07", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report7};
ReportControlBlock iedModel_External_LLN0_report7 = {&iedModel_External_LLN0, "urcbAssetHealth08", "urcbAssetHealth", false, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report8};
ReportControlBlock iedModel_External_LLN0_report8 = {&iedModel_External_LLN0, "brcbAssetHealth01", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report9};
ReportControlBlock iedModel_External_LLN0_report9 = {&iedModel_External_LLN0, "brcbAssetHealth02", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report10};
ReportControlBlock iedModel_External_LLN0_report10 = {&iedModel_External_LLN0, "brcbAssetHealth03", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report11};
ReportControlBlock iedModel_External_LLN0_report11 = {&iedModel_External_LLN0, "brcbAssetHealth04", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report12};
ReportControlBlock iedModel_External_LLN0_report12 = {&iedModel_External_LLN0, "brcbAssetHealth05", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report13};
ReportControlBlock iedModel_External_LLN0_report13 = {&iedModel_External_LLN0, "brcbAssetHealth06", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report14};
ReportControlBlock iedModel_External_LLN0_report14 = {&iedModel_External_LLN0, "brcbAssetHealth07", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report15};
ReportControlBlock iedModel_External_LLN0_report15 = {&iedModel_External_LLN0, "brcbAssetHealth08", "brcbAssetHealth", true, "dsAssetHealth", 1, 25, 47, 0, 10000, &iedModel_External_LLN0_report16};
ReportControlBlock iedModel_External_LLN0_report16 = {&iedModel_External_LLN0, "urcbA_DGA01", "TRANSFIXExternal/LLN0$Rpt$urcbA_DGA_01", false, "DGA", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report17};
ReportControlBlock iedModel_External_LLN0_report17 = {&iedModel_External_LLN0, "urcbA_DGA02", "TRANSFIXExternal/LLN0$Rpt$urcbA_DGA_01", false, "DGA", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report18};
ReportControlBlock iedModel_External_LLN0_report18 = {&iedModel_External_LLN0, "urcbA_DGA03", "TRANSFIXExternal/LLN0$Rpt$urcbA_DGA_01", false, "DGA", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report19};
ReportControlBlock iedModel_External_LLN0_report19 = {&iedModel_External_LLN0, "urcbB_AnIn_Std01", "TRANSFIXExternal/LLN0$Rpt$urcbB_AnIn_Std_01", false, "AnIn_std", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report20};
ReportControlBlock iedModel_External_LLN0_report20 = {&iedModel_External_LLN0, "urcbB_AnIn_Std02", "TRANSFIXExternal/LLN0$Rpt$urcbB_AnIn_Std_01", false, "AnIn_std", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report21};
ReportControlBlock iedModel_External_LLN0_report21 = {&iedModel_External_LLN0, "urcbB_AnIn_Std03", "TRANSFIXExternal/LLN0$Rpt$urcbB_AnIn_Std_01", false, "AnIn_std", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report22};
ReportControlBlock iedModel_External_LLN0_report22 = {&iedModel_External_LLN0, "urcbC_Al_St_Outputs01", "TRANSFIXExternal/LLN0$Rpt$urcbC01_Transfix_Status", false, "Al_St_Outputs", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report23};
ReportControlBlock iedModel_External_LLN0_report23 = {&iedModel_External_LLN0, "urcbC_Al_St_Outputs02", "TRANSFIXExternal/LLN0$Rpt$urcbC01_Transfix_Status", false, "Al_St_Outputs", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report24};
ReportControlBlock iedModel_External_LLN0_report24 = {&iedModel_External_LLN0, "urcbC_Al_St_Outputs03", "TRANSFIXExternal/LLN0$Rpt$urcbC01_Transfix_Status", false, "Al_St_Outputs", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report25};
ReportControlBlock iedModel_External_LLN0_report25 = {&iedModel_External_LLN0, "urcbD_Al_St_Gas_Conc01", "TRANSFIXExternal/LLN0$Rpt$urcbD01_Al_St_Gas_Conc", false, "Al_St_Gas_Conc", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report26};
ReportControlBlock iedModel_External_LLN0_report26 = {&iedModel_External_LLN0, "urcbD_Al_St_Gas_Conc02", "TRANSFIXExternal/LLN0$Rpt$urcbD01_Al_St_Gas_Conc", false, "Al_St_Gas_Conc", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report27};
ReportControlBlock iedModel_External_LLN0_report27 = {&iedModel_External_LLN0, "urcbD_Al_St_Gas_Conc03", "TRANSFIXExternal/LLN0$Rpt$urcbD01_Al_St_Gas_Conc", false, "Al_St_Gas_Conc", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report28};
ReportControlBlock iedModel_External_LLN0_report28 = {&iedModel_External_LLN0, "brcbA01", "TRANSFIXExternal/LLN0$Rpt$brcbA01", true, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report29};
ReportControlBlock iedModel_External_LLN0_report29 = {&iedModel_External_LLN0, "brcbA02", "TRANSFIXExternal/LLN0$Rpt$brcbA01", true, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report30};
ReportControlBlock iedModel_External_LLN0_report30 = {&iedModel_External_LLN0, "brcbA03", "TRANSFIXExternal/LLN0$Rpt$brcbA01", true, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report31};
ReportControlBlock iedModel_External_LLN0_report31 = {&iedModel_External_LLN0, "brcbB01", "TRANSFIXExternal/LLN0$Rpt$brcbB01", true, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report32};
ReportControlBlock iedModel_External_LLN0_report32 = {&iedModel_External_LLN0, "brcbB02", "TRANSFIXExternal/LLN0$Rpt$brcbB01", true, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report33};
ReportControlBlock iedModel_External_LLN0_report33 = {&iedModel_External_LLN0, "brcbB03", "TRANSFIXExternal/LLN0$Rpt$brcbB01", true, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report34};
ReportControlBlock iedModel_External_LLN0_report34 = {&iedModel_External_LLN0, "brcbC01", "TRANSFIXExternal/LLN0$Rpt$brcbC01", true, NULL, 0, 23, 47, 200, 2000, &iedModel_External_LLN0_report35};
ReportControlBlock iedModel_External_LLN0_report35 = {&iedModel_External_LLN0, "brcbC02", "TRANSFIXExternal/LLN0$Rpt$brcbC01", true, NULL, 0, 23, 47, 200, 2000, &iedModel_External_LLN0_report36};
ReportControlBlock iedModel_External_LLN0_report36 = {&iedModel_External_LLN0, "brcbC03", "TRANSFIXExternal/LLN0$Rpt$brcbC01", true, NULL, 0, 23, 47, 200, 2000, &iedModel_External_LLN0_report37};
ReportControlBlock iedModel_External_LLN0_report37 = {&iedModel_External_LLN0, "brcbD01", "TRANSFIXExternal/LLN0$Rpt$brcbD01", true, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report38};
ReportControlBlock iedModel_External_LLN0_report38 = {&iedModel_External_LLN0, "brcbD02", "TRANSFIXExternal/LLN0$Rpt$brcbD01", true, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report39};
ReportControlBlock iedModel_External_LLN0_report39 = {&iedModel_External_LLN0, "brcbD03", "TRANSFIXExternal/LLN0$Rpt$brcbD01", true, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report40};
ReportControlBlock iedModel_External_LLN0_report40 = {&iedModel_External_LLN0, "urcbE_Al_St_Gas_ROC01", "TRANSFIXExternal/LLN0$Rpt$urcbE01_Al_St_Gas_ROC", false, "Al_St_Gas_ROC", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report41};
ReportControlBlock iedModel_External_LLN0_report41 = {&iedModel_External_LLN0, "urcbE_Al_St_Gas_ROC02", "TRANSFIXExternal/LLN0$Rpt$urcbE01_Al_St_Gas_ROC", false, "Al_St_Gas_ROC", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report42};
ReportControlBlock iedModel_External_LLN0_report42 = {&iedModel_External_LLN0, "urcbE_Al_St_Gas_ROC03", "TRANSFIXExternal/LLN0$Rpt$urcbE01_Al_St_Gas_ROC", false, "Al_St_Gas_ROC", 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report43};
ReportControlBlock iedModel_External_LLN0_report43 = {&iedModel_External_LLN0, "urcbF01", "TRANSFIXExternal/LLN0$Rpt$urcbF01", false, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report44};
ReportControlBlock iedModel_External_LLN0_report44 = {&iedModel_External_LLN0, "urcbF02", "TRANSFIXExternal/LLN0$Rpt$urcbF01", false, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report45};
ReportControlBlock iedModel_External_LLN0_report45 = {&iedModel_External_LLN0, "urcbF03", "TRANSFIXExternal/LLN0$Rpt$urcbF01", false, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report46};
ReportControlBlock iedModel_External_LLN0_report46 = {&iedModel_External_LLN0, "urcbG01", "TRANSFIXExternal/LLN0$Rpt$urcbG01", false, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report47};
ReportControlBlock iedModel_External_LLN0_report47 = {&iedModel_External_LLN0, "urcbG02", "TRANSFIXExternal/LLN0$Rpt$urcbG01", false, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report48};
ReportControlBlock iedModel_External_LLN0_report48 = {&iedModel_External_LLN0, "urcbG03", "TRANSFIXExternal/LLN0$Rpt$urcbG01", false, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report49};
ReportControlBlock iedModel_External_LLN0_report49 = {&iedModel_External_LLN0, "brcbE01", "TRANSFIXExternal/LLN0$Rpt$brcbE01", true, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report50};
ReportControlBlock iedModel_External_LLN0_report50 = {&iedModel_External_LLN0, "brcbE02", "TRANSFIXExternal/LLN0$Rpt$brcbE01", true, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report51};
ReportControlBlock iedModel_External_LLN0_report51 = {&iedModel_External_LLN0, "brcbE03", "TRANSFIXExternal/LLN0$Rpt$brcbE01", true, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report52};
ReportControlBlock iedModel_External_LLN0_report52 = {&iedModel_External_LLN0, "brcbF01", "TRANSFIXExternal/LLN0$Rpt$brcbF01", true, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report53};
ReportControlBlock iedModel_External_LLN0_report53 = {&iedModel_External_LLN0, "brcbF02", "TRANSFIXExternal/LLN0$Rpt$brcbF01", true, NULL, 0, 31, 47, 200, 2000, &iedModel_External_LLN0_report54};
ReportControlBlock iedModel_External_LLN0_report54 = {&iedModel_External_LLN0, "brcbF03", "TRANSFIXExternal/LLN0$Rpt$brcbF01", true, NULL, 0, 31, 47, 200, 2000, NULL};







IedModel iedModel = {
    "TRANSFIX",
    &iedModel_OilSourceA,
    &iedModelds_External_LLN0_AnIn_std,
    &iedModel_External_LLN0_report0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    initializeValues
};

static void
initializeValues()
{

iedModel_OilSourceA_LLN0_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_OilSourceA_LLN0_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_OilSourceA_LLN0_NamPlt_vendor.mmsValue = MmsValue_newVisibleString("GE Energy");

iedModel_OilSourceA_LLN0_NamPlt_swRev.mmsValue = MmsValue_newVisibleString("1.6");

iedModel_OilSourceA_LLN0_NamPlt_d.mmsValue = MmsValue_newVisibleString("");

iedModel_OilSourceA_LLN0_NamPlt_configRev.mmsValue = MmsValue_newVisibleString("2ECD33CE21");

iedModel_OilSourceA_LLN0_NamPlt_ldNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2003");

iedModel_OilSourceA_LPHD1_PhyNam_vendor.mmsValue = MmsValue_newVisibleString("GE Energy");

iedModel_OilSourceA_LPHD1_PhyNam_hwRev.mmsValue = MmsValue_newVisibleString("1.6");

iedModel_OilSourceA_LPHD1_PhyNam_swRev.mmsValue = MmsValue_newVisibleString("1.12.0");

iedModel_OilSourceA_LPHD1_PhyNam_model.mmsValue = MmsValue_newVisibleString("KELMAN TRANSFIX");

iedModel_OilSourceA_MeasGGIO1_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_OilSourceA_MeasGGIO1_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_OilSourceA_MeasGGIO1_NamPlt_lnNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2003");

iedModel_OilSourceA_MeasGGIO1_AnIn2_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(52);

iedModel_OilSourceA_MeasGGIO1_AnIn2_d.mmsValue = MmsValue_newVisibleString("TDG - Total Dissolved Gas conc.");

iedModel_OilSourceA_MeasGGIO1_AnIn3_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(23);

iedModel_OilSourceA_MeasGGIO1_AnIn3_d.mmsValue = MmsValue_newVisibleString("Ambient Temp.");

iedModel_OilSourceA_MeasGGIO1_AnIn4_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(23);

iedModel_OilSourceA_MeasGGIO1_AnIn4_d.mmsValue = MmsValue_newVisibleString("Normalisation Temp.");

iedModel_OilSourceA_MeasGGIO1_AnIn5_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(5);

iedModel_OilSourceA_MeasGGIO1_AnIn5_units_multiplier.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_OilSourceA_MeasGGIO1_AnIn5_d.mmsValue = MmsValue_newVisibleString("Transformer Load Current");

iedModel_OilSourceA_MeasGGIO1_AnIn6_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_OilSourceA_MeasGGIO1_AnIn6_units_multiplier.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_OilSourceA_MeasGGIO1_AnIn6_d.mmsValue = MmsValue_newVisibleString("optional AI2");

iedModel_OilSourceA_MeasGGIO1_AnIn7_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_OilSourceA_MeasGGIO1_AnIn7_units_multiplier.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_OilSourceA_MeasGGIO1_AnIn7_d.mmsValue = MmsValue_newVisibleString("optional AI3");

iedModel_OilSourceA_MeasGGIO1_AnIn8_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_OilSourceA_MeasGGIO1_AnIn8_units_multiplier.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_OilSourceA_MeasGGIO1_AnIn8_d.mmsValue = MmsValue_newVisibleString("optional AI4");

iedModel_OilSourceA_MeasGGIO1_AnIn9_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_OilSourceA_MeasGGIO1_AnIn9_units_multiplier.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_OilSourceA_MeasGGIO1_AnIn9_d.mmsValue = MmsValue_newVisibleString("optional AI5");

iedModel_OilSourceA_MeasGGIO1_AnIn10_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_OilSourceA_MeasGGIO1_AnIn10_units_multiplier.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_OilSourceA_MeasGGIO1_AnIn10_d.mmsValue = MmsValue_newVisibleString("optional AI6");

iedModel_OilSourceA_MeasGGIO1_Alm1_d.mmsValue = MmsValue_newVisibleString("Hydrogen (H2) limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm2_d.mmsValue = MmsValue_newVisibleString("Carbon Dioxide (CO2) limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm3_d.mmsValue = MmsValue_newVisibleString("Carbon Monoxide (CO) limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm4_d.mmsValue = MmsValue_newVisibleString("Ethylene (C2H4) limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm5_d.mmsValue = MmsValue_newVisibleString("Ethane (C2H6) limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm6_d.mmsValue = MmsValue_newVisibleString("Methane (CH4) limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm7_d.mmsValue = MmsValue_newVisibleString("Acetylene (C2H2) limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm8_d.mmsValue = MmsValue_newVisibleString("Water (H2O) limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm9_d.mmsValue = MmsValue_newVisibleString("Oxygen (O2) limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm10_d.mmsValue = MmsValue_newVisibleString("TDCG limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm11_d.mmsValue = MmsValue_newVisibleString("Nitrogen (N2) limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm12_d.mmsValue = MmsValue_newVisibleString("Hydrogen (H2) ROC limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm13_d.mmsValue = MmsValue_newVisibleString("Carbon Dioxide (CO2) ROC limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm14_d.mmsValue = MmsValue_newVisibleString("Carbon Monoxide (CO) ROC limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm15_d.mmsValue = MmsValue_newVisibleString("Ethylene (C2H4) ROC limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm16_d.mmsValue = MmsValue_newVisibleString("Ethane (C2H6) ROC limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm17_d.mmsValue = MmsValue_newVisibleString("Methane (CH4) ROC limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm18_d.mmsValue = MmsValue_newVisibleString("Acetylene (C2H2) ROC limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm19_d.mmsValue = MmsValue_newVisibleString("Water (H2O) ROC limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm20_d.mmsValue = MmsValue_newVisibleString("Oxygen (O2) ROC limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm21_d.mmsValue = MmsValue_newVisibleString("TDCG ROC limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Alm22_d.mmsValue = MmsValue_newVisibleString("Nitrogen (N2) ROC limit exceeded");

iedModel_OilSourceA_MeasGGIO1_Ind1_d.mmsValue = MmsValue_newVisibleString("Caution Mode Enabled");

iedModel_OilSourceA_MeasGGIO1_Ind2_d.mmsValue = MmsValue_newVisibleString("Alarm Mode Enabled");

iedModel_OilSourceA_MeasGGIO1_Ind3_d.mmsValue = MmsValue_newVisibleString("SMS Message sent");

iedModel_OilSourceA_MeasGGIO1_Ind4_d.mmsValue = MmsValue_newVisibleString("Caution Indicator On");

iedModel_OilSourceA_MeasGGIO1_Ind5_d.mmsValue = MmsValue_newVisibleString("Alarm Indicator On");

iedModel_OilSourceA_MeasGGIO1_Ind6_d.mmsValue = MmsValue_newVisibleString("Service Indicator On");

iedModel_OilSourceA_MeasGGIO1_Ind7_d.mmsValue = MmsValue_newVisibleString("Relay 2 Enabled");

iedModel_OilSourceA_MeasGGIO1_Ind8_d.mmsValue = MmsValue_newVisibleString("Relay 3 Enabled");

iedModel_OilSourceA_MeasGGIO1_Ind9_d.mmsValue = MmsValue_newVisibleString("Relay 4 Enabled");

iedModel_OilSourceA_MeasGGIO1_Ind10_d.mmsValue = MmsValue_newVisibleString("Relay 5 Enabled");

iedModel_OilSourceA_MeasGGIO1_Ind11_d.mmsValue = MmsValue_newVisibleString("Relay 6 Enabled");

iedModel_OilSourceA_MeasGGIO1_Ind12_d.mmsValue = MmsValue_newVisibleString("Relay 7 Enabled");

iedModel_OilSourceA_MeasGGIO1_Ind13_d.mmsValue = MmsValue_newVisibleString("PPM values are valid");

iedModel_OilSourceA_MeasGGIO1_Ind14_d.mmsValue = MmsValue_newVisibleString("First measurement after reset");

iedModel_OilSourceA_MeasGGIO1_Ind15_d.mmsValue = MmsValue_newVisibleString("Sampling skipped");

iedModel_OilSourceA_MeasGGIO1_Ind16_d.mmsValue = MmsValue_newVisibleString("Error checking disabled");

iedModel_OilSourceA_MeasGGIO1_Ind17_d.mmsValue = MmsValue_newVisibleString("Nitrogen valid");

iedModel_OilSourceA_MeasGGIO1_Ind18_d.mmsValue = MmsValue_newVisibleString("TDG valid");

iedModel_OilSourceA_MeasGGIO1_Ind19_d.mmsValue = MmsValue_newVisibleString("Oil switch failed");

iedModel_OilSourceA_MeasGGIO1_Ind20_d.mmsValue = MmsValue_newVisibleString("Spurious alarm suspected");

iedModel_OilSourceA_MeasGGIO1_Ind21_d.mmsValue = MmsValue_newVisibleString("Manual Sample");

iedModel_OilSourceA_MeasGGIO1_Ind22_d.mmsValue = MmsValue_newVisibleString("Measurement Manually Stopped");

iedModel_OilSourceA_MeasGGIO1_Ind23_d.mmsValue = MmsValue_newVisibleString("Weak NHC Indication");

iedModel_OilSourceA_MeasGGIO1_Ind24_d.mmsValue = MmsValue_newVisibleString("Strong NHC Indication");

iedModel_OilSourceA_MeasGGIO1_Ind25_d.mmsValue = MmsValue_newVisibleString("Missing mains input");

iedModel_OilSourceA_MeasGGIO1_Ind26_d.mmsValue = MmsValue_newVisibleString("PGA power supply voltage too low");

iedModel_OilSourceA_MeasGGIO1_Ind27_d.mmsValue = MmsValue_newVisibleString("PGA chopper frequency outside range");

iedModel_OilSourceA_MeasGGIO1_Ind28_d.mmsValue = MmsValue_newVisibleString("PGA IR-source outside range");

iedModel_OilSourceA_MeasGGIO1_Ind29_d.mmsValue = MmsValue_newVisibleString("Gas flow lower than limit");

iedModel_OilSourceA_MeasGGIO1_Ind30_d.mmsValue = MmsValue_newVisibleString("Background noise/vibration too high");

iedModel_OilSourceA_MeasGGIO1_Ind31_d.mmsValue = MmsValue_newVisibleString("Microphone test failed");

iedModel_OilSourceA_MeasGGIO1_Ind32_d.mmsValue = MmsValue_newVisibleString("No levelsensor1 signal (oil level)");

iedModel_OilSourceA_MeasGGIO1_Ind33_d.mmsValue = MmsValue_newVisibleString("No Levelsensor3 signal (oil drain)");

iedModel_OilSourceA_MeasGGIO1_Ind34_d.mmsValue = MmsValue_newVisibleString("Levelsensor1 signal (oil level) ");

iedModel_OilSourceA_MeasGGIO1_Ind35_d.mmsValue = MmsValue_newVisibleString("Levelsensor2 signal (oil level alert) ");

iedModel_OilSourceA_MeasGGIO1_Ind36_d.mmsValue = MmsValue_newVisibleString("PGA Air temperature outside limits");

iedModel_OilSourceA_MeasGGIO1_Ind37_d.mmsValue = MmsValue_newVisibleString("Bad communication with controlboard");

iedModel_OilSourceA_MeasGGIO1_Ind38_d.mmsValue = MmsValue_newVisibleString("Gas leak test: Pump pressure too low ");

iedModel_OilSourceA_MeasGGIO1_Ind39_d.mmsValue = MmsValue_newVisibleString("Gas leak test: Pressure decay too high");

iedModel_OilSourceA_MeasGGIO1_Ind40_d.mmsValue = MmsValue_newVisibleString("Oil temperature too low");

iedModel_OilSourceA_MeasGGIO1_Ind41_d.mmsValue = MmsValue_newVisibleString("Oil temperature too high");

iedModel_OilSourceA_MeasGGIO1_Ind42_d.mmsValue = MmsValue_newVisibleString("Oil pressure too low");

iedModel_OilSourceA_MeasGGIO1_Ind43_d.mmsValue = MmsValue_newVisibleString("Oil pressure too high");

iedModel_OilSourceA_MeasGGIO1_Ind44_d.mmsValue = MmsValue_newVisibleString("Oil pump tacho count too high");

iedModel_OilSourceA_MeasGGIO1_Ind45_d.mmsValue = MmsValue_newVisibleString("Oil pump pressure too low");

iedModel_OilSourceA_MeasGGIO1_Ind46_d.mmsValue = MmsValue_newVisibleString("Oil pump speed out of range");

iedModel_OilSourceA_MeasGGIO1_Ind47_d.mmsValue = MmsValue_newVisibleString("Manual oil sampling switch");

iedModel_OilSourceA_MeasGGIO1_Ind48_d.mmsValue = MmsValue_newVisibleString("Oil pump tacho count too low");

iedModel_OilSourceA_MeasGGIO1_Ind49_d.mmsValue = MmsValue_newVisibleString("Oil pump not turning");

iedModel_OilSourceA_StGGIO2_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_OilSourceA_StGGIO2_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_OilSourceA_StGGIO2_NamPlt_lnNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2003");

iedModel_OilSourceA_StGGIO2_Ind1_d.mmsValue = MmsValue_newVisibleString("Measuring Source A");

iedModel_OilSourceA_StGGIO2_Ind2_d.mmsValue = MmsValue_newVisibleString("Source A Enable");

iedModel_OilSourceA_StGGIO2_Ind3_d.mmsValue = MmsValue_newVisibleString("Source A Scheduler Normal mode");

iedModel_OilSourceA_StGGIO2_Ind4_d.mmsValue = MmsValue_newVisibleString("Source A Scheduler Caution mode");

iedModel_OilSourceA_StGGIO2_Ind5_d.mmsValue = MmsValue_newVisibleString("Source A Scheduler Alarm mode");

iedModel_OilSourceA_SIML1_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_OilSourceA_SIML1_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_OilSourceA_SIML1_NamPlt_lnNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2010");

iedModel_OilSourceA_SIML1_Pres_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(39);

iedModel_OilSourceA_SIML1_Pres_units_multiplier.mmsValue = MmsValue_newIntegerFromInt32(3);

iedModel_OilSourceA_SIML1_Pres_d.mmsValue = MmsValue_newVisibleString("Oil Pressure");

iedModel_OilSourceA_SIML1_H2O_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_OilSourceA_SIML1_H2O_d.mmsValue = MmsValue_newVisibleString("Water Relative Saturation");

iedModel_OilSourceA_SIML1_H2OTmp_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(23);

iedModel_OilSourceA_SIML1_H2OTmp_d.mmsValue = MmsValue_newVisibleString("Oilt temp at H2O sensor");

iedModel_OilSourceA_SIML1_H2ppm_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(52);

iedModel_OilSourceA_SIML1_H2ppm_d.mmsValue = MmsValue_newVisibleString("Hydrogen conc.");

iedModel_OilSourceA_SIML1_N2ppm_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(52);

iedModel_OilSourceA_SIML1_N2ppm_d.mmsValue = MmsValue_newVisibleString("Nitrogen conc.");

iedModel_OilSourceA_SIML1_COppm_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(52);

iedModel_OilSourceA_SIML1_COppm_d.mmsValue = MmsValue_newVisibleString("Carbon Monoxide conc.");

iedModel_OilSourceA_SIML1_CO2ppm_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(52);

iedModel_OilSourceA_SIML1_CO2ppm_d.mmsValue = MmsValue_newVisibleString("Carbon Dioxide conc.");

iedModel_OilSourceA_SIML1_CH4ppm_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(52);

iedModel_OilSourceA_SIML1_CH4ppm_d.mmsValue = MmsValue_newVisibleString("Methane conc.");

iedModel_OilSourceA_SIML1_C2H2ppm_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(52);

iedModel_OilSourceA_SIML1_C2H2ppm_d.mmsValue = MmsValue_newVisibleString("Acetylene conc.");

iedModel_OilSourceA_SIML1_C2H4ppm_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(52);

iedModel_OilSourceA_SIML1_C2H4ppm_d.mmsValue = MmsValue_newVisibleString("Ethylene conc.");

iedModel_OilSourceA_SIML1_C2H6ppm_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(52);

iedModel_OilSourceA_SIML1_C2H6ppm_d.mmsValue = MmsValue_newVisibleString("Ethane conc.");

iedModel_OilSourceA_SIML1_O2ppm_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(52);

iedModel_OilSourceA_SIML1_O2ppm_d.mmsValue = MmsValue_newVisibleString("Oxygen conc.");

iedModel_OilSourceA_SIML1_CmbuGas_units_SIUnit.mmsValue = MmsValue_newIntegerFromInt32(52);

iedModel_OilSourceA_SIML1_CmbuGas_d.mmsValue = MmsValue_newVisibleString("TDCG conc.");

iedModel_General_LLN0_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_General_LLN0_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_General_LLN0_NamPlt_vendor.mmsValue = MmsValue_newVisibleString("GE Energy");

iedModel_General_LLN0_NamPlt_swRev.mmsValue = MmsValue_newVisibleString("1.12.0");

iedModel_General_LLN0_NamPlt_d.mmsValue = MmsValue_newVisibleString("");

iedModel_General_LLN0_NamPlt_configRev.mmsValue = MmsValue_newVisibleString("2ECD33CE21");

iedModel_General_LLN0_NamPlt_ldNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2003");

iedModel_General_LPHD1_PhyNam_vendor.mmsValue = MmsValue_newVisibleString("GE Energy");

iedModel_General_LPHD1_PhyNam_hwRev.mmsValue = MmsValue_newVisibleString("1.6");

iedModel_General_LPHD1_PhyNam_swRev.mmsValue = MmsValue_newVisibleString("1.12.0");

iedModel_General_LPHD1_PhyNam_model.mmsValue = MmsValue_newVisibleString("KELMAN TRANSFIX");

iedModel_General_AnIn1GGIO2_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_General_AnIn1GGIO2_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_General_AnIn1GGIO2_AnIn1_d.mmsValue = MmsValue_newVisibleString("AI1 Type");

iedModel_General_AnIn1GGIO2_AnIn2_d.mmsValue = MmsValue_newVisibleString("AI1 PGA Value");

iedModel_General_AnIn1GGIO2_Alm1_d.mmsValue = MmsValue_newVisibleString("AI1 Value is lower than Min Limit");

iedModel_General_AnIn1GGIO2_Alm2_d.mmsValue = MmsValue_newVisibleString("AI1 Value is greater than Max Limit");

iedModel_General_AnIn1GGIO2_Alm3_d.mmsValue = MmsValue_newVisibleString("AI1 ROC is greater than ROC Limit");

iedModel_General_AnIn1GGIO2_Ind1_d.mmsValue = MmsValue_newVisibleString("AI1 Caution Mode On");

iedModel_General_AnIn1GGIO2_Ind2_d.mmsValue = MmsValue_newVisibleString("AI1 Alarm Mode On");

iedModel_General_AnIn1GGIO2_Ind3_d.mmsValue = MmsValue_newVisibleString("AI1 SMS Message On");

iedModel_General_AnIn1GGIO2_Ind4_d.mmsValue = MmsValue_newVisibleString("AI1 Caution Indicator On");

iedModel_General_AnIn1GGIO2_Ind5_d.mmsValue = MmsValue_newVisibleString("AI1 Alarm Indicator On");

iedModel_General_AnIn1GGIO2_Ind6_d.mmsValue = MmsValue_newVisibleString("AI1 Relay 2 On");

iedModel_General_AnIn1GGIO2_Ind7_d.mmsValue = MmsValue_newVisibleString("AI1 Relay 3 On");

iedModel_General_AnIn1GGIO2_Ind8_d.mmsValue = MmsValue_newVisibleString("AI1 Relay 4 On");

iedModel_General_AnIn1GGIO2_Ind9_d.mmsValue = MmsValue_newVisibleString("AI1 Relay 5 On");

iedModel_General_AnIn1GGIO2_Ind10_d.mmsValue = MmsValue_newVisibleString("AI1 Relay 6 On");

iedModel_General_AnIn1GGIO2_Ind11_d.mmsValue = MmsValue_newVisibleString("AI1 Relay 7 On");

iedModel_General_AnIn2GGIO3_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_General_AnIn2GGIO3_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_General_AnIn2GGIO3_AnIn1_d.mmsValue = MmsValue_newVisibleString("AI2 Type");

iedModel_General_AnIn2GGIO3_AnIn2_d.mmsValue = MmsValue_newVisibleString("AI2 PGA Value");

iedModel_General_AnIn2GGIO3_Alm1_d.mmsValue = MmsValue_newVisibleString("AI2 Value is lower than Min Limit");

iedModel_General_AnIn2GGIO3_Alm2_d.mmsValue = MmsValue_newVisibleString("AI2 Value is greater than Max Limit");

iedModel_General_AnIn2GGIO3_Alm3_d.mmsValue = MmsValue_newVisibleString("AI2 ROC is greater than ROC Limit");

iedModel_General_AnIn2GGIO3_Ind1_d.mmsValue = MmsValue_newVisibleString("AI2 Caution Mode On");

iedModel_General_AnIn2GGIO3_Ind2_d.mmsValue = MmsValue_newVisibleString("AI2 Alarm Mode On");

iedModel_General_AnIn2GGIO3_Ind3_d.mmsValue = MmsValue_newVisibleString("AI2 SMS Message On");

iedModel_General_AnIn2GGIO3_Ind4_d.mmsValue = MmsValue_newVisibleString("AI2 Caution Indicator On");

iedModel_General_AnIn2GGIO3_Ind5_d.mmsValue = MmsValue_newVisibleString("AI2 Alarm Indicator On");

iedModel_General_AnIn2GGIO3_Ind6_d.mmsValue = MmsValue_newVisibleString("AI2 Relay 2 On");

iedModel_General_AnIn2GGIO3_Ind7_d.mmsValue = MmsValue_newVisibleString("AI2 Relay 3 On");

iedModel_General_AnIn2GGIO3_Ind8_d.mmsValue = MmsValue_newVisibleString("AI2 Relay 4 On");

iedModel_General_AnIn2GGIO3_Ind9_d.mmsValue = MmsValue_newVisibleString("AI2 Relay 5 On");

iedModel_General_AnIn2GGIO3_Ind10_d.mmsValue = MmsValue_newVisibleString("AI2 Relay 6 On");

iedModel_General_AnIn2GGIO3_Ind11_d.mmsValue = MmsValue_newVisibleString("AI2 Relay 7 On");

iedModel_General_AnIn3GGIO4_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_General_AnIn3GGIO4_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_General_AnIn3GGIO4_AnIn1_d.mmsValue = MmsValue_newVisibleString("AI3 Type");

iedModel_General_AnIn3GGIO4_AnIn2_d.mmsValue = MmsValue_newVisibleString("AI3 PGA Value");

iedModel_General_AnIn3GGIO4_Alm1_d.mmsValue = MmsValue_newVisibleString("AI3 Value is lower than Min Limit");

iedModel_General_AnIn3GGIO4_Alm2_d.mmsValue = MmsValue_newVisibleString("AI3 Value is greater than Max Limit");

iedModel_General_AnIn3GGIO4_Alm3_d.mmsValue = MmsValue_newVisibleString("AI3 ROC is greater than ROC Limit");

iedModel_General_AnIn3GGIO4_Ind1_d.mmsValue = MmsValue_newVisibleString("AI3 Caution Mode On");

iedModel_General_AnIn3GGIO4_Ind2_d.mmsValue = MmsValue_newVisibleString("AI3 Alarm Mode On");

iedModel_General_AnIn3GGIO4_Ind3_d.mmsValue = MmsValue_newVisibleString("AI3 SMS Message On");

iedModel_General_AnIn3GGIO4_Ind4_d.mmsValue = MmsValue_newVisibleString("AI3 Caution Indicator On");

iedModel_General_AnIn3GGIO4_Ind5_d.mmsValue = MmsValue_newVisibleString("AI3 Alarm Indicator On");

iedModel_General_AnIn3GGIO4_Ind6_d.mmsValue = MmsValue_newVisibleString("AI3 Relay 2 On");

iedModel_General_AnIn3GGIO4_Ind7_d.mmsValue = MmsValue_newVisibleString("AI3 Relay 3 On");

iedModel_General_AnIn3GGIO4_Ind8_d.mmsValue = MmsValue_newVisibleString("AI3 Relay 4 On");

iedModel_General_AnIn3GGIO4_Ind9_d.mmsValue = MmsValue_newVisibleString("AI3 Relay 5 On");

iedModel_General_AnIn3GGIO4_Ind10_d.mmsValue = MmsValue_newVisibleString("AI3 Relay 6 On");

iedModel_General_AnIn3GGIO4_Ind11_d.mmsValue = MmsValue_newVisibleString("AI3 Relay 7 On");

iedModel_General_AnIn5GGIO6_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_General_AnIn5GGIO6_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_General_AnIn5GGIO6_AnIn1_d.mmsValue = MmsValue_newVisibleString("AI5 Type");

iedModel_General_AnIn5GGIO6_AnIn2_d.mmsValue = MmsValue_newVisibleString("AI5 PGA Value");

iedModel_General_AnIn5GGIO6_Alm1_d.mmsValue = MmsValue_newVisibleString("AI5 Value is lower than Min Limit");

iedModel_General_AnIn5GGIO6_Alm2_d.mmsValue = MmsValue_newVisibleString("AI5 Value is greater than Max Limit");

iedModel_General_AnIn5GGIO6_Alm3_d.mmsValue = MmsValue_newVisibleString("AI5 ROC is greater than ROC Limit");

iedModel_General_AnIn5GGIO6_Ind1_d.mmsValue = MmsValue_newVisibleString("AI5 Caution Mode On");

iedModel_General_AnIn5GGIO6_Ind2_d.mmsValue = MmsValue_newVisibleString("AI5 Alarm Mode On");

iedModel_General_AnIn5GGIO6_Ind3_d.mmsValue = MmsValue_newVisibleString("AI5 SMS Message On");

iedModel_General_AnIn5GGIO6_Ind4_d.mmsValue = MmsValue_newVisibleString("AI5 Caution Indicator On");

iedModel_General_AnIn5GGIO6_Ind5_d.mmsValue = MmsValue_newVisibleString("AI5 Alarm Indicator On");

iedModel_General_AnIn5GGIO6_Ind6_d.mmsValue = MmsValue_newVisibleString("AI5 Relay 2 On");

iedModel_General_AnIn5GGIO6_Ind7_d.mmsValue = MmsValue_newVisibleString("AI5 Relay 3 On");

iedModel_General_AnIn5GGIO6_Ind8_d.mmsValue = MmsValue_newVisibleString("AI5 Relay 4 On");

iedModel_General_AnIn5GGIO6_Ind9_d.mmsValue = MmsValue_newVisibleString("AI5 Relay 5 On");

iedModel_General_AnIn5GGIO6_Ind10_d.mmsValue = MmsValue_newVisibleString("AI5 Relay 6 On");

iedModel_General_AnIn5GGIO6_Ind11_d.mmsValue = MmsValue_newVisibleString("AI5 Relay 7 On");

iedModel_General_AnIn4GGIO5_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_General_AnIn4GGIO5_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_General_AnIn4GGIO5_AnIn1_d.mmsValue = MmsValue_newVisibleString("AI4 Type");

iedModel_General_AnIn4GGIO5_AnIn2_d.mmsValue = MmsValue_newVisibleString("AI4 PGA Value");

iedModel_General_AnIn4GGIO5_Alm1_d.mmsValue = MmsValue_newVisibleString("AI4 Value is lower than Min Limit");

iedModel_General_AnIn4GGIO5_Alm2_d.mmsValue = MmsValue_newVisibleString("AI4 Value is greater than Max Limit");

iedModel_General_AnIn4GGIO5_Alm3_d.mmsValue = MmsValue_newVisibleString("AI4 ROC is greater than ROC Limit");

iedModel_General_AnIn4GGIO5_Ind1_d.mmsValue = MmsValue_newVisibleString("AI4 Caution Mode On");

iedModel_General_AnIn4GGIO5_Ind2_d.mmsValue = MmsValue_newVisibleString("AI4 Alarm Mode On");

iedModel_General_AnIn4GGIO5_Ind3_d.mmsValue = MmsValue_newVisibleString("AI4 SMS Message On");

iedModel_General_AnIn4GGIO5_Ind4_d.mmsValue = MmsValue_newVisibleString("AI4 Caution Indicator On");

iedModel_General_AnIn4GGIO5_Ind5_d.mmsValue = MmsValue_newVisibleString("AI4 Alarm Indicator On");

iedModel_General_AnIn4GGIO5_Ind6_d.mmsValue = MmsValue_newVisibleString("AI4 Relay 2 On");

iedModel_General_AnIn4GGIO5_Ind7_d.mmsValue = MmsValue_newVisibleString("AI4 Relay 3 On");

iedModel_General_AnIn4GGIO5_Ind8_d.mmsValue = MmsValue_newVisibleString("AI4 Relay 4 On");

iedModel_General_AnIn4GGIO5_Ind9_d.mmsValue = MmsValue_newVisibleString("AI4 Relay 5 On");

iedModel_General_AnIn4GGIO5_Ind10_d.mmsValue = MmsValue_newVisibleString("AI4 Relay 6 On");

iedModel_General_AnIn4GGIO5_Ind11_d.mmsValue = MmsValue_newVisibleString("AI4 Relay 7 On");

iedModel_General_AnIn6GGIO7_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_General_AnIn6GGIO7_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_General_AnIn6GGIO7_AnIn1_d.mmsValue = MmsValue_newVisibleString("AI6 Type");

iedModel_General_AnIn6GGIO7_AnIn2_d.mmsValue = MmsValue_newVisibleString("AI6 PGA Value");

iedModel_General_AnIn6GGIO7_Alm1_d.mmsValue = MmsValue_newVisibleString("AI6 Value is lower than Min Limit");

iedModel_General_AnIn6GGIO7_Alm2_d.mmsValue = MmsValue_newVisibleString("AI6 Value is greater than Max Limit");

iedModel_General_AnIn6GGIO7_Alm3_d.mmsValue = MmsValue_newVisibleString("AI6 ROC is greater than ROC Limit");

iedModel_General_AnIn6GGIO7_Ind1_d.mmsValue = MmsValue_newVisibleString("AI6 Caution Mode On");

iedModel_General_AnIn6GGIO7_Ind2_d.mmsValue = MmsValue_newVisibleString("AI6 Alarm Mode On");

iedModel_General_AnIn6GGIO7_Ind3_d.mmsValue = MmsValue_newVisibleString("AI6 SMS Message On");

iedModel_General_AnIn6GGIO7_Ind4_d.mmsValue = MmsValue_newVisibleString("AI6 Caution Indicator On");

iedModel_General_AnIn6GGIO7_Ind5_d.mmsValue = MmsValue_newVisibleString("AI6 Alarm Indicator On");

iedModel_General_AnIn6GGIO7_Ind6_d.mmsValue = MmsValue_newVisibleString("AI6 Relay 2 On");

iedModel_General_AnIn6GGIO7_Ind7_d.mmsValue = MmsValue_newVisibleString("AI6 Relay 3 On");

iedModel_General_AnIn6GGIO7_Ind8_d.mmsValue = MmsValue_newVisibleString("AI6 Relay 4 On");

iedModel_General_AnIn6GGIO7_Ind9_d.mmsValue = MmsValue_newVisibleString("AI6 Relay 5 On");

iedModel_General_AnIn6GGIO7_Ind10_d.mmsValue = MmsValue_newVisibleString("AI6 Relay 6 On");

iedModel_General_AnIn6GGIO7_Ind11_d.mmsValue = MmsValue_newVisibleString("AI6 Relay 7 On");

iedModel_General_TFXStGGIO11_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_General_TFXStGGIO11_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_General_TFXStGGIO11_Ind1_d.mmsValue = MmsValue_newVisibleString("Normal State");

iedModel_General_TFXStGGIO11_Ind2_d.mmsValue = MmsValue_newVisibleString("Caution Indicator");

iedModel_General_TFXStGGIO11_Ind3_d.mmsValue = MmsValue_newVisibleString("Alarm Indicator");

iedModel_General_TFXStGGIO11_Ind4_d.mmsValue = MmsValue_newVisibleString("Service Indicator");

iedModel_General_TFXStGGIO11_Ind5_d.mmsValue = MmsValue_newVisibleString("Oil Draining State");

iedModel_General_TFXStGGIO11_Ind6_d.mmsValue = MmsValue_newVisibleString("Reprogramming State");

iedModel_General_TFXStGGIO11_Ind7_d.mmsValue = MmsValue_newVisibleString("Manual Sample");

iedModel_General_TFXStGGIO11_Ind8_d.mmsValue = MmsValue_newVisibleString("Standby");

iedModel_General_TFXStGGIO11_Ind9_d.mmsValue = MmsValue_newVisibleString("Scheduler Enable");

iedModel_General_TFXStGGIO11_Ind10_d.mmsValue = MmsValue_newVisibleString("Heart Beat");

iedModel_General_DevSchGGIO12_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_General_DevSchGGIO12_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_General_DevSchGGIO12_Ind1_d.mmsValue = MmsValue_newVisibleString("Peripheral Scheduler enable");

iedModel_General_DevSchGGIO12_Ind2_d.mmsValue = MmsValue_newVisibleString("Peripheral Scheduler Normal Mode");

iedModel_General_DevSchGGIO12_Ind3_d.mmsValue = MmsValue_newVisibleString("Peripheral Scheduler Caution Mode");

iedModel_General_DevSchGGIO12_Ind4_d.mmsValue = MmsValue_newVisibleString("Peripheral Scheduler Alarm Mode");

iedModel_General_DIGGIO8_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_General_DIGGIO8_AnIn1_d.mmsValue = MmsValue_newVisibleString("DI1 Type");

iedModel_General_DIGGIO8_AnIn2_d.mmsValue = MmsValue_newVisibleString("DI1 Nbr of DIN transitions since last DIN enable");

iedModel_General_DIGGIO8_Alm1_d.mmsValue = MmsValue_newVisibleString("DI1 Transition count exceeded Max limit");

iedModel_General_DIGGIO8_Alm2_d.mmsValue = MmsValue_newVisibleString("DI1 Transition ROC exceeded ROC limit");

iedModel_General_DIGGIO8_Ind1_d.mmsValue = MmsValue_newVisibleString("DI1 Caution Mode On");

iedModel_General_DIGGIO8_Ind2_d.mmsValue = MmsValue_newVisibleString("DI1 Alarm Mode On");

iedModel_General_DIGGIO8_Ind3_d.mmsValue = MmsValue_newVisibleString("DI1 SMS Message On");

iedModel_General_DIGGIO8_Ind4_d.mmsValue = MmsValue_newVisibleString("DI1 Caution Indicator On");

iedModel_General_DIGGIO8_Ind5_d.mmsValue = MmsValue_newVisibleString("DI1 Alarm Indicator On");

iedModel_General_DIGGIO8_Ind6_d.mmsValue = MmsValue_newVisibleString("DI1 Relay 2 On");

iedModel_General_DIGGIO8_Ind7_d.mmsValue = MmsValue_newVisibleString("DI1 Relay 3 On");

iedModel_General_DIGGIO8_Ind8_d.mmsValue = MmsValue_newVisibleString("DI1 Relay 4 On");

iedModel_General_DIGGIO8_Ind9_d.mmsValue = MmsValue_newVisibleString("DI1 Relay 5 On");

iedModel_General_DIGGIO8_Ind10_d.mmsValue = MmsValue_newVisibleString("DI1 Relay 6 On");

iedModel_General_DIGGIO8_Ind11_d.mmsValue = MmsValue_newVisibleString("DI1 Relay 7 On");

iedModel_General_DIGGIO8_Ind12_d.mmsValue = MmsValue_newVisibleString("DI1 Enable");

iedModel_General_DIGGIO8_Ind13_d.mmsValue = MmsValue_newVisibleString("DI1 Status");

iedModel_General_DIGGIO8_Ind14_d.mmsValue = MmsValue_newVisibleString("DI1 Value");

iedModel_General_DIGGIO9_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_General_DIGGIO9_AnIn1_d.mmsValue = MmsValue_newVisibleString("DI2 Type");

iedModel_General_DIGGIO9_AnIn2_d.mmsValue = MmsValue_newVisibleString("DI2 Nbr of DIN transitions since last DIN enable");

iedModel_General_DIGGIO9_Alm1_d.mmsValue = MmsValue_newVisibleString("DI2 Transition count exceeded Max limit");

iedModel_General_DIGGIO9_Alm2_d.mmsValue = MmsValue_newVisibleString("DI2 Transition ROC exceeded ROC limit");

iedModel_General_DIGGIO9_Ind1_d.mmsValue = MmsValue_newVisibleString("DI2 Caution Mode On");

iedModel_General_DIGGIO9_Ind2_d.mmsValue = MmsValue_newVisibleString("DI2 Alarm Mode On");

iedModel_General_DIGGIO9_Ind3_d.mmsValue = MmsValue_newVisibleString("DI2 SMS Message On");

iedModel_General_DIGGIO9_Ind4_d.mmsValue = MmsValue_newVisibleString("DI2 Caution Indicator On");

iedModel_General_DIGGIO9_Ind5_d.mmsValue = MmsValue_newVisibleString("DI2 Alarm Indicator On");

iedModel_General_DIGGIO9_Ind6_d.mmsValue = MmsValue_newVisibleString("DI2 Relay 2 On");

iedModel_General_DIGGIO9_Ind7_d.mmsValue = MmsValue_newVisibleString("DI2 Relay 3 On");

iedModel_General_DIGGIO9_Ind8_d.mmsValue = MmsValue_newVisibleString("DI2 Relay 4 On");

iedModel_General_DIGGIO9_Ind9_d.mmsValue = MmsValue_newVisibleString("DI2 Relay 5 On");

iedModel_General_DIGGIO9_Ind10_d.mmsValue = MmsValue_newVisibleString("DI2 Relay 6 On");

iedModel_General_DIGGIO9_Ind11_d.mmsValue = MmsValue_newVisibleString("DI2 Relay 7 On");

iedModel_General_DIGGIO9_Ind12_d.mmsValue = MmsValue_newVisibleString("DI2 Enable");

iedModel_General_DIGGIO9_Ind13_d.mmsValue = MmsValue_newVisibleString("DI2 Status");

iedModel_General_DIGGIO9_Ind14_d.mmsValue = MmsValue_newVisibleString("DI2 Value");

iedModel_General_DIGGIO10_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_General_DIGGIO10_AnIn1_d.mmsValue = MmsValue_newVisibleString("DI3 Type");

iedModel_General_DIGGIO10_AnIn2_d.mmsValue = MmsValue_newVisibleString("DI3 Nbr of DIN transitions since last DIN enable");

iedModel_General_DIGGIO10_Alm1_d.mmsValue = MmsValue_newVisibleString("DI3 Transition count exceeded Max limit");

iedModel_General_DIGGIO10_Alm2_d.mmsValue = MmsValue_newVisibleString("DI3 Transition ROC exceeded ROC limit");

iedModel_General_DIGGIO10_Ind1_d.mmsValue = MmsValue_newVisibleString("DI3 Caution Mode On");

iedModel_General_DIGGIO10_Ind2_d.mmsValue = MmsValue_newVisibleString("DI3 Alarm Mode On");

iedModel_General_DIGGIO10_Ind3_d.mmsValue = MmsValue_newVisibleString("DI3 SMS Message On");

iedModel_General_DIGGIO10_Ind4_d.mmsValue = MmsValue_newVisibleString("DI3 Caution Indicator On");

iedModel_General_DIGGIO10_Ind5_d.mmsValue = MmsValue_newVisibleString("DI3 Alarm Indicator On");

iedModel_General_DIGGIO10_Ind6_d.mmsValue = MmsValue_newVisibleString("DI3 Relay 2 On");

iedModel_General_DIGGIO10_Ind7_d.mmsValue = MmsValue_newVisibleString("DI3 Relay 3 On");

iedModel_General_DIGGIO10_Ind8_d.mmsValue = MmsValue_newVisibleString("DI3 Relay 4 On");

iedModel_General_DIGGIO10_Ind9_d.mmsValue = MmsValue_newVisibleString("DI3 Relay 5 On");

iedModel_General_DIGGIO10_Ind10_d.mmsValue = MmsValue_newVisibleString("DI3 Relay 6 On");

iedModel_General_DIGGIO10_Ind11_d.mmsValue = MmsValue_newVisibleString("DI3 Relay 7 On");

iedModel_General_DIGGIO10_Ind12_d.mmsValue = MmsValue_newVisibleString("DI3 Enable");

iedModel_General_DIGGIO10_Ind13_d.mmsValue = MmsValue_newVisibleString("DI3 Status");

iedModel_General_DIGGIO10_Ind14_d.mmsValue = MmsValue_newVisibleString("DI3 Value");

iedModel_Dummy_LLN0_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_Dummy_LLN0_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_Dummy_LLN0_NamPlt_vendor.mmsValue = MmsValue_newVisibleString("GE Energy");

iedModel_Dummy_LLN0_NamPlt_swRev.mmsValue = MmsValue_newVisibleString("1.12.0");

iedModel_Dummy_LLN0_NamPlt_d.mmsValue = MmsValue_newVisibleString("");

iedModel_Dummy_LLN0_NamPlt_configRev.mmsValue = MmsValue_newVisibleString("2ECD33CE21");

iedModel_Dummy_LLN0_NamPlt_ldNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2003");

iedModel_Dummy_LPHD1_PhyNam_vendor.mmsValue = MmsValue_newVisibleString("GE Energy");

iedModel_Dummy_LPHD1_PhyNam_hwRev.mmsValue = MmsValue_newVisibleString("1.6");

iedModel_Dummy_LPHD1_PhyNam_swRev.mmsValue = MmsValue_newVisibleString("1.12.0");

iedModel_Dummy_LPHD1_PhyNam_model.mmsValue = MmsValue_newVisibleString("KELMAN TRANSFIX");

iedModel_Dummy_DummyGGIO1_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_External_LLN0_Mod_ctlModel.mmsValue = MmsValue_newIntegerFromInt32(0);

iedModel_External_LLN0_Beh_stVal.mmsValue = MmsValue_newIntegerFromInt32(1);

iedModel_External_LLN0_NamPlt_vendor.mmsValue = MmsValue_newVisibleString("GE Energy");

iedModel_External_LLN0_NamPlt_swRev.mmsValue = MmsValue_newVisibleString("1.12.0");

iedModel_External_LLN0_NamPlt_d.mmsValue = MmsValue_newVisibleString("");

iedModel_External_LLN0_NamPlt_configRev.mmsValue = MmsValue_newVisibleString("2ECD33CE21");

iedModel_External_LLN0_NamPlt_ldNs.mmsValue = MmsValue_newVisibleString("IEC 61850-7-4:2003");

iedModel_External_LPHD1_PhyNam_vendor.mmsValue = MmsValue_newVisibleString("GE Energy");

iedModel_External_LPHD1_PhyNam_hwRev.mmsValue = MmsValue_newVisibleString("1.6");

iedModel_External_LPHD1_PhyNam_swRev.mmsValue = MmsValue_newVisibleString("1.12.0");

iedModel_External_LPHD1_PhyNam_serNum.mmsValue = MmsValue_newVisibleString("");

iedModel_External_LPHD1_PhyNam_model.mmsValue = MmsValue_newVisibleString("KELMAN TRANSFIX");

iedModel_External_LPHD1_PhyNam_location.mmsValue = MmsValue_newVisibleString("");
}
